/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef RUTHERFORDIUM_PRIVATE_H
#define RUTHERFORDIUM_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"6.6.6.6"
#define VER_MAJOR	6
#define VER_MINOR	6
#define VER_RELEASE	6
#define VER_BUILD	6
#define COMPANY_NAME	"pankoza"
#define FILE_VERSION	"6.6.6.6"
#define FILE_DESCRIPTION	"Rutherfordium.exe setup"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"GDI (noskid)"
#define PRODUCT_VERSION	"6.6.6.6"

#endif /*RUTHERFORDIUM_PRIVATE_H*/
