﻿// PentoxideR.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#define _CRT_SECURE_NO_WARNINGS
// Disable Aero Start
#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include <dwmapi.h>
// Disable Aero End
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <stdio.h>
#include <tchar.h>
#include <ShlObj.h>
#include "Bytebeats.h"
#include "Payloads.h"
#include "GlitchMsg.h"

void StopThread(HANDLE thread) {
    if (thread == NULL) { return; }
    TerminateThread(thread, 0);
    CloseHandle(thread);
    return;
}

HANDLE drawcubethread = NULL, drawiconsthread = NULL, drawcursorsthread = NULL, drawtextsthread = NULL, cursorballthread = NULL, shell32iconsthread = NULL;
void RunPayload() {
    DwmEnableComposition(0); //Disable Aero
    Sleep(3000);
    HANDLE GlitchMsgThread = CreateThread(0, 0, msgbox, 0, 0, 0);
    Sleep(1500);
    sound1();
    cursorballthread = CreateThread(0, 0, CursorBall, 0, 0, 0); drawiconsthread = CreateThread(0, 0, DrawIcons, 0, 0, 0), drawcursorsthread = CreateThread(0, 0, DrawCursors, 0, 0, 0);
    HANDLE Payload1Num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload1Num1);
    RefreshScreen();

    sound2();
    HANDLE Payload2Num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload2Num1);
    RefreshScreen();

    sound3();
    HANDLE Payload3Num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload3Num1);
    RefreshScreen();

    sound4();
    HANDLE Payload4Num1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload4Num1);
    RefreshScreen();

    sound5();
    HANDLE Payload5Num1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload5Num1);
    RefreshScreen();

    sound6();
    HANDLE Payload6Num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload6Num1);
    RefreshScreen();

    sound7();
    HANDLE Payload7Num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload7Num1);
    RefreshScreen();

    sound8();
    HANDLE Payload8Num1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
    HANDLE Payload8Num2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload8Num1); StopThread(Payload8Num2);
    RefreshScreen();

    sound9();
    HANDLE Payload9Num1 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload9Num1);
    RefreshScreen();

    sound10();
    HANDLE Payload10Num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload10Num1);
    RefreshScreen();

    sound11();
    HANDLE Payload11Num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload11Num1);
    StopThread(drawiconsthread); StopThread(drawcursorsthread);
    RefreshScreen();

    sound12();
    HANDLE Payload12Num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload12Num1); StopThread(cursorballthread);
    RefreshScreen();

    sound13();
    HANDLE Payload13Num1 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
    drawcubethread = CreateThread(0, 0, Payload_3DCube, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload13Num1);
    RefreshScreen();

    sound14();
    HANDLE Payload14Num1 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
    drawcursorsthread = CreateThread(0, 0, DrawCursors, 0, 0, 0), drawiconsthread = CreateThread(0, 0, DrawIcons, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload14Num1);
    RefreshScreen();

    sound15();
    HANDLE Payload15Num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload15Num1);
    RefreshScreen();

    sound16();
    HANDLE Payload16Num1 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
    HANDLE Payload16Num2 = CreateThread(0, 0, Payload16_num2, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload16Num1); StopThread(Payload16Num2);
    RefreshScreen();

    sound17();
    HANDLE Payload17Num1 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload17Num1);
    RefreshScreen();

    sound18();
    drawtextsthread = CreateThread(0, 0, DrawTexts2, 0, 0, 0), shell32iconsthread = CreateThread(0, 0, BeautifulShell32Icons, 0, 0, 0);
    HANDLE Payload18Num1 = CreateThread(0, 0, Payload18_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload18Num1);
    RefreshScreen();

    sound19();
    HANDLE Payload19Num1 = CreateThread(0, 0, Payload19_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload19Num1);
    RefreshScreen();

    sound20();
    HANDLE Payload20Num1 = CreateThread(0, 0, Payload20_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload20Num1);
    StopThread(GlitchMsgThread); StopThread(drawiconsthread); StopThread(drawcursorsthread); StopThread(drawcubethread); StopThread(drawtextsthread); StopThread(shell32iconsthread);
    RefreshScreen();

    sound21();
    HANDLE Payload21Num1 = CreateThread(0, 0, Payload21_num1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload21Num1);
    RefreshScreen();
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    LPCSTR FirstWarningTitle, LastWarningTitle, FirstWarningText, LastWarningText;
    FirstWarningTitle = "WARNING - PentoxideR.exe (GDI Only)";
    LastWarningTitle = "LAST WARNING - PentoxideR.exe (GDI Only)";
    FirstWarningText = "This is a GDI Only, Are you sure you want to run it?";
    LastWarningText = "Are you sure?\r\nIt won't harm your computer but it still contains flashing lights and loud noises - NOT for epilepsy";

    if (MessageBoxA(NULL, FirstWarningText, FirstWarningTitle, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
        if (MessageBoxA(NULL, LastWarningText, LastWarningTitle, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
            RunPayload();
            ExitProcess(0);
        }
        else {
            ExitProcess(0);
        }
    }
    else {
        ExitProcess(0);
    }
}