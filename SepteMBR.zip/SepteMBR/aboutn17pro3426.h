#define ABOUT_N17PRO3426 "penis idot sb rubbish 2b sad bee dirty air arm bee."
void absdljksdfasdfasdjfa() {
	std::cout << ABOUT_N17PRO3426;
}