﻿#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
VOID WINAPI MG(HWND hwnd) {
    HWND window = hwnd;
    RECT windowRect;
    GetWindowRect(window, &windowRect);
    int w = windowRect.right - windowRect.left, h = windowRect.bottom - windowRect.top;
    for (;;) {
        HDC hdc = GetDC(window), hdcmem = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hdcmem, bmp);
        HBRUSH hBrush = CreateSolidBrush(RndRGB);
        SelectObject(hdcmem, hBrush);
        PatBlt(hdcmem, 0, 0, w, h, PATCOPY);
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, 0, 0, w, h, hdcmem, 0, 0, w, h, blf);
        Sleep(100);
        if (rand() % 300 <= 150) { InvalidateRect(window, 0, 0); }
    }
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    HWND msgboxHWND;
    if (nCode == HCBT_ACTIVATE)
    {
        msgboxHWND = (HWND)wParam;
        Sleep(100);
        HANDLE mbm = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, msgboxHWND, 0, NULL);
        return 0;
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI Window1_MsgBox(LPVOID lpParam) {
    while (true) {
        MessageBox(NULL, L"", L"", MB_ICONERROR);
        MessageBox(NULL, L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", L"", MB_ICONERROR);
        MessageBox(NULL, L"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t", L"", MB_ICONERROR);
        MessageBox(NULL, L"\n\n\n\t\n\t\t\t\n\n\n\t\t\n\t\n\t\t\t\n\t\n\t\t\t\t\t\n\n\n\t\n\t\n\t\t\n\t\n\t\n\t\t\n\t\n\t\n\t\n\t\n\t\n\t", L"", 1048576 | MB_ICONERROR);
    }
}
DWORD WINAPI Shader1_Error(LPVOID lpParam) {
    HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
    PRGBTRIPLE rgbtriple;
    for (;;) {
        desk = GetDC(0);
        HDC deskMem = CreateCompatibleDC(desk);
        HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
        SelectObject(deskMem, scr);
        BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
        for (int i = 0; i < sw * sh; i++) {
            int x = i % sw, y = i / sh;
            rgbtriple[i].rgbtRed += x & y;
            rgbtriple[i].rgbtGreen += x & y;
            rgbtriple[i].rgbtBlue += x & y;
        }
        BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, SRCCOPY);
        ReleaseDC(wnd, desk);
        DeleteDC(desk); DeleteDC(deskMem); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
        Sleep(10);
    }
}
DWORD WINAPI Shader2_Green(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            rgbScreen[i].rgb = t * i;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Payload1a_Rotate(LPVOID lpParam) {
    RECT rect;
    POINT lpt[3];
    while (true)
    {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        HDC mdc = CreateCompatibleDC(hdc);
        HBITMAP hbit = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(mdc, hbit);
        GetWindowRect(GetDesktopWindow(), &rect);
        int counter = 30;
        HBRUSH Red = CreateSolidBrush(RGB(255, 0, 0));
        SelectObject(mdc, Red);
        PatBlt(mdc, 0, 0, w, h, PATCOPY);
        if (rand() % 2 == 0) {
            lpt[0].x = rect.left + counter;
            lpt[0].y = rect.top - counter;
            lpt[1].x = rect.right + counter;
            lpt[1].y = rect.top + counter;
            lpt[2].x = rect.left - counter;
            lpt[2].y = rect.bottom - counter;
            PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
        }
        else if (rand() % 2 == 1) {
            lpt[0].x = rect.left - counter;
            lpt[0].y = rect.top + counter;
            lpt[1].x = rect.right - counter;
            lpt[1].y = rect.top - counter;
            lpt[2].x = rect.left + counter;
            lpt[2].y = rect.bottom + counter;
            PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
        }
        PlgBlt(mdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
        BitBlt(hdc, 0, 0, w, h, mdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Payload1b_Icon(LPVOID lpParam) {//from XUGE.exe
    HDC hdc = GetDC(0);
    int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    for (;;) {
        for (int x = 0; x <= w; x += 64) {
            for (int y = 0; y <= h; y += 64) {
                DrawIcon(hdc, x, y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(101 + rand() % 4)));
            }
        }
        Sleep(1000);
    }
}
DWORD WINAPI Payload1c_CopyWindows(LPVOID lpParam) {
    RECT r;
    HWND hwnd;
    HDC hdc;
    while (true) {
        hwnd = GetForegroundWindow();
        GetWindowRect(hwnd, &r);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int w1 = r.right - r.left, h1 = r.bottom - r.top;
        hdc = GetWindowDC(hwnd);
        BitBlt(GetDC(0), rand() % w, rand() % h, w1, h1, hdc, 0, 0, SRCCOPY);
        Sleep(100);
    }
}
DWORD WINAPI Shader3_Rainble(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb = (x & y) * RGB(GetRValue(Hue(239)), GetGValue(Hue(239)), GetBValue(Hue(239)));
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader4_Rainble2(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    INT i = 0;
    while (true) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (int)((i ^ 4) + (i * 4) * pow(x - (y ^ x), (1.0 / 3.0)));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader5_Error2(LPVOID lpParam) {//from Alkyl octanitrogen.exe
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* pBits = nullptr;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x ^ y * w;
                BYTE originalRed = pBits[index].rgbRed;
                BYTE originalGreen = pBits[index].rgbGreen;
                BYTE originalBlue = pBits[index].rgbBlue;
                BYTE fractalRed = (x ^ y) * 9;
                BYTE fractalGreen = (x ^ y) * 9;
                BYTE fractalBlue = x ^ y & 9;
                pBits[index].rgbRed += static_cast<BYTE>(0.5 * originalRed + 0.5 * fractalRed);
                pBits[index].rgbGreen += static_cast<BYTE>(0.5 * originalGreen + 0.5 * fractalGreen);
                pBits[index].rgbBlue += static_cast<BYTE>(0.5 * originalBlue + 0.5 * fractalBlue);
                pBits[index].rgbRed += static_cast<BYTE>(pBits[index].rgbRed * 0.8);
                pBits[index].rgbGreen += static_cast<BYTE>((pBits[index].rgbGreen * 0.8));
                pBits[index].rgbBlue += static_cast<BYTE>(pBits[index].rgbBlue * 0.8);
                pBits[index].rgbRed += static_cast<BYTE>(0.3 * fractalBlue + 0.6 * fractalGreen);
                pBits[index].rgbGreen += static_cast<BYTE>(0.3 * fractalRed + 0.6 * fractalBlue);
                pBits[index].rgbBlue += static_cast<BYTE>(0.3 * fractalGreen + 0.6 * fractalRed);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        DeleteDC(hdc);
    }
}
DWORD WINAPI Payload2a_Fractal(LPVOID lpParam) {
    int w = GetSystemMetrics(0) / 4, h = GetSystemMetrics(1) / 4;
    int w1 = w * 4, h1 = h * 4;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w1, h1);
        SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w1, h1, hdc, 0, 0, SRCCOPY);
        BitBlt(hdc, -10, -10, w, h, hcdc, 0, 0, SRCCOPY);
        BitBlt(hdc, w + 10, 0, w, h - 10, hcdc, w, 0, SRCCOPY);
        BitBlt(hdc, w * 2 - 10, 0, w - 10, h, hcdc, w * 2, 0, SRCCOPY);
        BitBlt(hdc, w * 3 + 10, -10, w, h, hcdc, w * 3, 0, SRCCOPY);
        BitBlt(hdc, 0, h + 10, w, h - 10, hcdc, 0, h, SRCCOPY);
        StretchBlt(hdc, w, h, w, h, hcdc, 0, 0, w1, h1, SRCCOPY);
        BitBlt(hdc, w * 2 + 10, h + 10, w - 10, h - 10, hcdc, w * 2, h, SRCCOPY);
        BitBlt(hdc, w * 3 + 10, h, w - 10, h, hcdc, w * 3, h, SRCCOPY);
        StretchBlt(hdc, 0, h * 2, w, h, hcdc, 0, 0, w1, h1, SRCCOPY);
        StretchBlt(hdc, w, h * 2, w, h, hcdc, w + 10, h * 2 + 10, w - 20, h - 20, SRCCOPY);
        StretchBlt(hdc, w * 2 + 10, h * 2 + 10, w - 20, h - 20, hcdc, w * 2, h * 2, w, h, SRCCOPY);
        StretchBlt(hdc, w * 3, h * 2, w, h, hcdc, 0, 0, w, h, SRCCOPY);
        BitBlt(hdc, 10, h * 3, w - 10, h, hcdc, 0, h * 3, SRCCOPY);
        BitBlt(hdc, w, h * 3 + 10, w, h, hcdc, w, h * 3, SRCCOPY);
        BitBlt(hdc, w * 2, h * 3 + 10, w, h, hcdc, w * 2, h * 3, SRCCOPY);
        BitBlt(hdc, w * 3 + 10, h * 3 + 10, w, h, hcdc, w * 3, h * 3, SRCCOPY);
        ReleaseDC(0, hdc); DeleteDC(hcdc);
        DeleteObject(bmp);
        Sleep(100);
    }
}
DWORD WINAPI Payload2b_Icon2(LPVOID lpParam) {
    int M_Icon[] = { IDI_ICON1, IDI_ICON2, IDI_ICON3, IDI_ICON4 };
    int tmp = rand() % 3;
    HICON hIcon[] = { LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\imageres.dll"),MAKEINTRESOURCE(1)),LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\shell32.dll"),MAKEINTRESOURCE(1)),LoadIcon(GetModuleHandle(NULL),MAKEINTRESOURCE(M_Icon[tmp])),LoadIcon(0,IDI_APPLICATION),LoadIcon(0,IDI_SHIELD),LoadIcon(0,IDI_ERROR),LoadIcon(0,IDI_WARNING),LoadIcon(0,IDI_QUESTION),LoadIcon(0,IDI_INFORMATION) };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        DrawIcon(GetDC(0), rand() % w, rand() % h, hIcon[rand() % 9]);
        hIcon[1] = LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\imageres.dll"), MAKEINTRESOURCE(rand() % 300));
        hIcon[2] = LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\shell32.dll"), MAKEINTRESOURCE(rand() % 300));
        tmp = rand() % 3; hIcon[3] = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(M_Icon[tmp]));
        Sleep(10);
    }
}
DWORD WINAPI Payload2c_VisualBasicScriptCode(LPVOID lpParam) {
    LPCSTR code[] = { "msgbox","inputbox","createobject(\"wscript.shell\")","until","loop","if...then...","Sub" };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        SetTextColor(hdc, RndRGB);
        SetBkColor(hdc, RndRGB);
        int tmp = rand() % 7;
        TextOutA(hdc, rand() % w, rand() % h, code[tmp], strlen(code[tmp]));
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader6_Rainble3(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    INT i = 0;
    while (true) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (int)((i ^ 4) + (i * 4) * pow(x * y ^ index, (1.0 / 3.0)));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
        Sleep(5);
    }
}
DWORD WINAPI Payload3a_Mosaic(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 4) {
            for (int x = 0; x < w; x += 4) {
                StretchBlt(hcdc, x, y, 4, 4, hcdc, x, y, 1, 1, SRCCOPY);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc); DeleteDC(hcdc);
        DeleteObject(bmp);
        Sleep(10);
    }
}
DWORD WINAPI Payload3b_CopyScreen(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int rop[] = { SRCCOPY,NOTSRCCOPY,SRCAND,SRCINVERT,SRCPAINT,NOTSRCERASE };
        StretchBlt(GetDC(0), rand() % w, rand() % h, rand() % w, rand() % h, GetDC(0), 0, 0, w, h, rop[rand() % 6]);
        Sleep(10);
    }
}
DWORD WINAPI Payload3c_Colorful(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(NULL);
        HRGN hRgn = CreateEllipticRgn(rand() % w, rand() % h, rand() % w, rand() % h);
        HBRUSH hb1 = CreateHatchBrush(rand() % 7, RndRGB);
        SelectObject(hdc, hRgn);
        SelectObject(hdc, hb1);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        DeleteObject(hb1);
        HBRUSH hb2 = CreateSolidBrush(RndRGB);
        SelectObject(hdc, hb2);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        DeleteObject(hb2);
        DeleteObject(hRgn);
        ci(rand() % w, rand() % h, rand() % w, rand() % h);
        Sleep(10);
    }
}
DWORD WINAPI Payload3d_Melt(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BitBlt(GetDC(0), (rand() % 10) - 5, (rand() % 10) - 5, rand() % w, rand() % h, GetDC(0), 0, 0, SRCCOPY);
    }
}
DWORD WINAPI Payload3e_Move(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
        HBRUSH hBrush = CreateSolidBrush(RndRGB);
        SelectObject(hcdc, bmp);
        BitBlt(hcdc, -20, 20, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, -20, -h + 20, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, w - 20, 20, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, w - 20, -h + 20, w, h, hdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, hBrush);
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        DeleteObject(hBrush);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); DeleteDC(hcdc);
        DeleteObject(bmp);
        Sleep(10);
    }
}
DWORD WINAPI Shader7_Last(LPVOID lpParam) {//from Aopocaly Doom.exe
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); RGBQUAD* data = (RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCERASE);
        GetBitmapBits(hBitmap, w * h * 4, data);
        int v = 0; BYTE byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            v = rand() % 114; *((BYTE*)data + 4 * i + v) -= 1;
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(1);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t >> 5 & (t << 3) + 12 * t * (t >> 13 | (t >> 1 | t >> 10 | t >> 2) & t >> 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    static char buffer[44100 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 12 & 13 ^ 2 | t >> 10 & 9) | 30000 / (t % 4096 + 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 2 & t >> 9 | (t % 240));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    static char buffer[44100 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 2 & t >> 10 | (t % 100));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 ^ t >> 6));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> (3 & t) >> 0xCA98C));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t | t >> 6));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 3 & 5) + (t * (0xC4 >> (t >> 3 % 7) & 13) | t >> 7) + cos(t * 0xC4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {//made by my self
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((((t >> 2) * (t >> 5) | t >> 5) + t * 3 & (t >> 10)) | (rand() % 200));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t << t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void SPtime() {
    Sleep(30000);
}
void runSP() {
    HANDLE wnd1 = CreateThread(NULL, 0, Window1_MsgBox, NULL, 0, NULL);
    Sleep(100);
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Shader1_Error, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1, 0);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader2_Green, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    clean();
    sound3();
    HANDLE th3a = CreateThread(NULL, 0, Payload1a_Rotate, NULL, 0, NULL);
    HANDLE th3b = CreateThread(NULL, 0, Payload1b_Icon, NULL, 0, NULL);
    HANDLE th3c = CreateThread(NULL, 0, Payload1c_CopyWindows, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3a, 0);
    TerminateThread(th3b, 0);
    TerminateThread(th3c, 0);
    clean();
    sound4();
    HANDLE th4 = CreateThread(NULL, 0, Shader3_Rainble, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4, 0);
    clean();
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader4_Rainble2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5, 0);
    clean();
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader5_Error2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6, 0);
    clean();
    sound7();
    HANDLE th7a = CreateThread(NULL, 0, Payload2a_Fractal, NULL, 0, NULL);
    HANDLE th7b = CreateThread(NULL, 0, Payload2b_Icon2, NULL, 0, NULL);
    HANDLE th7c = CreateThread(NULL, 0, Payload2c_VisualBasicScriptCode, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7a, 0);
    clean();
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Shader6_Rainble3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8, 0);
    clean();
    sound9();
    HANDLE th9a = CreateThread(NULL, 0, Payload3a_Mosaic, NULL, 0, NULL);
    HANDLE th9b = CreateThread(NULL, 0, Payload3b_CopyScreen, NULL, 0, NULL);
    HANDLE th9c = CreateThread(NULL, 0, Payload3c_Colorful, NULL, 0, NULL);
    HANDLE th9d = CreateThread(NULL, 0, Payload3d_Melt, NULL, 0, NULL);
    HANDLE th9e = CreateThread(NULL, 0, Payload3e_Move, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9a, 0);
    TerminateThread(th9b, 0);
    TerminateThread(th9c, 0);
    TerminateThread(th9c, 0);
    TerminateThread(th9d, 0);
    TerminateThread(th9e, 0);
    TerminateThread(th7b, 0);
    TerminateThread(th7c, 0);
    clean();
    sound10();
    HANDLE th10 = CreateThread(NULL, 0, Shader7_Last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10, 0);
    clean();
}
void InitDPI() {
    HMODULE hModUser32 = LoadLibraryW(L"user32.dll");
    BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModUser32, "SetProcessDPIAware");
    if (SetProcessDPIAware)
        SetProcessDPIAware();
    FreeLibrary(hModUser32);
}
DWORD xs;
void SeedXorshift32(DWORD dwSeed) {
    xs = dwSeed;
}
int main() {
    InitDPI();
    srand(time(NULL));
    SeedXorshift32((DWORD)time(NULL));
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-YouAiYouAi";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"vbs.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        if (MessageBoxW(0, MessageTextSecond, L"vbs.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { UnhookWindowsHookEx(hook); ExitProcess(0); }
        else {
            UnhookWindowsHookEx(hook);
            runSP();
        }
    }
    return 0;
}