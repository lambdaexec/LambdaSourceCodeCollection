﻿// undefined.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <stdio.h>
#include <tchar.h>
#include <ShlObj.h>
#include "Bytebeats.h"
#include "Payloads.h"

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    Init_DPI();
    LPCSTR FirstWarningTitle = "WARNING - undefined.exe", LastWarningTitle = "LAST WARNING - undefined.exe";
    LPCSTR FirstWarningText = "This is a GDI only, Are you sure you want to run it?", LastWarningText = "Are you sure?\r\nIt won't harm your computer but it contains flashing lights and loud noises - NOT for epilepsy";

    if (MessageBoxA(NULL, FirstWarningText, FirstWarningTitle, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
        if (MessageBoxA(NULL, LastWarningText, LastWarningTitle, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
            Sleep(3000);
            dwm_turnoff();
            StartMalware(); //see Payloads.h
            ExitProcess(0);
        }
        else {
            ExitProcess(0);
        }
    }
    else {
        ExitProcess(0);
    }
}