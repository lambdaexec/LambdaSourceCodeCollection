#pragma once
#include <windows.h>
extern HWND GDIWindow_hwnd = NULL;
extern int w = 0, h = 0;
MSG msg; WNDCLASSEXW wcex; bool buzhidaoxiesha = false, hidewnd = false;

void Init_DPI() {
    HMODULE user32 = GetModuleHandleA("user32.dll");
    if (user32) {
        typedef DWORD(CALLBACK* dpi)(DWORD);
        dpi d_p_i = (dpi)GetProcAddress(user32, "SetProcessDPIAware");
        if (d_p_i) { d_p_i(0); }
    }
}

void dwm_turnoff() { //Only works in Windows Vista and Windows 7.
    HMODULE dwmapi = GetModuleHandleA("dwmapi.dll");
    if (dwmapi) {
        typedef DWORD(CALLBACK* dwm)(DWORD);
        dwm d_w_m = (dwm)GetProcAddress(dwmapi, "DwmEnableComposition");
        if (d_w_m) { d_w_m(0); }
    }
}

void StopThread(HANDLE thread) {
    if (thread == NULL) { return; }
    TerminateThread(thread, 0);
    CloseHandle(thread);
    return;
}

void RefreshScreen() {
    RedrawWindow(GDIWindow_hwnd, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
    InvalidateRect(GDIWindow_hwnd, 0, 1);
    InvalidateRect(0, 0, 0);

    HDC hdc = GetDC(GDIWindow_hwnd), hdc2 = GetDC(0);
    BitBlt(hdc, 0, 0, w, h, hdc2, 0, 0, SRCCOPY);
    ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    DeleteDC(hdc); DeleteDC(hdc2);
    UpdateWindow(GDIWindow_hwnd);
}

int RandomRGB() {
    int rgb = RGB(rand() % 255, rand() % 255, rand() % 255);
    return rgb;
}


VOID WINAPI ci(HDC hdc, int x, int y, int w, int h) {
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    SelectObject(hdc, hBrush);
    BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
    DeleteObject(hrgn); DeleteObject(hBrush);
}

int MyNewDrawIcon2(HDC hdc, int x, int y, int size, HICON hIcon) {
    DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
    DestroyIcon(hIcon); DeleteObject(hIcon);
    return 1;
}

bool first = true; int mic_incrementor = 10, mic_move = 2;
int mic_x1 = 0, mic_x2 = 0, mic_x3 = 0, mic_x4 = 0, mic_y1 = 0, mic_y2 = 0, mic_y3 = 0, mic_y4 = 0;
int mic_signX1 = mic_move, mic_signY1 = mic_move, mic_signX2 = mic_move, mic_signY2 = mic_move, mic_signX3 = mic_move, mic_signY3 = mic_move, mic_signX4 = mic_move, mic_signY4 = mic_move;
void MovingIcons(HDC hdc) {
    HICON hIcon = NULL;
    int sysiconsize = GetSystemMetrics(11);
    if (first == true) {
        mic_x1 = 0, mic_x2 = w - sysiconsize, mic_x3 = 0, mic_x4 = w - sysiconsize;
        mic_y1 = 0, mic_y2 = 0, mic_y3 = h - sysiconsize, mic_y4 = h - sysiconsize;
        first = false;
    }
    hIcon = LoadIcon(NULL, IDI_ERROR);
    MyNewDrawIcon2(hdc, mic_x1, mic_y1, sysiconsize, hIcon);
    hIcon = LoadIcon(NULL, IDI_WARNING);
    MyNewDrawIcon2(hdc, mic_x2, mic_y2, sysiconsize, hIcon);
    hIcon = LoadIcon(NULL, IDI_INFORMATION);
    MyNewDrawIcon2(hdc, mic_x3, mic_y3, sysiconsize, hIcon);
    hIcon = LoadIcon(NULL, IDI_QUESTION);
    MyNewDrawIcon2(hdc, mic_x4, mic_y4, sysiconsize, hIcon);
    mic_x1 += mic_incrementor * mic_signX1; mic_y1 += mic_incrementor * mic_signY1;
    mic_x2 += mic_incrementor * mic_signX2; mic_y2 += mic_incrementor * mic_signY2;
    mic_x3 += mic_incrementor * mic_signX3; mic_y3 += mic_incrementor * mic_signY3;
    mic_x4 += mic_incrementor * mic_signX4; mic_y4 += mic_incrementor * mic_signY4;
    if (mic_x1 >= w) { mic_signX1 = -mic_move; } else if (mic_x1 <= 0) { mic_signX1 = mic_move; }
    if (mic_y1 >= h) { mic_signY1 = -mic_move; } else if (mic_y1 <= 0) { mic_signY1 = mic_move; }
    if (mic_x2 >= w) { mic_signX2 = -mic_move; } else if (mic_x2 <= 0) { mic_signX2 = mic_move; }
    if (mic_y2 >= h) { mic_signY2 = -mic_move; } else if (mic_y2 <= 0) { mic_signY2 = mic_move; }
    if (mic_x3 >= w) { mic_signX3 = -mic_move; } else if (mic_x3 <= 0) { mic_signX3 = mic_move; }
    if (mic_y3 >= h) { mic_signY3 = -mic_move; } else if (mic_y3 <= 0) { mic_signY3 = mic_move; }
    if (mic_x4 >= w) { mic_signX4 = -mic_move; } else if (mic_x4 <= 0) { mic_signX4 = mic_move; }
    if (mic_y4 >= h) { mic_signY4 = -mic_move; } else if (mic_y4 <= 0) { mic_signY4 = mic_move; }
}

void ScreenResolutions(bool canshu1) {
    w = GetSystemMetrics(0); h = GetSystemMetrics(1);
    if (canshu1 && IsWindow(GDIWindow_hwnd)) {
        SetWindowPos(GDIWindow_hwnd, HWND_TOPMOST, 0, 0, w, h, SWP_SHOWWINDOW | SWP_NOACTIVATE);
    }
}

DWORD WINAPI ShowGDIWindow(LPVOID lpParam) {
    Sleep(50);
    SetWindowPos(GDIWindow_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    ShowWindow(GDIWindow_hwnd, true);
    return 0;
}

void ShowHide_GDIEffectWindow(bool a) {
    if (a == false) {
        hidewnd = true;
        SetWindowPos(GDIWindow_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        ShowWindow(GDIWindow_hwnd, false);
    }
    else {
        hidewnd = false;
        SetWindowPos(GDIWindow_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        ShowWindow(GDIWindow_hwnd, true);
    }
}

void KillGDIWindow() {
    buzhidaoxiesha = true; hidewnd = true;
    if (!IsWindow(GDIWindow_hwnd)) { return; }
    KillTimer(GDIWindow_hwnd, 0);
    ShowWindow(GDIWindow_hwnd, false);
    SetWindowPos(GDIWindow_hwnd, NULL, 0, 0, 0, 0, SWP_HIDEWINDOW);
    CloseWindow(GDIWindow_hwnd);
    if (IsWindow(GDIWindow_hwnd)) { DestroyWindow(GDIWindow_hwnd); }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE: { //Window Created Event
        ShowWindow(hwnd, SW_SHOW);
        SetTimer(hwnd, 0, 50, 0);
        break;
    }
    case WM_PAINT: { //Paint Window Event
        ValidateRect(hwnd, 0);
        break;
    }
    case WM_CTLCOLORDLG: { //idk
        return (BOOL)(HBRUSH)GetStockObject(NULL_BRUSH);
        break;
    }
    case WM_TIMER: { //Timer Event (Make GDI effect window always on top)
        SetWindowPos(GDIWindow_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSENDCHANGING | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        break;
    }
    case WM_DESTROY: { //Destroy Window Event
        if (buzhidaoxiesha == false) { return false; }
        KillTimer(hwnd, 0);
        DestroyWindow(hwnd);
        PostQuitMessage(0);
        break;
    }
    case WM_CLOSE: { //Close Window Event
        if (buzhidaoxiesha == false) {
            //MessageBoxA(NULL, "Sorry, You're not allowed to close gdi effect window.", "Permission Denied", MB_ICONERROR);
            return false;
        }
        DestroyWindow(hwnd);
        break;
    }
    case WM_SIZE: { //Window Minimized Event (restore it)
        if (hidewnd == false && wParam == SIZE_MINIMIZED) { 
            CreateThread(0, 0, ShowGDIWindow, 0, 0, 0);
        }
        break;
    }
    case WM_GETMINMAXINFO: { //Window Size Changed Event (Want to change window size? NO WAY!)
        MINMAXINFO* p = (MINMAXINFO*)lParam;
        p->ptMinTrackSize.x = w; p->ptMinTrackSize.y = h;
        p->ptMaxTrackSize.x = w; p->ptMaxTrackSize.y = h;
        return true;
        break;
    }
    case WM_WINDOWPOSCHANGING: { //Window Position Changing Event (Want to change window position? NO WAY!)
        WINDOWPOS* pWindowPos = (WINDOWPOS*)lParam;
        pWindowPos->flags |= SWP_NOMOVE | SWP_NOSIZE;
        return DefWindowProc(hwnd, message, wParam, (LPARAM)pWindowPos);
        break;
    }
    case WM_SYSCOMMAND: { //Close & Minimize Button Clicked Event
        if (hidewnd == false) {
            if ((wParam & 0xFFF0) == SC_CLOSE || (wParam & 0xFFF0) == SC_MINIMIZE) {
                return false;
            }
        }
        break;
    }
    case WM_SHOWWINDOW: { //Window Hided Event  (Want to hide window? NO WAY!)
        if (hidewnd == false && wParam == false) { CreateThread(0, 0, ShowGDIWindow, 0, 0, 0); }
        break;
    }
    case WM_DISPLAYCHANGE: { //Display Changed Event
        ScreenResolutions(true);
        break;
    }
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}