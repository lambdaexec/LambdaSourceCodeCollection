The MBR is a clone of the Chrome Dino game from 
https://github.com/franeklubi/dino
Controls
Use shift to jump
Use ctrl to crouch
note: The MBR doesn't work properly in VMWare, so use VirtualBox
