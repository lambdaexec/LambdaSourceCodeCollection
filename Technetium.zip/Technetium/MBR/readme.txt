i found this 3D MBR here: https://news.ycombinator.com/item?id=21163760
http://oirase.annexia.org/war.S